-- =========================================================
-- DATABASE: absensi_unida
-- Sistem Informasi Absensi Mahasiswa (QR Code)
-- Mata Kuliah: Rekayasa Perangkat Lunak (RPL) — 5 Kelas
-- Universitas Jabal Ghafur - Gle Gapui (Sigli)
-- =========================================================

CREATE DATABASE IF NOT EXISTS absensi_unida CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE absensi_unida;

-- =========================================================
-- TABEL USERS (Akun Login: admin & mahasiswa)
-- =========================================================
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role ENUM('admin', 'mahasiswa') NOT NULL DEFAULT 'mahasiswa',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- =========================================================
-- TABEL PENGATURAN (Data satu mata kuliah — baris tunggal)
-- =========================================================
CREATE TABLE pengaturan (
    id INT PRIMARY KEY DEFAULT 1,
    nama_kampus VARCHAR(150) NOT NULL DEFAULT 'Universitas Jabal Ghafur (Unigha)',
    yayasan VARCHAR(150) NOT NULL DEFAULT 'Yayasan Pembangunan Kampus Jabal Ghafur',
    alamat_kampus VARCHAR(200) NOT NULL DEFAULT 'Gle Gapui, Sigli',
    fakultas VARCHAR(120) NOT NULL DEFAULT 'Fakultas Teknik dan Sains',
    jurusan VARCHAR(120) NOT NULL DEFAULT 'Teknik Informatika',
    prodi VARCHAR(120) NOT NULL DEFAULT 'Teknik Informatika',
    kode_mk VARCHAR(20) NOT NULL DEFAULT 'FTI510',
    nama_mk VARCHAR(150) NOT NULL DEFAULT 'Rekayasa Perangkat Lunak',
    dosen_pengampu VARCHAR(120) NOT NULL DEFAULT 'Zikrul Khalid, S.T., M.T.',
    nidn_dosen VARCHAR(30) DEFAULT NULL,
    no_wa_dosen VARCHAR(20) DEFAULT '085217171948',
    email_dosen VARCHAR(150) DEFAULT NULL,
    semester VARCHAR(20) NOT NULL DEFAULT 'Ganjil',
    tahun_ajaran VARCHAR(20) NOT NULL DEFAULT '2026/2027',
    toleransi_menit INT NOT NULL DEFAULT 15,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

INSERT INTO pengaturan (id) VALUES (1);

-- =========================================================
-- TABEL KELAS (Data Kelas — 5 kelas untuk 1 mata kuliah)
-- =========================================================
CREATE TABLE kelas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nama_kelas VARCHAR(20) NOT NULL UNIQUE,   -- contoh: FTI-03/02, A, B, C
    ruang VARCHAR(50) DEFAULT NULL,
    hari ENUM('Senin','Selasa','Rabu','Kamis','Jumat','Sabtu') NOT NULL DEFAULT 'Senin',
    jam_mulai TIME NOT NULL DEFAULT '08:00:00',
    jam_selesai TIME NOT NULL DEFAULT '10:00:00',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- =========================================================
-- TABEL MAHASISWA
-- =========================================================
CREATE TABLE mahasiswa (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT DEFAULT NULL,   -- NULL = mahasiswa belum punya akun login (daftar sendiri via register.php)
    nama VARCHAR(100) NOT NULL,
    nim VARCHAR(30) NOT NULL UNIQUE,
    jenis_kelamin ENUM('L','P') NOT NULL DEFAULT 'L',
    alamat VARCHAR(200) DEFAULT NULL,
    kelas_id INT NOT NULL,
    qr_token VARCHAR(64) NOT NULL UNIQUE,
    foto VARCHAR(255) DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_mhs_user  FOREIGN KEY (user_id)  REFERENCES users(id) ON DELETE CASCADE,
    CONSTRAINT fk_mhs_kelas FOREIGN KEY (kelas_id) REFERENCES kelas(id) ON DELETE RESTRICT
) ENGINE=InnoDB;

-- =========================================================
-- TABEL ABSENSI (per kelas, per tanggal, untuk mata kuliah tunggal)
-- =========================================================
CREATE TABLE absensi (
    id INT AUTO_INCREMENT PRIMARY KEY,
    mahasiswa_id INT NOT NULL,
    kelas_id INT NOT NULL,
    tanggal DATE NOT NULL,
    waktu_scan TIME NOT NULL,
    status ENUM('H','I','S','A') NOT NULL DEFAULT 'H',
    keterangan VARCHAR(255) DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_abs_mhs   FOREIGN KEY (mahasiswa_id) REFERENCES mahasiswa(id) ON DELETE CASCADE,
    CONSTRAINT fk_abs_kelas FOREIGN KEY (kelas_id)      REFERENCES kelas(id)     ON DELETE CASCADE,
    UNIQUE KEY uniq_absen_harian (mahasiswa_id, tanggal)
) ENGINE=InnoDB;

-- =========================================================
-- TABEL SURAT IZIN
-- =========================================================
CREATE TABLE surat_izin (
    id INT AUTO_INCREMENT PRIMARY KEY,
    mahasiswa_id INT NOT NULL,
    kelas_id INT NOT NULL,
    tanggal_izin DATE NOT NULL,
    jenis ENUM('Izin','Sakit') NOT NULL DEFAULT 'Izin',
    alasan TEXT NOT NULL,
    status_konfirmasi ENUM('Pending','Disetujui','Ditolak') NOT NULL DEFAULT 'Pending',
    wa_terkirim TINYINT(1) NOT NULL DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_izin_mhs   FOREIGN KEY (mahasiswa_id) REFERENCES mahasiswa(id) ON DELETE CASCADE,
    CONSTRAINT fk_izin_kelas FOREIGN KEY (kelas_id)      REFERENCES kelas(id)     ON DELETE CASCADE
) ENGINE=InnoDB;

-- =========================================================
-- TABEL HARI LIBUR (agar sistem tidak menghitung Alfa di tanggal libur)
-- =========================================================
CREATE TABLE hari_libur (
    id INT AUTO_INCREMENT PRIMARY KEY,
    tanggal DATE NOT NULL UNIQUE,
    keterangan VARCHAR(150) DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- =========================================================
-- TABEL PENGUMUMAN (Broadcast info dosen tidak masuk / info lain)
-- =========================================================
CREATE TABLE pengumuman (
    id INT AUTO_INCREMENT PRIMARY KEY,
    kelas_id INT DEFAULT NULL,           -- NULL = untuk semua kelas
    tipe ENUM('Pengumuman','Tugas') NOT NULL DEFAULT 'Pengumuman',
    judul VARCHAR(150) NOT NULL,
    isi TEXT NOT NULL,
    deadline DATETIME DEFAULT NULL,      -- batas waktu, khusus tipe Tugas
    file_lampiran VARCHAR(255) DEFAULT NULL,
    file_nama_asli VARCHAR(255) DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_peng_kelas FOREIGN KEY (kelas_id) REFERENCES kelas(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- =========================================================
-- DATA AWAL (SEED)
-- Username: admin | Password: admin123
-- =========================================================
INSERT INTO users (username, password, role) VALUES
('admin', '$2y$12$7kZlQj3.RT8HDvQ/hstfiOuwM5rL/IGJlu3FrSgBjJ4w8.3Lyxclm', 'admin');

-- 4 Kelas paralel untuk mata kuliah semester 5
INSERT INTO kelas (nama_kelas, ruang, hari, jam_mulai, jam_selesai) VALUES
('5.2', 'FTI-03/02', 'Sabtu', '14:30:00', '17:00:00'),
('5.3', 'FTI-03/03', 'Senin', '08:00:00', '10:30:00'),
('5.4', 'FTI-03/04', 'Jumat', '08:30:00', '11:00:00'),
('5.5', 'FTI-03/05', 'Senin', '08:00:00', '10:30:00');

-- =========================================================
-- DATA MAHASISWA (TANPA AKUN LOGIN)
-- user_id sengaja NULL. Mahasiswa membuat username & password
-- sendiri lewat register.php, lalu datanya diklaim otomatis
-- berdasarkan NIM.
-- Sumber: Daftar Hadir Mahasiswa (DHMD) FTI-03/02, /03, /04.
-- =========================================================
SET @k52 = (SELECT id FROM kelas WHERE nama_kelas = '5.2' LIMIT 1);
SET @k53 = (SELECT id FROM kelas WHERE nama_kelas = '5.3' LIMIT 1);
SET @k54 = (SELECT id FROM kelas WHERE nama_kelas = '5.4' LIMIT 1);
SET @k55 = (SELECT id FROM kelas WHERE nama_kelas = '5.5' LIMIT 1);

-- KELAS 5.2 — FTI-03/02 (30 mahasiswa)
INSERT INTO mahasiswa (kelas_id, nama, nim, jenis_kelamin, qr_token) VALUES
(@k52, 'RAUDHATUL HUSNA', '24105111017', 'P', 'STD-24105111017'),
(@k52, 'FAZZLIA ULFA', '24105111031', 'P', 'STD-24105111031'),
(@k52, 'DARA NABILA SASKIA', '24105111032', 'P', 'STD-24105111032'),
(@k52, 'WILDA RAHMA', '24105111033', 'P', 'STD-24105111033'),
(@k52, 'MIZRAL AQLA', '24105111034', 'L', 'STD-24105111034'),
(@k52, 'MILHAN AHMADIA', '24105111035', 'L', 'STD-24105111035'),
(@k52, 'WIRQAN HERARI', '24105111036', 'L', 'STD-24105111036'),
(@k52, 'RASYA ISLAMI FASYA', '24105111037', 'L', 'STD-24105111037'),
(@k52, 'ADE SITY ZHAHARA', '24105111038', 'P', 'STD-24105111038'),
(@k52, 'IKA NAZILLA', '24105111040', 'P', 'STD-24105111040'),
(@k52, 'ALYA ZAHARA', '24105111041', 'P', 'STD-24105111041'),
(@k52, 'ZASKIA', '24105111042', 'P', 'STD-24105111042'),
(@k52, 'MUHAMMAD SYAUQI', '24105111043', 'L', 'STD-24105111043'),
(@k52, 'NISA WIDIATUL UHYA', '24105111044', 'P', 'STD-24105111044'),
(@k52, 'YASMIN THAHIRAH', '24105111045', 'P', 'STD-24105111045'),
(@k52, 'DIAN RAMADANI', '24105111046', 'P', 'STD-24105111046'),
(@k52, 'TEUKU ARIEL RASYA', '24105111047', 'L', 'STD-24105111047'),
(@k52, 'FAUZAN AZIMA', '24105111048', 'L', 'STD-24105111048'),
(@k52, 'ANIZA NURFADHILA', '24105111049', 'P', 'STD-24105111049'),
(@k52, 'LIZA ULUL KHAIRA', '24105111050', 'P', 'STD-24105111050'),
(@k52, 'OULIA PUTRI', '24105111051', 'P', 'STD-24105111051'),
(@k52, 'TASYA TIQA', '24105111053', 'P', 'STD-24105111053'),
(@k52, 'OZRA FERDIAN', '24105111054', 'L', 'STD-24105111054'),
(@k52, 'SHYBBRAL MALASHY', '24105111056', 'L', 'STD-24105111056'),
(@k52, 'DHIA MUNIRA SAFIRA', '24105111057', 'P', 'STD-24105111057'),
(@k52, 'MUHAMMED FERDY', '24105111058', 'L', 'STD-24105111058'),
(@k52, 'KHAIRUNNISA', '24105111059', 'P', 'STD-24105111059'),
(@k52, 'NADAA FARHAH FADHILLAH', '24105111060', 'P', 'STD-24105111060'),
(@k52, 'AZRATUL AL ZAHRA', '24105111093', 'P', 'STD-24105111093'),
(@k52, 'MUHAMMAD RAYYANNUR', '24105111170', 'L', 'STD-24105111170');

-- KELAS 5.3 — FTI-03/03 (20 mahasiswa)
INSERT INTO mahasiswa (kelas_id, nama, nim, jenis_kelamin, qr_token) VALUES
(@k53, 'HILMATUN SAFURA', '24105111039', 'P', 'STD-24105111039'),
(@k53, 'ZAFIRA ISMI SAMAHIYA', '24105111061', 'P', 'STD-24105111061'),
(@k53, 'MUHAMMAD RAFFAIL', '24105111062', 'L', 'STD-24105111062'),
(@k53, 'HAYATUN NUFUS', '24105111070', 'P', 'STD-24105111070'),
(@k53, 'FEBY AUZIA FITRIANI', '24105111071', 'P', 'STD-24105111071'),
(@k53, 'RISMATUR RAHMI', '24105111073', 'P', 'STD-24105111073'),
(@k53, 'FEZA MUKAMMIL', '24105111075', 'L', 'STD-24105111075'),
(@k53, 'AHLUL ZIKRI', '24105111076', 'L', 'STD-24105111076'),
(@k53, 'ANSHAR SALSARAJA', '24105111077', 'L', 'STD-24105111077'),
(@k53, 'SALMAN FARISI', '24105111080', 'L', 'STD-24105111080'),
(@k53, 'ASMAUL HUSNA', '24105111081', 'P', 'STD-24105111081'),
(@k53, 'ULFA MAILANI', '24105111082', 'P', 'STD-24105111082'),
(@k53, 'RISKA FITRIA', '24105111083', 'P', 'STD-24105111083'),
(@k53, 'INTAN MAULI ZAHRA', '24105111084', 'P', 'STD-24105111084'),
(@k53, 'MISBAHUN NURA', '24105111086', 'P', 'STD-24105111086'),
(@k53, 'RAHMATUL ZIKRA', '24105111087', 'P', 'STD-24105111087'),
(@k53, 'NIZAM', '24105111089', 'L', 'STD-24105111089'),
(@k53, 'VELIGA SHINTA FEZIA', '24105111095', 'P', 'STD-24105111095'),
(@k53, 'NELLY AGUSTIANI', '24105111119', 'P', 'STD-24105111119'),
(@k53, 'MUHAMMAD SHAMDI QOWIE', '24105111169', 'L', 'STD-24105111169');

-- KELAS 5.4 — FTI-03/04 (27 mahasiswa)
INSERT INTO mahasiswa (kelas_id, nama, nim, jenis_kelamin, qr_token) VALUES
(@k54, 'RESTU ARIVAL', '24105111025', 'L', 'STD-24105111025'),
(@k54, 'AIDA YUSIRA', '24105111072', 'P', 'STD-24105111072'),
(@k54, 'NAILA AFIFAH', '24105111074', 'P', 'STD-24105111074'),
(@k54, 'MUHAMMAD ZAMHARIRA', '24105111078', 'L', 'STD-24105111078'),
(@k54, 'QURATUL NAIVA', '24105111085', 'P', 'STD-24105111085'),
(@k54, 'RAISYATUL ALYA', '24105111090', 'P', 'STD-24105111090'),
(@k54, 'SYIFAUL ASKIA', '24105111091', 'P', 'STD-24105111091'),
(@k54, 'PUTRI MULYANI', '24105111092', 'P', 'STD-24105111092'),
(@k54, 'REKHA AQLA', '24105111094', 'P', 'STD-24105111094'),
(@k54, 'MUHAMMAD ZIKRAL', '24105111097', 'L', 'STD-24105111097'),
(@k54, 'MUHAMMAD ZARKAWI', '24105111098', 'L', 'STD-24105111098'),
(@k54, 'ARIF AULIA', '24105111099', 'L', 'STD-24105111099'),
(@k54, 'MISBAH HUDDIN', '24105111100', 'L', 'STD-24105111100'),
(@k54, 'SAFIRA AL SYIFA', '24105111103', 'P', 'STD-24105111103'),
(@k54, 'NAZIRAH FONNA', '24105111105', 'P', 'STD-24105111105'),
(@k54, 'NOVA MAULIDIA', '24105111106', 'P', 'STD-24105111106'),
(@k54, 'YAZRA', '24105111107', 'P', 'STD-24105111107'),
(@k54, 'MUHAMMAD AMAL', '24105111108', 'L', 'STD-24105111108'),
(@k54, 'MUHAMMAD IKHLASUL', '24105111109', 'L', 'STD-24105111109'),
(@k54, 'KHALISA HUE MAI IRA', '24105111110', 'P', 'STD-24105111110'),
(@k54, 'SITI ZALIKHA FARTIA', '24105111111', 'P', 'STD-24105111111'),
(@k54, 'MUHAMMAD DIAUDDIN', '24105111112', 'L', 'STD-24105111112'),
(@k54, 'MUHAMMAD AL-GHIFARI', '24105111113', 'L', 'STD-24105111113'),
(@k54, 'FAUZUL IRHAM', '24105111115', 'L', 'STD-24105111115'),
(@k54, 'HAYATON NUFUS', '24105111116', 'P', 'STD-24105111116'),
(@k54, 'MIFTAHUL FITRI', '24105111117', 'P', 'STD-24105111117'),
(@k54, 'KHAILIL NUZUL AZWAR', '24105111118', 'L', 'STD-24105111118');

-- KELAS 5.5 (32 mahasiswa)
INSERT INTO mahasiswa (kelas_id, nama, nim, jenis_kelamin, qr_token) VALUES
(@k55, 'ZIKRUL KHALIS', '24105111002', 'L', 'STD-24105111002'),
(@k55, 'SYIFA', '24105111005', 'P', 'STD-24105111005'),
(@k55, 'FAJIRA', '24105111023', 'P', 'STD-24105111023'),
(@k55, 'ZIRA ZAHIRA', '24105111029', 'P', 'STD-24105111029'),
(@k55, 'SARATUL AMNA', '24105111068', 'P', 'STD-24105111068'),
(@k55, 'MIA RAHMAWATI', '24105111104', 'P', 'STD-24105111104'),
(@k55, 'MUHAMMAD RAYYAN', '24105111120', 'L', 'STD-24105111120'),
(@k55, 'T. IKHYAR FIRDAUSI', '24105111121', 'L', 'STD-24105111121'),
(@k55, 'MUHAMMAD ALWI', '24105111122', 'L', 'STD-24105111122'),
(@k55, 'HAFIZH FAHREZI', '24105111123', 'L', 'STD-24105111123'),
(@k55, 'NISPA ANISA', '24105111124', 'P', 'STD-24105111124'),
(@k55, 'RAUDHATUL JANNAH', '24105111125', 'P', 'STD-24105111125'),
(@k55, 'TAMA RACHIDI', '24105111127', 'L', 'STD-24105111127'),
(@k55, 'TEUKU ZAKI IRFAN', '24105111128', 'L', 'STD-24105111128'),
(@k55, 'SINTIA ATTAHIRA', '24105111129', 'P', 'STD-24105111129'),
(@k55, 'INTAN SURYA', '24105111132', 'P', 'STD-24105111132'),
(@k55, 'SAFRINA', '24105111133', 'P', 'STD-24105111133'),
(@k55, 'CUT PUTRI BALKIS', '24105111135', 'P', 'STD-24105111135'),
(@k55, 'MUHAMMAD RAIS', '24105111139', 'L', 'STD-24105111139'),
(@k55, 'MUHAMMAD ALAIDINSYAH', '24105111140', 'L', 'STD-24105111140'),
(@k55, 'MUHAMMAD RAFI', '24105111141', 'L', 'STD-24105111141'),
(@k55, 'BADRATUL NAFIS', '24105111143', 'L', 'STD-24105111143'),
(@k55, 'NIA MAULINA', '24105111144', 'P', 'STD-24105111144'),
(@k55, 'AL FASYIMI', '24105111146', 'L', 'STD-24105111146'),
(@k55, 'ALDI', '24105111147', 'L', 'STD-24105111147'),
(@k55, 'M. INDRA NURULLAH', '24105111148', 'L', 'STD-24105111148'),
(@k55, 'KHANSA AIKA ALIYYAH.S', '24105111150', 'P', 'STD-24105111150'),
(@k55, 'KHAIRUL MUNAWAR', '24105111151', 'L', 'STD-24105111151'),
(@k55, 'DILLA NUR PUSPITA', '24105111155', 'P', 'STD-24105111155'),
(@k55, 'JAMALUL HUSNIL MUBARAQ', '24105111161', 'L', 'STD-24105111161'),
(@k55, 'IMAM RAMADHAN', '24105111162', 'L', 'STD-24105111162'),
(@k55, 'M. RAFIQIL A''LAA', '24105111164', 'L', 'STD-24105111164');

-- Cek hasil
SELECT k.nama_kelas, COUNT(m.id) AS jumlah
FROM kelas k LEFT JOIN mahasiswa m ON m.kelas_id = k.id
GROUP BY k.nama_kelas ORDER BY k.nama_kelas;

<?php
/**
 * Konfigurasi Koneksi Database (PDO / MySQL)
 * Absensi Unigha — Sistem Absensi Mahasiswa Mata Kuliah RPL
 * Universitas Jabal Ghafur - Gle Gapui (Sigli)
 */

// Sesuaikan kredensial berikut dengan environment server Anda
define('DB_HOST', 'localhost');
define('DB_NAME', 'absensi_unida');
define('DB_USER', 'root');
define('DB_PASS', '');

function getDBConnection() {
    static $pdo = null;
    if ($pdo === null) {
        try {
            $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4";
            $pdo = new PDO($dsn, DB_USER, DB_PASS, [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
            ]);
        } catch (PDOException $e) {
            die("Koneksi database gagal: " . $e->getMessage());
        }
    }
    return $pdo;
}

// Mulai session di seluruh aplikasi (aman dipanggil berkali-kali)
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/**
 * Helper: pastikan user sudah login, jika belum redirect ke login
 */
function requireLogin($role = null) {
    if (!isset($_SESSION['user_id'])) {
        header('Location: /login.php');
        exit;
    }
    if ($role !== null && $_SESSION['role'] !== $role) {
        header('Location: /login.php');
        exit;
    }
}

/**
 * Helper: sanitasi output HTML
 */
function h($str) {
    return htmlspecialchars($str ?? '', ENT_QUOTES, 'UTF-8');
}

/**
 * Helper: ambil pengaturan mata kuliah tunggal (di-cache per request)
 */
function getPengaturan() {
    static $pengaturan = null;
    if ($pengaturan === null) {
        $pdo = getDBConnection();
        $pengaturan = $pdo->query("SELECT * FROM pengaturan WHERE id = 1")->fetch();
        if (!$pengaturan) {
            // fallback jika baris pengaturan belum ada
            $pengaturan = [
                'nama_kampus' => 'Universitas Jabal Ghafur',
                'yayasan' => 'Yayasan Pembangunan Kampus Jabal Ghafur',
                'alamat_kampus' => 'Gle Gapui, Sigli',
                'fakultas' => 'Fakultas Teknologi Informasi',
                'jurusan' => 'Teknik Informatika',
                'prodi' => 'S1 Teknik Informatika',
                'kode_mk' => '-',
                'nama_mk' => 'Mata Kuliah',
                'dosen_pengampu' => '-',
                'nidn_dosen' => '',
                'no_wa_dosen' => '',
                'semester' => 'Ganjil',
                'tahun_ajaran' => date('Y') . '/' . (date('Y') + 1),
                'toleransi_menit' => 15,
            ];
        }
    }
    return $pengaturan;
}

/**
 * Helper: label status absensi
 */
function statusLabel($kode) {
    $map = ['H' => 'Hadir', 'I' => 'Izin', 'S' => 'Sakit', 'A' => 'Alpa'];
    return $map[$kode] ?? $kode;
}

/**
 * Helper: cek apakah tanggal tertentu adalah hari libur (tanggal merah)
 */
function isHariLibur($pdo, $tanggal) {
    static $cache = [];
    if (!array_key_exists($tanggal, $cache)) {
        $stmt = $pdo->prepare("SELECT id FROM hari_libur WHERE tanggal = :t LIMIT 1");
        $stmt->execute([':t' => $tanggal]);
        $cache[$tanggal] = (bool)$stmt->fetch();
    }
    return $cache[$tanggal];
}

/**
 * Helper: hitung skor & predikat kedisiplinan kehadiran mahasiswa
 * berdasarkan riwayat status 'H' (tepat waktu) vs 'H' dengan keterangan Terlambat vs total pertemuan tercatat.
 */
function hitungSkorDisiplin($pdo, $mahasiswaId) {
    $stmt = $pdo->prepare("SELECT status, keterangan FROM absensi WHERE mahasiswa_id = :id");
    $stmt->execute([':id' => $mahasiswaId]);
    $rows = $stmt->fetchAll();

    $total = count($rows);
    if ($total === 0) {
        return ['skor' => 0, 'predikat' => 'Belum Ada Data', 'warna' => 'text-slate-400', 'tepatWaktu' => 0, 'terlambat' => 0, 'total' => 0];
    }

    $tepatWaktu = 0; $terlambat = 0;
    foreach ($rows as $r) {
        if ($r['status'] === 'H') {
            if (($r['keterangan'] ?? '') === 'Terlambat') { $terlambat++; }
            else { $tepatWaktu++; }
        }
    }
    $skor = round((($tepatWaktu + 0.5 * $terlambat) / $total) * 100);

    if ($skor >= 90)      { $predikat = 'Sangat Disiplin';  $warna = 'text-emerald-400'; }
    elseif ($skor >= 75)  { $predikat = 'Disiplin';         $warna = 'text-sky-400'; }
    elseif ($skor >= 50)  { $predikat = 'Cukup Disiplin';   $warna = 'text-amber-400'; }
    else                  { $predikat = 'Perlu Ditingkatkan'; $warna = 'text-red-400'; }

    return ['skor' => $skor, 'predikat' => $predikat, 'warna' => $warna, 'tepatWaktu' => $tepatWaktu, 'terlambat' => $terlambat, 'total' => $total];
}

/**
 * Helper: buat kode verifikasi keaslian dokumen (untuk laporan resmi / cetak)
 * Kode bersifat deterministik terhadap input agar tetap sama saat dicetak ulang.
 */
function buatKodeVerifikasi(...$bagian) {
    $raw = implode('|', $bagian);
    return 'VRF-' . strtoupper(substr(hash('sha256', $raw), 0, 10));
}

/**
 * Helper: avatar ilustrasi sederhana berbasis jenis kelamin (bukan foto asli)
 * 'L' = laki-laki, 'P' = perempuan (memakai hijab)
 */
function avatarSvg($jenisKelamin) {
    if ($jenisKelamin === 'P') {
        return '<svg viewBox="0 0 64 64" xmlns="http://www.w3.org/2000/svg" style="width:100%;height:100%;display:block;">
            <circle cx="32" cy="32" r="32" fill="#ec4899"/>
            <path d="M20 25c0-8.5 5.4-15 12-15s12 6.5 12 15c0 3.2-1.1 6.1-3.3 8.4l4.6 21.6H18.7l4.6-21.6C21.1 31.1 20 28.2 20 25z" fill="#ffffff"/>
            <circle cx="32" cy="24" r="8.5" fill="#ec4899"/>
        </svg>';
    }
    return '<svg viewBox="0 0 64 64" xmlns="http://www.w3.org/2000/svg" style="width:100%;height:100%;display:block;">
        <circle cx="32" cy="32" r="32" fill="#0ea5e9"/>
        <circle cx="32" cy="24" r="10.5" fill="#ffffff"/>
        <path d="M13 57c1.2-13 9-21.5 19-21.5S49.8 44 51 57H13z" fill="#ffffff"/>
    </svg>';
}

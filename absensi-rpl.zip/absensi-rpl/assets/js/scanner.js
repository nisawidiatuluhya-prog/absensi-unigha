/**
 * scanner.js
 * Modul pemindai QR code real-time menggunakan library ZXing (via CDN)
 * Dipakai di halaman mahasiswa/scanner.php
 *
 * Alur:
 * 1. Meminta akses kamera pengguna
 * 2. Membaca QR code secara kontinu dari video stream
 * 3. Saat barcode terbaca, mengirim token ke proses_scan.php (AJAX/fetch)
 * 4. Menampilkan hasil verifikasi kehadiran secara real-time
 */

let codeReader = null;
let scanningActive = false;
let lastScannedToken = null;
let lastScanTime = 0;
const SCAN_COOLDOWN_MS = 4000; // hindari spam scan token yang sama

function initScanner(videoElementId, resultCallback) {
    if (typeof ZXing === 'undefined') {
        console.error('Library ZXing belum dimuat.');
        return;
    }

    codeReader = new ZXing.BrowserMultiFormatReader();
    scanningActive = true;

    codeReader.listVideoInputDevices()
        .then((videoInputDevices) => {
            if (videoInputDevices.length === 0) {
                resultCallback({ error: 'Kamera tidak ditemukan pada perangkat ini.' });
                return;
            }
            // Prioritaskan kamera belakang jika tersedia (untuk perangkat mobile)
            const backCam = videoInputDevices.find(d => /back|belakang|rear/i.test(d.label));
            const deviceId = backCam ? backCam.deviceId : videoInputDevices[0].deviceId;

            codeReader.decodeFromVideoDevice(deviceId, videoElementId, (result, err) => {
                if (!scanningActive) return;

                if (result) {
                    const token = result.getText();
                    const now = Date.now();
                    if (token === lastScannedToken && (now - lastScanTime) < SCAN_COOLDOWN_MS) {
                        return; // cegah duplikasi scan berturut-turut
                    }
                    lastScannedToken = token;
                    lastScanTime = now;
                    handleScanResult(token, resultCallback);
                }
                // NotFoundException muncul terus-menerus saat tidak ada barcode di frame — abaikan
            });
        })
        .catch((err) => {
            resultCallback({ error: 'Gagal mengakses kamera: ' + err.message });
        });
}

function handleScanResult(token, resultCallback) {
    fetch('proses_scan.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: 'barcode_token=' + encodeURIComponent(token)
    })
    .then(res => res.json())
    .then(data => resultCallback(data))
    .catch(() => resultCallback({ error: 'Gagal terhubung ke server. Silakan coba lagi.' }));
}

function stopScanner() {
    scanningActive = false;
    if (codeReader) {
        codeReader.reset();
    }
}

// Bunyikan notifikasi singkat (opsional, tanpa audio file eksternal)
function beep(success = true) {
    try {
        const ctx = new (window.AudioContext || window.webkitAudioContext)();
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.frequency.value = success ? 880 : 220;
        gain.gain.value = 0.1;
        osc.start();
        setTimeout(() => { osc.stop(); ctx.close(); }, 150);
    } catch (e) { /* abaikan jika audio context tidak didukung */ }
}

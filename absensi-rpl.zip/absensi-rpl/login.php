<?php
require_once __DIR__ . '/config/database.php';
$p = getPengaturan();

$error = '';
$activeRole = ($_GET['role'] ?? $_POST['expected_role'] ?? 'mahasiswa') === 'admin' ? 'admin' : 'mahasiswa';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $expectedRole = ($_POST['expected_role'] ?? 'mahasiswa') === 'admin' ? 'admin' : 'mahasiswa';
    $activeRole = $expectedRole;

    if ($username === '' || $password === '') {
        $error = 'Username dan password wajib diisi.';
    } else {
        $pdo = getDBConnection();
        $stmt = $pdo->prepare("SELECT * FROM users WHERE username = :u LIMIT 1");
        $stmt->execute([':u' => $username]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['password'])) {
            if ($user['role'] !== $expectedRole) {
                $error = $expectedRole === 'admin'
                    ? 'Akun ini bukan akun Admin. Silakan gunakan tab "Login Mahasiswa".'
                    : 'Akun ini bukan akun Mahasiswa. Silakan gunakan tab "Login Admin".';
            } else {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['username'] = $user['username'];
                $_SESSION['role'] = $user['role'];

                header('Location: ' . ($user['role'] === 'admin' ? 'admin/dashboard.php' : 'mahasiswa/dashboard.php'));
                exit;
            }
        } else {
            $error = 'Username atau password salah.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Masuk | Absensi Unigha</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<script src="https://cdn.tailwindcss.com"></script>
<link rel="stylesheet" href="assets/css/style.css">
</head>
<body class="min-h-screen flex items-center justify-center px-4 py-10">
  <div class="w-full max-w-md">
    <div class="text-center mb-6">
      <div class="w-14 h-14 mx-auto mb-3 rounded-xl bg-gradient-to-br from-sky-400 to-indigo-500 flex items-center justify-center font-bold text-slate-900 text-lg">AU</div>
      <h1 class="text-xl font-bold text-white">Absensi Unigha</h1>
      <p class="text-sm text-slate-400 mt-1"><?= h($p['nama_kampus']) ?> — <?= h($p['nama_mk']) ?></p>
    </div>

    <!-- TAB PILIHAN ROLE -->
    <div class="flex gap-2 mb-5">
      <button type="button" id="tab-mhs" onclick="pilihRole('mahasiswa')" class="role-tab">🎓 Login Mahasiswa</button>
      <button type="button" id="tab-admin" onclick="pilihRole('admin')" class="role-tab">🛠️ Login Admin</button>
    </div>

    <div class="card-navy p-8">
      <?php if ($error): ?>
        <div class="mb-4 px-4 py-3 rounded-lg bg-red-900/40 border border-red-700/40 text-red-300 text-sm">
          <?= h($error) ?>
        </div>
      <?php endif; ?>

      <p class="text-xs font-semibold text-sky-400 uppercase tracking-wide mb-3" id="form-label">Masuk sebagai Mahasiswa</p>
      <form method="POST" class="space-y-4">
        <input type="hidden" name="expected_role" id="expected_role" value="<?= h($activeRole) ?>">
        <div>
          <label class="text-sm text-slate-400 block mb-1">Username</label>
          <input type="text" name="username" required autofocus
            class="w-full px-4 py-2.5 rounded-lg bg-slate-800 border border-white/10 text-white focus:outline-none focus:border-sky-400"
            placeholder="Masukkan username">
        </div>
        <div>
          <label class="text-sm text-slate-400 block mb-1">Password</label>
          <input type="password" name="password" required
            class="w-full px-4 py-2.5 rounded-lg bg-slate-800 border border-white/10 text-white focus:outline-none focus:border-sky-400"
            placeholder="Masukkan password">
        </div>
        <button type="submit"
          class="w-full py-2.5 rounded-lg bg-sky-500 hover:bg-sky-400 text-slate-900 font-semibold transition">
          Masuk
        </button>
      </form>

      <div id="daftar-box">
        <div class="flex items-center gap-3 my-6">
          <div class="flex-1 h-px bg-white/10"></div>
          <span class="text-xs text-slate-500">atau</span>
          <div class="flex-1 h-px bg-white/10"></div>
        </div>
        <p class="text-xs font-semibold text-slate-400 uppercase tracking-wide mb-3 text-center">Belum Punya Akun?</p>
        <a href="register.php"
          class="block w-full text-center py-2.5 rounded-lg border border-sky-400/40 text-sky-300 hover:bg-sky-500/10 font-semibold transition">
          Daftar sebagai Mahasiswa
        </a>
      </div>

      <div class="mt-4 px-4 py-3 rounded-lg bg-slate-800/60 border border-white/10 text-center">
        <p class="text-xs text-slate-400 mb-1">🔑 Akun Admin Default</p>
        <p class="text-sm text-slate-200">Username: <span class="font-semibold text-sky-300">admin</span></p>
        <p class="text-sm text-slate-200">Password: <span class="font-semibold text-sky-300">admin123</span></p>
      </div>
    </div>

    <p class="text-center text-xs text-slate-600 mt-6">
      <a href="index.php" class="hover:text-slate-400">&larr; Kembali ke Beranda</a>
    </p>
  </div>

  <script>
    function pilihRole(role) {
      document.getElementById('expected_role').value = role;
      document.getElementById('tab-mhs').classList.toggle('active', role === 'mahasiswa');
      document.getElementById('tab-admin').classList.toggle('active', role === 'admin');
      document.getElementById('form-label').textContent = role === 'admin' ? 'Masuk sebagai Admin' : 'Masuk sebagai Mahasiswa';
      document.getElementById('daftar-box').style.display = role === 'admin' ? 'none' : 'block';
    }
    pilihRole('<?= h($activeRole) ?>');
  </script>
</body>
</html>

# Absensi Unigha

Sistem informasi absensi mahasiswa berbasis QR Code, dirancang khusus untuk
**satu mata kuliah** (contoh: Rekayasa Perangkat Lunak) yang memiliki
**beberapa kelas paralel** (default 5 kelas), di **Universitas Jabal Ghafur —
Gle Gapui (Sigli)**.

## Perubahan Utama dari Versi Sebelumnya

- Nama aplikasi menjadi **Absensi Unigha**.
- Struktur data disederhanakan: satu mata kuliah (diatur di menu
  **Pengaturan**), banyak kelas (menu **Data Kelas**) — bukan lagi banyak
  mata kuliah + banyak dosen.
- **Data Mahasiswa** kini dikelompokkan rapi per kelas (bukan per
  semester+kelas), lengkap dengan kolom jenis kelamin dan alamat.
- **Laporan Absensi Resmi** dibuat per kelas dengan format DHMD (Daftar
  Hadir Mahasiswa dan Dosen) — kop yayasan/kampus, info matakuliah/ruang/
  dosen, tabel matriks tanggal pertemuan dengan simbol H/I/S/A,
  rekapitulasi akhir per mahasiswa, **Alfa otomatis untuk pertemuan yang
  lewat tanpa catatan**, serta **kode/QR verifikasi keaslian dokumen**.
- **Kartu Mahasiswa Digital** kini memakai **QR Code** (bukan barcode)
  dan tersedia baik di sisi mahasiswa (self-view) maupun admin (menu
  **Kartu Digital** untuk satu mahasiswa, dan **Cetak Massal Kartu**
  untuk mencetak satu kelas sekaligus).
- Status kehadiran bertambah menjadi **H / I / S / A** (Hadir, Izin,
  Sakit, Alpa).
- **Kalender Hari Libur**: admin bisa menandai tanggal libur agar tidak
  dihitung sebagai pertemuan/Alfa, dan mahasiswa otomatis tidak bisa
  absen pada tanggal tersebut.
- **Pengumuman**: admin dapat mem-broadcast info (misal dosen
  berhalangan hadir) ke semua kelas atau kelas tertentu; muncul sebagai
  notifikasi lonceng di dashboard mahasiswa.
- **Live Monitoring**: admin dapat memantau aktivitas absensi hari ini
  secara real-time (auto-refresh tiap 8 detik) di menu **Live
  Monitoring**.
- **Skor Kedisiplinan (Gamifikasi)**: dashboard mahasiswa menampilkan
  skor & predikat kedisiplinan (Sangat Disiplin/Disiplin/Cukup
  Disiplin/Perlu Ditingkatkan) berdasarkan riwayat ketepatan waktu.
- **Halaman Login** dipecah menjadi dua tab jelas: **Login Admin** dan
  **Login Mahasiswa**.
- **Landing page** dirombak dengan desain yang lebih rapi dan menampilkan
  ringkasan informasi mata kuliah yang aktif.
- **Dashboard Admin** dilengkapi grafik batang status kehadiran, diagram
  bulat (pie/donut) distribusi kehadiran, perbandingan hadir vs tidak
  hadir hari ini, dan perbandingan gender.
- **Pengajuan Izin** kini bisa langsung dikirim ke dosen melalui tautan
  WhatsApp (nomor dosen diatur di menu Pengaturan).
- **Menu bergaya "hamburger" di HP**: sidebar admin & mahasiswa kini bisa
  dibuka/ditutup lewat ikon ☰ di HP — sebelumnya menu benar-benar
  tersembunyi tanpa cara membukanya di layar kecil.
- **Panduan Admin**: halaman panduan sungguhan (bukan lagi sekadar
  `alert()` popup) dengan alur langkah bernomor dan FAQ pemecahan masalah.
- **Ekspor Laporan ke Excel & Word**: tombol unduh `.xls` dan `.doc` di
  halaman Laporan Resmi, selain cetak PDF via browser.
- **Unduh Kartu (PNG)**: tombol unduh gambar kartu digital, tersedia di
  dashboard mahasiswa dan halaman Kartu Digital admin.
- **Surat Izin**: kini bisa diunduh sebagai gambar (PNG), dan tab
  WhatsApp otomatis terbuka ke nomor dosen dengan pesan siap kirim
  setelah pengajuan berhasil.
- **Kalender Hari Libur visual**: grid kalender bulanan dengan tanggal
  merah yang bisa ditandai/dihapus langsung dengan klik.
- **Widget Jadwal & Jam Masuk** + **Tren Kehadiran 14 Hari (Chart.js)**
  ditambahkan ke Dashboard Admin.
- **Avatar berbasis gender**: kartu mahasiswa kini menampilkan ilustrasi
  avatar laki-laki/perempuan (berhijab) alih-alih inisial huruf.
- Rebranding penuh menjadi **Absensi Unigha**, dosen pengampu default
  diganti ke Zikrul Khalid, S.T., M.T., nomor WhatsApp dosen default
  diisi otomatis.

## Struktur Folder

```
absensi-rpl/
├── index.php                  Landing page
├── login.php                  Login (tab Admin / Mahasiswa)
├── register.php                Registrasi mandiri mahasiswa
├── logout.php
├── database.sql                Skema database lengkap + data awal
├── config/
│   └── database.php             Koneksi PDO + helper (getPengaturan, dsb)
├── assets/
│   ├── css/style.css
│   └── js/scanner.js            Modul scanner QR (ZXing)
├── admin/
│   ├── dashboard.php            Statistik & grafik
│   ├── monitoring.php           Live monitoring absensi hari ini (auto-refresh)
│   ├── kelas.php                Data Kelas (CRUD 5 kelas)
│   ├── mahasiswa.php            Data Mahasiswa per kelas
│   ├── kartu.php                Kartu digital + QR (view/print per mahasiswa)
│   ├── kartu_qr.php             Cetak massal kartu QR per kelas
│   ├── izin.php                 Validasi surat izin/sakit
│   ├── pengumuman.php           Broadcast pengumuman ke mahasiswa
│   ├── hari_libur.php           Kalender hari libur (dikecualikan dari Alfa)
│   ├── laporan.php              Laporan resmi (DHMD) per kelas + kode verifikasi
│   └── pengaturan.php           Data mata kuliah, dosen, kampus
└── mahasiswa/
    ├── dashboard.php            Kartu digital + ringkasan kehadiran + skor disiplin
    ├── scanner.php               Scan QR real-time
    ├── proses_scan.php           Endpoint AJAX pencatatan absensi
    ├── ajukan_izin.php           Form izin/sakit + kirim WA ke dosen
    ├── kontak_dosen.php          Info kontak dosen pengampu
    ├── profil.php                Profil, ubah password & riwayat absensi
    └── panduan.php                Panduan penggunaan
```

## Instalasi

1. Buat database dengan mengimpor `database.sql` (otomatis membuat
   database `absensi_unigha`, tabel, 1 akun admin, dan 5 kelas contoh).
2. Sesuaikan kredensial di `config/database.php`.
3. Arahkan root folder `absensi-rpl/` ke web server (Apache/Nginx +
   PHP 8+, ekstensi `pdo_mysql` aktif).
4. Login sebagai admin (default: `admin` / `admin123`), lalu buka menu
   **Pengaturan** untuk mengisi data mata kuliah, dosen, dan nomor
   WhatsApp dosen sesuai kondisi sebenarnya.
5. Sesuaikan/lengkapi 5 kelas di menu **Data Kelas**, lalu tambahkan
   mahasiswa di menu **Data Mahasiswa** (atau biarkan mahasiswa
   mendaftar sendiri lewat halaman **Daftar**).

## Catatan Teknis

- QR code dibuat di sisi klien memakai library `qrcodejs` (CDN),
  dan dipindai memakai `@zxing/library` (CDN) yang sudah mendukung
  format QR maupun 1D barcode.
- Validasi absensi mencocokkan hari & jam scan dengan jadwal kelas
  mahasiswa (tabel `kelas`), dengan toleransi keterlambatan yang bisa
  diatur di menu Pengaturan.
- Status **S (Sakit)** dan **I (Izin)** pada tabel absensi otomatis
  terisi ketika admin menyetujui pengajuan surat izin/sakit terkait.

---

## Data Kelas & Mahasiswa

Diambil dari lembar **Daftar Hadir Mahasiswa (DHMD)** FTI-03/02, /03, /04.

| Kelas | Ruang/Kode | Jadwal | Jumlah |
|---|---|---|---|
| 5.2 | FTI-03/02 | Sabtu 14:30–17:00 | 30 |
| 5.3 | FTI-03/03 | *(belum diketahui)* | 20 |
| 5.4 | FTI-03/04 | Jumat 08:30–11:00 | 27 |
| 5.5 | *(belum diketahui)* | *(belum diketahui)* | 32 |

Total 109 mahasiswa. NIM asli dipakai apa adanya. Kolom L/P diisi berdasarkan perkiraan
dari nama — mohon dicek lagi lewat menu admin.

### Akun login dibuat sendiri oleh mahasiswa
- Kolom `mahasiswa.user_id` boleh `NULL` = data ada, akun belum dibuat.
- Di `register.php` mahasiswa cukup isi **NIM + username + password**. Sistem mencocokkan NIM
  lalu menyambungkan akun ke data resmi (nama & kelas dari dosen, tidak bisa diubah sendiri).
- Admin → Data Mahasiswa punya kolom **Akun**: `Belum daftar` (kuning) / `Aktif` (hijau).
- Form tambah mahasiswa di admin: username & password **opsional**.

### Cara import
Import `database.sql` — satu file ini sudah lengkap: struktur tabel, akun admin,
4 kelas, dan semua mahasiswa. Kalau database `absensi_unida` sudah ada sebelumnya,
`DROP DATABASE absensi_unida;` dulu baru import ulang, karena file ini membuat
database dari awal (bukan tambahan).

### Catatan
Lembar DHMD menyebut mata kuliah **Konsep Data Warehouse dan Data Mining (FTI510)**
dengan pengasuh **Tri Mulya Dharma, S.Kom., M.T.**, sedangkan tabel `pengaturan` masih
berisi *Rekayasa Perangkat Lunak* / *Zikrul Khalid, S.T., M.T.* Silakan disesuaikan
lewat menu Admin → Pengaturan bila perlu.

---

## Fitur Baru: Kirim Surat, Lihat Surat, Pengumuman & Tugas

### Mahasiswa — kirim surat izin/sakit
Setelah surat berhasil dibuat, di bawah pratinjau surat ada dua tombol:
- **✉️ Kirim ke Dosen** — membuka aplikasi email dengan isi surat sudah terisi (perlu **Email Dosen** diisi dulu di Admin → Pengaturan).
- **📲 Kirim via WhatsApp** — membuka WhatsApp dengan pesan siap kirim ke nomor dosen.

Surat tetap otomatis tersimpan di sistem begitu diajukan — dua tombol ini cuma opsi tambahan untuk mengirim salinannya langsung.

### Admin — lihat surat saat validasi izin
Di Admin → Validasi Surat Izin, sekarang ada tombol **"Lihat Surat"** di tiap baris. Ini membuka
surat resmi lengkap (bisa dicetak/diunduh) dan admin bisa langsung Setujui/Tolak dari halaman itu juga.

### Dosen — Pengumuman & Tugas dengan lampiran
Admin → Pengumuman sekarang punya dua tipe: **Pengumuman** dan **Tugas**. Tugas bisa diberi
batas waktu (deadline) dan lampiran file (PDF, Word, Excel, gambar, ZIP — maks 10MB).

### Mahasiswa — halaman "Pemberitahuan Dosen" (bukan lonceng)
Lonceng notifikasi di dashboard sudah dihapus. Sekarang ada menu sidebar baru
**📌 Pemberitahuan Dosen** yang menampilkan semua pengumuman & tugas dari dosen, bisa difilter
per tipe, lengkap dengan status deadline dan tombol unduh lampiran. Di dashboard hanya ada bar
ringkas yang mengarah ke halaman ini.

**Catatan:** fitur upload lampiran butuh folder `assets/uploads/pengumuman/` bisa ditulis
oleh web server (permission 755 biasanya cukup).

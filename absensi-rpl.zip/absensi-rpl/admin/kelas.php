<?php
require_once __DIR__ . '/../config/database.php';
requireLogin('admin');
$pdo = getDBConnection();
$p = getPengaturan();

$msg = ''; $msgType = 'success';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'tambah') {
    $nama = trim($_POST['nama_kelas'] ?? '');
    $ruang = trim($_POST['ruang'] ?? '');
    $hari = $_POST['hari'] ?? 'Senin';
    $mulai = $_POST['jam_mulai'] ?? '08:00';
    $selesai = $_POST['jam_selesai'] ?? '10:00';

    if ($nama === '') {
        $msg = 'Nama kelas wajib diisi.'; $msgType = 'error';
    } else {
        try {
            $stmt = $pdo->prepare("INSERT INTO kelas (nama_kelas, ruang, hari, jam_mulai, jam_selesai) VALUES (:n, :r, :h, :m, :s)");
            $stmt->execute([':n' => $nama, ':r' => $ruang, ':h' => $hari, ':m' => $mulai, ':s' => $selesai]);
            $msg = "Kelas \"$nama\" berhasil ditambahkan.";
        } catch (Exception $e) {
            $msg = 'Gagal menambahkan kelas (nama kelas mungkin sudah ada).'; $msgType = 'error';
        }
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'edit') {
    $id = (int)$_POST['id'];
    $stmt = $pdo->prepare("UPDATE kelas SET nama_kelas=:n, ruang=:r, hari=:h, jam_mulai=:m, jam_selesai=:s WHERE id=:id");
    $stmt->execute([
        ':n' => trim($_POST['nama_kelas']), ':r' => trim($_POST['ruang']),
        ':h' => $_POST['hari'], ':m' => $_POST['jam_mulai'], ':s' => $_POST['jam_selesai'], ':id' => $id
    ]);
    $msg = 'Data kelas berhasil diperbarui.';
}

if (isset($_GET['hapus'])) {
    $id = (int)$_GET['hapus'];
    $cek = $pdo->prepare("SELECT COUNT(*) c FROM mahasiswa WHERE kelas_id = :id");
    $cek->execute([':id' => $id]);
    if ($cek->fetch()['c'] > 0) {
        $msg = 'Kelas tidak dapat dihapus karena masih memiliki mahasiswa terdaftar.'; $msgType = 'error';
    } else {
        $pdo->prepare("DELETE FROM kelas WHERE id = :id")->execute([':id' => $id]);
        $msg = 'Kelas berhasil dihapus.';
    }
}

$kelasList = $pdo->query("
    SELECT k.*, (SELECT COUNT(*) FROM mahasiswa m WHERE m.kelas_id = k.id) jumlah_mhs
    FROM kelas k ORDER BY k.nama_kelas
")->fetchAll();

$pageTitle = 'Data Kelas';
include __DIR__ . '/_layout_top.php';
?>

<div class="flex flex-col md:flex-row md:items-center justify-between gap-3 mb-6">
  <div>
    <h1 class="text-2xl font-bold text-white">Data Kelas — <?= h($p['nama_mk']) ?></h1>
    <p class="text-slate-400 text-sm">Kelola kelas paralel untuk mata kuliah ini beserta jadwalnya</p>
  </div>
  <button onclick="document.getElementById('modalTambah').classList.remove('hidden')"
    class="px-4 py-2 rounded-lg bg-sky-500 hover:bg-sky-400 text-slate-900 font-semibold text-sm">
    + Tambah Kelas
  </button>
</div>

<?php if ($msg): ?>
  <div class="mb-5 px-4 py-3 rounded-lg text-sm <?= $msgType === 'error' ? 'bg-red-900/40 border border-red-700/40 text-red-300' : 'bg-emerald-900/40 border border-emerald-700/40 text-emerald-300' ?>">
    <?= h($msg) ?>
  </div>
<?php endif; ?>

<div class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
  <?php if (empty($kelasList)): ?>
    <p class="text-slate-500 text-sm">Belum ada data kelas.</p>
  <?php endif; ?>
  <?php foreach ($kelasList as $k): ?>
    <div class="card-navy p-5">
      <div class="flex items-start justify-between mb-3">
        <div>
          <p class="text-white font-semibold"><?= h($k['nama_kelas']) ?></p>
          <p class="text-xs text-slate-500"><?= h($k['ruang'] ?: '-') ?></p>
        </div>
        <span class="badge badge-H"><?= (int)$k['jumlah_mhs'] ?> mhs</span>
      </div>
      <p class="text-sm text-slate-400 mb-4"><?= h($k['hari']) ?>, <?= substr($k['jam_mulai'],0,5) ?>–<?= substr($k['jam_selesai'],0,5) ?></p>
      <div class="flex gap-3 text-xs">
        <button onclick='bukaEdit(<?= json_encode($k) ?>)' class="text-sky-400 hover:text-sky-300">Edit</button>
        <a href="?hapus=<?= $k['id'] ?>" onclick="return confirm('Hapus kelas ini?')" class="text-red-400 hover:text-red-300">Hapus</a>
        <a href="mahasiswa.php?kelas=<?= $k['id'] ?>" class="text-slate-400 hover:text-white">Lihat Mahasiswa &rarr;</a>
      </div>
    </div>
  <?php endforeach; ?>
</div>

<!-- MODAL TAMBAH -->
<div id="modalTambah" class="hidden fixed inset-0 bg-black/60 flex items-center justify-center p-4 z-50">
  <div class="card-navy p-6 w-full max-w-md">
    <p class="font-semibold text-white mb-4">Tambah Kelas Baru</p>
    <form method="POST" class="space-y-3">
      <input type="hidden" name="action" value="tambah">
      <input type="text" name="nama_kelas" placeholder="Nama Kelas (cth: FTI-03/02 - F)" required class="w-full px-3 py-2 rounded-lg bg-slate-800 border border-white/10 text-white text-sm">
      <input type="text" name="ruang" placeholder="Ruang" class="w-full px-3 py-2 rounded-lg bg-slate-800 border border-white/10 text-white text-sm">
      <div class="grid grid-cols-3 gap-2">
        <select name="hari" class="px-3 py-2 rounded-lg bg-slate-800 border border-white/10 text-white text-sm">
          <?php foreach (['Senin','Selasa','Rabu','Kamis','Jumat','Sabtu'] as $h): ?><option value="<?= $h ?>"><?= $h ?></option><?php endforeach; ?>
        </select>
        <input type="time" name="jam_mulai" value="08:00" required class="px-3 py-2 rounded-lg bg-slate-800 border border-white/10 text-white text-sm">
        <input type="time" name="jam_selesai" value="10:00" required class="px-3 py-2 rounded-lg bg-slate-800 border border-white/10 text-white text-sm">
      </div>
      <div class="flex gap-3 pt-2">
        <button type="button" onclick="document.getElementById('modalTambah').classList.add('hidden')"
          class="flex-1 py-2 rounded-lg bg-slate-700 hover:bg-slate-600 text-white text-sm">Batal</button>
        <button type="submit" class="flex-1 py-2 rounded-lg bg-sky-500 hover:bg-sky-400 text-slate-900 font-semibold text-sm">Simpan</button>
      </div>
    </form>
  </div>
</div>

<!-- MODAL EDIT -->
<div id="modalEdit" class="hidden fixed inset-0 bg-black/60 flex items-center justify-center p-4 z-50">
  <div class="card-navy p-6 w-full max-w-md">
    <p class="font-semibold text-white mb-4">Edit Kelas</p>
    <form method="POST" class="space-y-3">
      <input type="hidden" name="action" value="edit">
      <input type="hidden" name="id" id="edit_id">
      <input type="text" name="nama_kelas" id="edit_nama" required class="w-full px-3 py-2 rounded-lg bg-slate-800 border border-white/10 text-white text-sm">
      <input type="text" name="ruang" id="edit_ruang" class="w-full px-3 py-2 rounded-lg bg-slate-800 border border-white/10 text-white text-sm">
      <div class="grid grid-cols-3 gap-2">
        <select name="hari" id="edit_hari" class="px-3 py-2 rounded-lg bg-slate-800 border border-white/10 text-white text-sm">
          <?php foreach (['Senin','Selasa','Rabu','Kamis','Jumat','Sabtu'] as $h): ?><option value="<?= $h ?>"><?= $h ?></option><?php endforeach; ?>
        </select>
        <input type="time" name="jam_mulai" id="edit_mulai" required class="px-3 py-2 rounded-lg bg-slate-800 border border-white/10 text-white text-sm">
        <input type="time" name="jam_selesai" id="edit_selesai" required class="px-3 py-2 rounded-lg bg-slate-800 border border-white/10 text-white text-sm">
      </div>
      <div class="flex gap-3 pt-2">
        <button type="button" onclick="document.getElementById('modalEdit').classList.add('hidden')"
          class="flex-1 py-2 rounded-lg bg-slate-700 hover:bg-slate-600 text-white text-sm">Batal</button>
        <button type="submit" class="flex-1 py-2 rounded-lg bg-sky-500 hover:bg-sky-400 text-slate-900 font-semibold text-sm">Simpan Perubahan</button>
      </div>
    </form>
  </div>
</div>

<script>
function bukaEdit(k) {
  document.getElementById('edit_id').value = k.id;
  document.getElementById('edit_nama').value = k.nama_kelas;
  document.getElementById('edit_ruang').value = k.ruang || '';
  document.getElementById('edit_hari').value = k.hari;
  document.getElementById('edit_mulai').value = k.jam_mulai.substring(0,5);
  document.getElementById('edit_selesai').value = k.jam_selesai.substring(0,5);
  document.getElementById('modalEdit').classList.remove('hidden');
}
</script>

<?php include __DIR__ . '/_layout_bottom.php'; ?>

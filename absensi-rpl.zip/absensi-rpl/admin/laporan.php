<?php
require_once __DIR__ . '/../config/database.php';
requireLogin('admin');
$pdo = getDBConnection();
$p = getPengaturan();

$kelasOptions = $pdo->query("SELECT * FROM kelas ORDER BY nama_kelas")->fetchAll();
if (empty($kelasOptions)) {
    $filterKelasId = 0; $kelasAktif = null;
} else {
    $filterKelasId = (int)($_GET['kelas'] ?? $kelasOptions[0]['id']);
    $kelasAktif = null;
    foreach ($kelasOptions as $k) { if ((int)$k['id'] === $filterKelasId) { $kelasAktif = $k; break; } }
    if (!$kelasAktif) { $kelasAktif = $kelasOptions[0]; $filterKelasId = (int)$kelasAktif['id']; }
}
$filterBulan = $_GET['bulan'] ?? date('Y-m');

// Tanggal-tanggal pertemuan pada bulan terpilih yang jatuh pada hari kelas tsb
// (tanggal yang ditandai sebagai hari libur otomatis dilewati / tidak dihitung)
$tanggalPertemuan = [];
if ($kelasAktif) {
    $hariMapAngka = ['Minggu'=>0,'Senin'=>1,'Selasa'=>2,'Rabu'=>3,'Kamis'=>4,'Jumat'=>5,'Sabtu'=>6];
    $targetDow = $hariMapAngka[$kelasAktif['hari']] ?? 1;
    $awalBulan = new DateTime($filterBulan . '-01');
    $akhirBulan = (clone $awalBulan)->modify('last day of this month');
    $cursor = clone $awalBulan;
    while ($cursor <= $akhirBulan) {
        $tglStr = $cursor->format('Y-m-d');
        if ((int)$cursor->format('w') === $targetDow && !isHariLibur($pdo, $tglStr)) {
            $tanggalPertemuan[] = $tglStr;
        }
        $cursor->modify('+1 day');
    }
}
$hariIniStr = date('Y-m-d');

// Mahasiswa di kelas ini
$mhsStmt = $pdo->prepare("SELECT * FROM mahasiswa WHERE kelas_id = :kid ORDER BY nama");
$mhsStmt->execute([':kid' => $filterKelasId]);
$mhsList = $mhsStmt->fetchAll();

// Absensi bulan ini untuk kelas ini, diindeks [mahasiswa_id][tanggal] = status
$absensiMap = [];
if ($filterKelasId) {
    $absStmt = $pdo->prepare("
        SELECT mahasiswa_id, tanggal, status FROM absensi
        WHERE kelas_id = :kid AND DATE_FORMAT(tanggal, '%Y-%m') = :bulan
    ");
    $absStmt->execute([':kid' => $filterKelasId, ':bulan' => $filterBulan]);
    foreach ($absStmt as $row) {
        $absensiMap[$row['mahasiswa_id']][$row['tanggal']] = $row['status'];
    }
}

$pageTitle = 'Laporan Absensi Resmi';
include __DIR__ . '/_layout_top.php';
?>

<div class="flex flex-col md:flex-row md:items-center justify-between gap-3 mb-6 print:hidden">
  <div>
    <h1 class="text-2xl font-bold text-white">Laporan Absensi Resmi (DHMD)</h1>
    <p class="text-slate-400 text-sm">Daftar Hadir Mahasiswa dan Dosen — dibuat per kelas</p>
  </div>
  <div class="flex flex-wrap gap-2">
    <button onclick="window.print()" class="px-4 py-2 rounded-lg bg-slate-700 hover:bg-slate-600 text-white text-sm">🖨️ PDF / Cetak</button>
    <?php if ($kelasAktif): ?>
      <a href="export_laporan_excel.php?kelas=<?= $filterKelasId ?>&bulan=<?= h($filterBulan) ?>" class="px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-sm">📊 Unduh Excel</a>
      <a href="export_laporan_word.php?kelas=<?= $filterKelasId ?>&bulan=<?= h($filterBulan) ?>" class="px-4 py-2 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-sm">📄 Unduh Word</a>
    <?php endif; ?>
  </div>
</div>

<form method="GET" class="card-navy p-4 mb-6 flex flex-wrap gap-3 items-end print:hidden">
  <div>
    <label class="text-xs text-slate-400 block mb-1">Kelas</label>
    <select name="kelas" class="px-3 py-2 rounded-lg bg-slate-800 border border-white/10 text-white text-sm">
      <?php foreach ($kelasOptions as $k): ?>
        <option value="<?= $k['id'] ?>" <?= $filterKelasId == $k['id'] ? 'selected' : '' ?>><?= h($k['nama_kelas']) ?></option>
      <?php endforeach; ?>
    </select>
  </div>
  <div>
    <label class="text-xs text-slate-400 block mb-1">Bulan</label>
    <input type="month" name="bulan" value="<?= h($filterBulan) ?>" class="px-3 py-2 rounded-lg bg-slate-800 border border-white/10 text-white text-sm">
  </div>
  <button class="px-4 py-2 rounded-lg bg-sky-500 hover:bg-sky-400 text-slate-900 font-semibold text-sm">Tampilkan</button>
</form>

<?php if (!$kelasAktif): ?>
  <p class="text-slate-500 text-sm">Belum ada data kelas. Tambahkan kelas terlebih dahulu di menu Data Kelas.</p>
<?php else: ?>

<div class="card-navy p-6 overflow-x-auto print-area">
  <!-- KOP RESMI -->
  <div class="official-doc bg-white text-slate-900 p-5 rounded-lg mb-4" style="border:3px double #0f172a;">
    <div class="flex items-center gap-4 border-b-4 border-slate-800 pb-3 mb-3">
      <div class="w-16 h-16 rounded-full border-2 border-slate-800 flex items-center justify-center font-bold text-xs text-center shrink-0">
        UJG<br>SIGLI
      </div>
      <div class="text-center flex-1">
        <p class="text-xs font-semibold uppercase"><?= h($p['yayasan']) ?></p>
        <p class="text-base font-bold uppercase"><?= h($p['nama_kampus']) ?> — <?= h($p['alamat_kampus']) ?></p>
        <p class="text-sm font-bold underline uppercase mt-1">Daftar Hadir Mahasiswa dan Dosen</p>
        <p class="text-xs font-semibold">( D H M D )</p>
      </div>
    </div>
    <p class="text-[11px] text-right mb-2">Nomor: <?= h(strtoupper(substr($kelasAktif['nama_kelas'],0,8))) ?>/DHMD/<?= h($p['kode_mk']) ?>/<?= date('m/Y', strtotime($filterBulan.'-01')) ?></p>
    <div class="grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-1 text-xs mb-2">
      <p><strong>Matakuliah</strong> &nbsp; : &nbsp; <?= h($p['kode_mk']) ?> — <?= h($p['nama_mk']) ?></p>
      <p><strong>Hari / Jam</strong> &nbsp; : &nbsp; <?= h($kelasAktif['hari']) ?>, <?= substr($kelasAktif['jam_mulai'],0,5) ?>–<?= substr($kelasAktif['jam_selesai'],0,5) ?></p>
      <p><strong>Tempat / Ruang / Kelas</strong> &nbsp; : &nbsp; <?= h($kelasAktif['ruang'] ?: '-') ?> / <?= h($kelasAktif['nama_kelas']) ?></p>
      <p><strong>Jurusan / Prodi</strong> &nbsp; : &nbsp; <?= h($p['jurusan']) ?> / <?= h($p['prodi']) ?></p>
      <p><strong>Pengasuh / Dosen</strong> &nbsp; : &nbsp; <?= h($p['dosen_pengampu']) ?></p>
      <p><strong>Semester</strong> &nbsp; : &nbsp; <?= h($p['semester']) ?> — <?= h($p['tahun_ajaran']) ?></p>
    </div>
    <p class="text-xs">Bulan: <strong><?= date('F Y', strtotime($filterBulan . '-01')) ?></strong></p>
  </div>

  <!-- TABEL MATRIKS ABSENSI -->
  <div class="official-doc bg-white text-slate-900 p-2 rounded-lg overflow-x-auto">
    <table class="dhmd-table">
      <thead>
        <tr>
          <th rowspan="2">No</th>
          <th rowspan="2">Nama</th>
          <th rowspan="2">NIM</th>
          <th colspan="<?= max(count($tanggalPertemuan),1) ?>">Tanggal Pertemuan</th>
          <th colspan="4">Rekap</th>
        </tr>
        <tr>
          <?php if (empty($tanggalPertemuan)): ?>
            <th>-</th>
          <?php else: foreach ($tanggalPertemuan as $tgl): ?>
            <th><?= date('d/m', strtotime($tgl)) ?></th>
          <?php endforeach; endif; ?>
          <th>H</th><th>I</th><th>S</th><th>A</th>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($mhsList)): ?>
          <tr><td colspan="<?= 3 + max(count($tanggalPertemuan),1) + 4 ?>">Belum ada mahasiswa pada kelas ini.</td></tr>
        <?php endif; ?>
        <?php foreach ($mhsList as $i => $m):
          $rec = ['H'=>0,'I'=>0,'S'=>0,'A'=>0];
        ?>
          <tr>
            <td><?= $i + 1 ?></td>
            <td style="text-align:left"><?= h($m['nama']) ?></td>
            <td><?= h($m['nim']) ?></td>
            <?php if (empty($tanggalPertemuan)): ?>
              <td>-</td>
            <?php else: foreach ($tanggalPertemuan as $tgl):
                $st = $absensiMap[$m['id']][$tgl] ?? '';
                // Pertemuan yang sudah lewat dan tidak ada catatan sama sekali otomatis dihitung Alfa
                if ($st === '' && $tgl < $hariIniStr) { $st = 'A'; }
                if ($st !== '') { $rec[$st]++; }
            ?>
              <td><?= h($st) ?></td>
            <?php endforeach; endif; ?>
            <td><?= $rec['H'] ?></td>
            <td><?= $rec['I'] ?></td>
            <td><?= $rec['S'] ?></td>
            <td><?= $rec['A'] ?></td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
    <p class="text-[10px] text-slate-500 mt-2">Keterangan: H = Hadir &middot; I = Izin &middot; S = Sakit &middot; A = Alpa</p>
  </div>

  <!-- TANDA TANGAN & VERIFIKASI KEASLIAN DOKUMEN -->
  <?php $kodeVerifikasi = buatKodeVerifikasi($kelasAktif['id'], $filterBulan, $p['nama_mk']); ?>
  <div class="official-doc bg-white text-slate-900 p-4 rounded-lg mt-4 grid grid-cols-3 gap-4 text-xs">
    <div class="flex flex-col justify-end">
      <div id="qr-verifikasi" class="mb-1"></div>
      <p class="text-slate-500">Kode: <span class="font-mono font-semibold"><?= h($kodeVerifikasi) ?></span></p>
      <p class="text-slate-400 mt-1">Pindai untuk verifikasi keaslian dokumen ini.</p>
    </div>
    <div class="text-center">
      <p>Mengetahui,</p>
      <p>Ketua Program Studi <?= h($p['prodi']) ?>,</p>
      <p class="mt-16 font-semibold underline">( ..................................... )</p>
    </div>
    <div class="text-center">
      <p>Sigli, <?= date('d F Y') ?></p>
      <p>Dosen Pengampu,</p>
      <p class="mt-16 font-semibold underline"><?= h($p['dosen_pengampu']) ?></p>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/qrcodejs@1.0.0/qrcode.min.js"></script>
<script>
  new QRCode(document.getElementById("qr-verifikasi"), {
    text: <?= json_encode($kodeVerifikasi . ' | ' . $kelasAktif['nama_kelas'] . ' | ' . $filterBulan) ?>,
    width: 70, height: 70,
    colorDark: "#0f172a", colorLight: "#ffffff"
  });
</script>

<?php endif; ?>

<?php include __DIR__ . '/_layout_bottom.php'; ?>

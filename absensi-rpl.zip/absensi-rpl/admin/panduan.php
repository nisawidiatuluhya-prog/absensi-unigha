<?php
require_once __DIR__ . '/../config/database.php';
requireLogin('admin');
$p = getPengaturan();

$pageTitle = 'Panduan Admin';
include __DIR__ . '/_layout_top.php';

$langkah = [
    ['🏫', 'Atur Kelas & Jadwal', 'Buka menu "Data Kelas" untuk menambah/mengedit kelas paralel beserta hari dan jam kuliahnya. Jam ini juga bisa diedit cepat lewat kartu jadwal di Dashboard.'],
    ['🎓', 'Kelola Data Mahasiswa', 'Buka menu "Data Mahasiswa" untuk melihat, mencari, atau menambahkan mahasiswa secara manual ke kelas tertentu.'],
    ['🪪', 'Cetak Kartu QR', 'Gunakan menu "Kartu Digital" untuk mencetak kartu satu mahasiswa, atau "Cetak Massal Kartu" untuk mencetak satu kelas sekaligus.'],
    ['🟢', 'Pantau Kehadiran Live', 'Menu "Live Monitoring" menampilkan aktivitas absensi hari ini secara real-time, tanpa perlu refresh manual.'],
    ['📩', 'Validasi Surat Izin', 'Setiap surat izin/sakit yang diajukan mahasiswa masuk ke menu "Validasi Izin" — klik Terima atau Tolak untuk memperbarui status absensi mereka otomatis.'],
    ['📣', 'Broadcast Pengumuman', 'Gunakan menu "Pengumuman" untuk mengirim info (misalnya dosen berhalangan hadir) ke seluruh mahasiswa atau kelas tertentu — langsung muncul sebagai notifikasi di dashboard mereka.'],
    ['📅', 'Tandai Hari Libur', 'Menu "Hari Libur" berisi kalender — klik tanggal untuk menandai/menghapus tanggal merah agar tidak dihitung sebagai pertemuan/Alfa.'],
    ['📑', 'Unduh Laporan Resmi', 'Menu "Laporan Resmi" menghasilkan Daftar Hadir Mahasiswa dan Dosen (DHMD) per kelas per bulan, lengkap dengan tombol unduh PDF (cetak), Excel, dan Word.'],
    ['⚙️', 'Sesuaikan Data Mata Kuliah', 'Menu "Pengaturan Mata Kuliah" untuk mengubah nama kampus, dosen pengampu, nomor WhatsApp dosen, dan batas toleransi keterlambatan.'],
];
?>

<h1 class="text-2xl font-bold text-white mb-1">Panduan Admin — Absensi Unigha</h1>
<p class="text-slate-400 text-sm mb-8">Alur pengelolaan sistem absensi untuk mata kuliah <?= h($p['nama_mk']) ?></p>

<div class="relative">
  <div class="absolute left-5 top-2 bottom-2 w-0.5 bg-gradient-to-b from-sky-400/60 to-indigo-500/20 hidden sm:block"></div>
  <div class="space-y-4">
    <?php foreach ($langkah as $i => $l): ?>
      <div class="card-navy p-5 flex gap-4 items-start relative">
        <div class="w-10 h-10 rounded-full bg-sky-500 text-slate-900 font-bold flex items-center justify-center shrink-0 relative z-10"><?= $i + 1 ?></div>
        <div>
          <p class="text-white font-semibold mb-1"><?= $l[0] ?> <?= h($l[1]) ?></p>
          <p class="text-slate-400 text-sm"><?= $l[2] ?></p>
        </div>
      </div>
    <?php endforeach; ?>
  </div>
</div>

<div class="card-navy p-5 mt-8">
  <p class="font-semibold text-white mb-1">🛠️ Pertanyaan Umum & Pemecahan Masalah</p>
  <p class="text-slate-500 text-xs mb-4">Jika ada tombol atau fitur yang tidak berjalan seperti seharusnya, coba langkah berikut.</p>
  <div class="space-y-4 text-sm">
    <div>
      <p class="text-slate-200 font-medium">❓ Menu di sidebar tidak muncul di HP?</p>
      <p class="text-slate-500">Ketuk ikon ☰ di pojok kiri atas untuk membuka menu. Jika masih tidak muncul, coba muat ulang halaman.</p>
    </div>
    <div>
      <p class="text-slate-200 font-medium">❓ Laporan/kartu tidak bisa diunduh?</p>
      <p class="text-slate-500">Pastikan pop-up/download tidak diblokir oleh browser. Coba tekan lama tombol unduh dan pilih "Buka di tab baru" jika perlu.</p>
    </div>
    <div>
      <p class="text-slate-200 font-medium">❓ Mahasiswa tidak bisa scan / absen ditolak sistem?</p>
      <p class="text-slate-500">Periksa jam kelas di menu Data Kelas, dan pastikan tanggal hari ini tidak sedang ditandai sebagai hari libur.</p>
    </div>
    <div>
      <p class="text-slate-200 font-medium">❓ Ingin reset password mahasiswa?</p>
      <p class="text-slate-500">Saat ini reset password dilakukan lewat database (tabel <code>users</code>) — fitur reset dari panel admin akan ditambahkan pada pembaruan berikutnya.</p>
    </div>
  </div>
</div>

<?php include __DIR__ . '/_layout_bottom.php'; ?>

<?php
require_once __DIR__ . '/../config/database.php';
requireLogin('admin');
$pdo = getDBConnection();
$p = getPengaturan();

$msg = ''; $msgType = 'success';
$kelasOptions = $pdo->query("SELECT * FROM kelas ORDER BY nama_kelas")->fetchAll();

$uploadDir = __DIR__ . '/../assets/uploads/pengumuman/';
if (!is_dir($uploadDir)) { mkdir($uploadDir, 0755, true); }

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'kirim') {
    $tipe = ($_POST['tipe'] ?? 'Pengumuman') === 'Tugas' ? 'Tugas' : 'Pengumuman';
    $judul = trim($_POST['judul'] ?? '');
    $isi = trim($_POST['isi'] ?? '');
    $kelasId = ($_POST['kelas_id'] ?? '') === '' ? null : (int)$_POST['kelas_id'];
    $deadline = ($tipe === 'Tugas' && !empty($_POST['deadline'])) ? $_POST['deadline'] : null;

    if ($judul === '' || $isi === '') {
        $msg = 'Judul dan isi wajib diisi.'; $msgType = 'error';
    } else {
        $fileSimpan = null;
        $fileAsli = null;

        if (!empty($_FILES['lampiran']['name']) && $_FILES['lampiran']['error'] === UPLOAD_ERR_OK) {
            $izinExt = ['pdf','doc','docx','ppt','pptx','xls','xlsx','jpg','jpeg','png','zip','rar'];
            $ext = strtolower(pathinfo($_FILES['lampiran']['name'], PATHINFO_EXTENSION));
            if (!in_array($ext, $izinExt)) {
                $msg = 'Jenis file lampiran tidak diizinkan.'; $msgType = 'error';
            } elseif ($_FILES['lampiran']['size'] > 10 * 1024 * 1024) {
                $msg = 'Ukuran file lampiran maksimal 10MB.'; $msgType = 'error';
            } else {
                $fileAsli = $_FILES['lampiran']['name'];
                $fileSimpan = uniqid('lampiran_', true) . '.' . $ext;
                move_uploaded_file($_FILES['lampiran']['tmp_name'], $uploadDir . $fileSimpan);
            }
        }

        if ($msg === '') {
            $stmt = $pdo->prepare("
                INSERT INTO pengumuman (kelas_id, tipe, judul, isi, deadline, file_lampiran, file_nama_asli)
                VALUES (:k, :t, :j, :i, :d, :f, :fn)
            ");
            $stmt->execute([
                ':k' => $kelasId, ':t' => $tipe, ':j' => $judul, ':i' => $isi,
                ':d' => $deadline, ':f' => $fileSimpan, ':fn' => $fileAsli
            ]);
            $msg = ($tipe === 'Tugas' ? 'Tugas' : 'Pengumuman') . ' berhasil dikirim dan langsung tampil ke mahasiswa.';
        }
    }
}

if (isset($_GET['hapus'])) {
    $stmt = $pdo->prepare("SELECT file_lampiran FROM pengumuman WHERE id = :id");
    $stmt->execute([':id' => (int)$_GET['hapus']]);
    $row = $stmt->fetch();
    if ($row && $row['file_lampiran'] && file_exists($uploadDir . $row['file_lampiran'])) {
        unlink($uploadDir . $row['file_lampiran']);
    }
    $pdo->prepare("DELETE FROM pengumuman WHERE id = :id")->execute([':id' => (int)$_GET['hapus']]);
    $msg = 'Data berhasil dihapus.';
}

$daftar = $pdo->query("
    SELECT pg.*, k.nama_kelas
    FROM pengumuman pg
    LEFT JOIN kelas k ON k.id = pg.kelas_id
    ORDER BY pg.created_at DESC
")->fetchAll();

$pageTitle = 'Pengumuman & Tugas';
include __DIR__ . '/_layout_top.php';
?>

<h1 class="text-2xl font-bold text-white mb-1">Pengumuman & Tugas Dosen</h1>
<p class="text-slate-400 text-sm mb-6">Broadcast info penting atau bagikan tugas — langsung tampil di halaman "Pemberitahuan Dosen" mahasiswa</p>

<?php if ($msg): ?>
  <div class="mb-5 px-4 py-3 rounded-lg text-sm <?= $msgType === 'error' ? 'bg-red-900/40 border border-red-700/40 text-red-300' : 'bg-emerald-900/40 border border-emerald-700/40 text-emerald-300' ?>">
    <?= h($msg) ?>
  </div>
<?php endif; ?>

<div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
  <div class="card-navy p-6">
    <p class="font-semibold text-white mb-4">Buat Baru</p>
    <form method="POST" enctype="multipart/form-data" class="space-y-3">
      <input type="hidden" name="action" value="kirim">
      <div>
        <label class="text-xs text-slate-400 block mb-1">Tipe</label>
        <select name="tipe" id="tipe-select" onchange="document.getElementById('deadline-wrap').classList.toggle('hidden', this.value !== 'Tugas')" class="w-full px-3 py-2 rounded-lg bg-slate-800 border border-white/10 text-white text-sm">
          <option value="Pengumuman">📣 Pengumuman</option>
          <option value="Tugas">📝 Tugas</option>
        </select>
      </div>
      <div>
        <label class="text-xs text-slate-400 block mb-1">Tujuan</label>
        <select name="kelas_id" class="w-full px-3 py-2 rounded-lg bg-slate-800 border border-white/10 text-white text-sm">
          <option value="">Semua Kelas</option>
          <?php foreach ($kelasOptions as $k): ?>
            <option value="<?= $k['id'] ?>">Hanya Kelas <?= h($k['nama_kelas']) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div>
        <label class="text-xs text-slate-400 block mb-1">Judul</label>
        <input type="text" name="judul" required placeholder="cth: Tugas Pertemuan 5" class="w-full px-3 py-2 rounded-lg bg-slate-800 border border-white/10 text-white text-sm">
      </div>
      <div>
        <label class="text-xs text-slate-400 block mb-1">Isi / Instruksi</label>
        <textarea name="isi" rows="5" required placeholder="Tuliskan detailnya..." class="w-full px-3 py-2 rounded-lg bg-slate-800 border border-white/10 text-white text-sm"></textarea>
      </div>
      <div id="deadline-wrap" class="hidden">
        <label class="text-xs text-slate-400 block mb-1">Batas Waktu Pengumpulan</label>
        <input type="datetime-local" name="deadline" class="w-full px-3 py-2 rounded-lg bg-slate-800 border border-white/10 text-white text-sm">
      </div>
      <div>
        <label class="text-xs text-slate-400 block mb-1">Lampiran File <span class="text-slate-600">(opsional, maks 10MB)</span></label>
        <input type="file" name="lampiran" class="w-full text-xs text-slate-400 file:mr-3 file:py-2 file:px-3 file:rounded-lg file:border-0 file:bg-slate-700 file:text-white file:text-xs">
      </div>
      <button class="w-full py-2.5 rounded-lg bg-sky-500 hover:bg-sky-400 text-slate-900 font-semibold text-sm">📤 Kirim</button>
    </form>
  </div>

  <div class="lg:col-span-2 card-navy p-6">
    <p class="font-semibold text-white mb-4">Riwayat</p>
    <div class="space-y-3 max-h-[560px] overflow-y-auto">
      <?php if (empty($daftar)): ?>
        <p class="text-slate-500 text-sm">Belum ada pengumuman atau tugas yang dikirim.</p>
      <?php endif; ?>
      <?php foreach ($daftar as $d): ?>
        <div class="bg-slate-800/60 border border-white/10 rounded-lg p-4">
          <div class="flex items-start justify-between gap-3">
            <div>
              <span class="badge <?= $d['tipe'] === 'Tugas' ? 'badge-I' : 'badge-H' ?>"><?= $d['tipe'] === 'Tugas' ? '📝 Tugas' : '📣 Pengumuman' ?></span>
              <p class="text-white font-semibold text-sm mt-1"><?= h($d['judul']) ?></p>
              <p class="text-xs text-slate-500 mb-2">
                <?= $d['nama_kelas'] ? 'Kelas ' . h($d['nama_kelas']) : 'Semua Kelas' ?>
                &middot; <?= date('d M Y, H:i', strtotime($d['created_at'])) ?>
                <?php if ($d['tipe'] === 'Tugas' && $d['deadline']): ?>
                  &middot; Deadline <?= date('d M Y, H:i', strtotime($d['deadline'])) ?>
                <?php endif; ?>
              </p>
            </div>
            <a href="?hapus=<?= $d['id'] ?>" onclick="return confirm('Hapus data ini?')" class="text-red-400 hover:text-red-300 text-xs shrink-0">Hapus</a>
          </div>
          <p class="text-slate-300 text-sm whitespace-pre-line"><?= h($d['isi']) ?></p>
          <?php if ($d['file_lampiran']): ?>
            <a href="../assets/uploads/pengumuman/<?= h($d['file_lampiran']) ?>" target="_blank" class="inline-flex items-center gap-1 mt-2 text-sky-400 hover:text-sky-300 text-xs">📎 <?= h($d['file_nama_asli']) ?></a>
          <?php endif; ?>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</div>

<?php include __DIR__ . '/_layout_bottom.php'; ?>

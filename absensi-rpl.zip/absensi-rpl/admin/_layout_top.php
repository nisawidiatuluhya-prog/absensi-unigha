<?php
// Partial ini di-include di setiap halaman admin setelah proses data selesai.
// Variabel $pageTitle harus sudah didefinisikan sebelum include.
$currentPage = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= h($pageTitle ?? 'Admin') ?> | Absensi Unigha</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<script src="https://cdn.tailwindcss.com"></script>
<link rel="stylesheet" href="../assets/css/style.css">
</head>
<body class="min-h-screen flex text-slate-200">

  <!-- OVERLAY MOBILE -->
  <div id="sidebar-overlay" class="fixed inset-0 bg-black/60 z-40 hidden md:hidden" onclick="toggleSidebar()"></div>

  <!-- SIDEBAR -->
  <aside id="sidebar" class="w-64 shrink-0 border-r border-white/5 flex flex-col fixed md:static inset-y-0 left-0 z-50 -translate-x-full md:translate-x-0 transition-transform duration-300 ease-in-out" style="background-color:#0b1220;">
    <div class="p-5 flex items-center justify-between gap-3 border-b border-white/5">
      <div class="flex items-center gap-3">
        <div class="w-9 h-9 rounded-lg bg-gradient-to-br from-sky-400 to-indigo-500 flex items-center justify-center font-bold text-slate-900 text-sm">AU</div>
        <div>
          <p class="text-white font-semibold text-sm leading-tight">Absensi Unigha</p>
          <p class="text-xs text-slate-500 leading-tight">Panel Admin</p>
        </div>
      </div>
      <button onclick="toggleSidebar()" class="md:hidden w-8 h-8 rounded-lg bg-white/5 text-white flex items-center justify-center">✕</button>
    </div>
    <nav class="p-3 flex-1 space-y-1 overflow-y-auto">
      <a href="dashboard.php" class="sidebar-link <?= $currentPage === 'dashboard.php' ? 'active' : '' ?>">📊 Dashboard</a>
      <a href="monitoring.php" class="sidebar-link <?= $currentPage === 'monitoring.php' ? 'active' : '' ?>">🟢 Live Monitoring</a>
      <a href="kelas.php" class="sidebar-link <?= $currentPage === 'kelas.php' ? 'active' : '' ?>">🏫 Data Kelas</a>
      <a href="mahasiswa.php" class="sidebar-link <?= $currentPage === 'mahasiswa.php' ? 'active' : '' ?>">🎓 Data Mahasiswa</a>
      <a href="kartu.php" class="sidebar-link <?= $currentPage === 'kartu.php' ? 'active' : '' ?>">🪪 Kartu Digital</a>
      <a href="kartu_qr.php" class="sidebar-link <?= $currentPage === 'kartu_qr.php' ? 'active' : '' ?>">🖨️ Cetak Massal Kartu</a>
      <a href="izin.php" class="sidebar-link <?= $currentPage === 'izin.php' ? 'active' : '' ?>">📩 Validasi Izin</a>
      <a href="pengumuman.php" class="sidebar-link <?= $currentPage === 'pengumuman.php' ? 'active' : '' ?>">📣 Pengumuman</a>
      <a href="hari_libur.php" class="sidebar-link <?= $currentPage === 'hari_libur.php' ? 'active' : '' ?>">📅 Hari Libur</a>
      <a href="laporan.php" class="sidebar-link <?= $currentPage === 'laporan.php' ? 'active' : '' ?>">📑 Laporan Resmi</a>
      <a href="pengaturan.php" class="sidebar-link <?= $currentPage === 'pengaturan.php' ? 'active' : '' ?>">⚙️ Pengaturan Mata Kuliah</a>
    </nav>
    <div class="p-3 border-t border-white/5 space-y-1">
      <a href="panduan.php" class="sidebar-link <?= $currentPage === 'panduan.php' ? 'active' : '' ?>">
        ❓ Panduan
      </a>
      <div class="sidebar-link">
        👤 <?= h($_SESSION['username'] ?? 'Admin') ?>
      </div>
      <a href="../logout.php" class="sidebar-link text-red-400 hover:text-red-300">
        🚪 Keluar
      </a>
    </div>
  </aside>

  <!-- MAIN CONTENT -->
  <div class="flex-1 flex flex-col min-w-0">
    <!-- Topbar mobile -->
    <div class="md:hidden flex items-center justify-between px-4 py-3 border-b border-white/5 sticky top-0 z-30" style="background-color:#0b1220;">
      <button onclick="toggleSidebar()" class="w-9 h-9 rounded-lg bg-white/5 text-white flex items-center justify-center text-lg">☰</button>
      <p class="font-semibold text-white text-sm">Absensi Unigha</p>
      <a href="../logout.php" class="text-red-400 text-sm">Keluar</a>
    </div>
    <main class="flex-1 p-6 md:p-8 overflow-x-auto">

    <script>
      function toggleSidebar() {
        document.getElementById('sidebar').classList.toggle('-translate-x-full');
        document.getElementById('sidebar-overlay').classList.toggle('hidden');
      }
    </script>

<?php
require_once __DIR__ . '/../config/database.php';
requireLogin('admin');
$pdo = getDBConnection();
$p = getPengaturan();

$id = (int)($_GET['id'] ?? 0);
$mhs = null;
if ($id) {
    $stmt = $pdo->prepare("SELECT m.*, k.nama_kelas FROM mahasiswa m JOIN kelas k ON k.id = m.kelas_id WHERE m.id = :id");
    $stmt->execute([':id' => $id]);
    $mhs = $stmt->fetch();
}

$mahasiswaList = $pdo->query("
    SELECT m.id, m.nama, m.nim, k.nama_kelas FROM mahasiswa m
    JOIN kelas k ON k.id = m.kelas_id ORDER BY k.nama_kelas, m.nama
")->fetchAll();

$pageTitle = 'Kartu Mahasiswa Digital';
include __DIR__ . '/_layout_top.php';
?>

<script src="https://cdn.jsdelivr.net/npm/qrcodejs@1.0.0/qrcode.min.js"></script>

<h1 class="text-2xl font-bold text-white mb-1 print:hidden">Kartu Mahasiswa Digital</h1>
<p class="text-slate-400 text-sm mb-6 print:hidden">Pratinjau kartu identitas mahasiswa lengkap dengan QR code, siap cetak</p>

<div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
  <!-- DAFTAR MAHASISWA -->
  <div class="card-navy p-5 print:hidden">
    <p class="font-semibold text-white mb-3">Pilih Mahasiswa</p>
    <div class="max-h-[480px] overflow-y-auto space-y-1">
      <?php foreach ($mahasiswaList as $m): ?>
        <a href="?id=<?= $m['id'] ?>" class="block px-3 py-2 rounded-lg text-sm <?= $id === (int)$m['id'] ? 'bg-sky-500 text-slate-900 font-semibold' : 'bg-slate-800/60 text-slate-300 hover:bg-slate-800' ?>">
          <?= h($m['nama']) ?>
          <span class="block text-xs <?= $id === (int)$m['id'] ? 'text-slate-800' : 'text-slate-500' ?>"><?= h($m['nim']) ?> &middot; <?= h($m['nama_kelas']) ?></span>
        </a>
      <?php endforeach; ?>
    </div>
  </div>

  <!-- KARTU -->
  <div class="lg:col-span-2">
    <?php if (!$mhs): ?>
      <div class="card-navy p-10 text-center text-slate-500 text-sm">Pilih mahasiswa di daftar sebelah kiri untuk menampilkan kartu.</div>
    <?php else: ?>
      <div class="id-card print-area" id="kartu-cetak">
        <div class="id-card-header flex items-center gap-3">
          <div class="w-11 h-11 rounded-lg bg-white/15 flex items-center justify-center font-bold text-white shrink-0">AU</div>
          <div>
            <p class="font-bold text-white leading-tight"><?= h($p['nama_kampus']) ?></p>
            <p class="text-xs text-white/80 leading-tight">KARTU PESERTA MATA KULIAH — <?= h($p['nama_mk']) ?></p>
            <p class="text-[11px] text-white/60 leading-tight"><?= h($p['fakultas']) ?>, <?= h($p['alamat_kampus']) ?></p>
          </div>
        </div>
        <div class="p-6 flex items-center gap-4">
          <div class="id-avatar shrink-0" style="width:70px;height:70px;"><?= avatarSvg($mhs['jenis_kelamin']) ?></div>
          <div class="flex-1 space-y-1.5 text-sm text-slate-700">
            <p class="text-lg font-bold text-slate-900 leading-tight"><?= h($mhs['nama']) ?></p>
            <p><span class="text-slate-400">NIM</span> &nbsp; <span class="font-medium"><?= h($mhs['nim']) ?></span></p>
            <p><span class="text-slate-400">Kelas</span> &nbsp; <span class="font-medium"><?= h($mhs['nama_kelas']) ?></span></p>
            <p><span class="text-slate-400">J. Kelamin</span> &nbsp; <span class="font-medium"><?= $mhs['jenis_kelamin'] === 'L' ? 'Laki-laki' : 'Perempuan' ?></span></p>
            <p class="text-xs text-slate-400 mt-1">Tahun Ajaran <?= h($p['tahun_ajaran']) ?></p>
          </div>
          <div class="flex flex-col items-center justify-center border border-slate-200 rounded-xl p-3 shrink-0">
            <div id="qrcode"></div>
            <p class="text-[10px] text-slate-400 mt-2">Pindai QR untuk absensi</p>
          </div>
        </div>
        <div class="px-6 py-3 text-center text-white text-xs font-semibold" style="background:#0f172a;">
          Absensi Unigha — <?= h($p['nama_kampus']) ?>
        </div>
      </div>
      <div class="flex gap-2 mt-4 print:hidden">
        <button onclick="window.print()" class="px-4 py-2 rounded-lg bg-slate-700 hover:bg-slate-600 text-white text-sm">🖨️ Cetak Kartu</button>
        <button onclick="unduhKartuAdmin()" class="px-4 py-2 rounded-lg bg-sky-500 hover:bg-sky-400 text-slate-900 font-semibold text-sm">⬇️ Unduh PNG</button>
      </div>

      <script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>
      <script>
        new QRCode(document.getElementById("qrcode"), {
          text: <?= json_encode($mhs['qr_token']) ?>,
          width: 110, height: 110,
          colorDark: "#0f172a", colorLight: "#ffffff"
        });
        function unduhKartuAdmin() {
          html2canvas(document.getElementById('kartu-cetak'), { backgroundColor: '#ffffff', scale: 2 }).then(function (canvas) {
            const link = document.createElement('a');
            link.download = 'kartu-<?= h(preg_replace('/[^A-Za-z0-9]/', '', $mhs['nim'])) ?>.png';
            link.href = canvas.toDataURL('image/png');
            link.click();
          });
        }
      </script>
    <?php endif; ?>
  </div>
</div>

<?php include __DIR__ . '/_layout_bottom.php'; ?>

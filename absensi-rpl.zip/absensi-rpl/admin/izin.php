<?php
require_once __DIR__ . '/../config/database.php';
requireLogin('admin');
$pdo = getDBConnection();

$msg = '';

if (isset($_GET['aksi'], $_GET['id'])) {
    $id = (int)$_GET['id'];
    $status = $_GET['aksi'] === 'setuju' ? 'Disetujui' : ($_GET['aksi'] === 'tolak' ? 'Ditolak' : null);
    if ($status) {
        $stmt = $pdo->prepare("UPDATE surat_izin SET status_konfirmasi = :s WHERE id = :id");
        $stmt->execute([':s' => $status, ':id' => $id]);

        // Jika disetujui, catat status di tabel absensi (I/S) agar tampil di laporan
        if ($status === 'Disetujui') {
            $izinStmt = $pdo->prepare("SELECT * FROM surat_izin WHERE id = :id");
            $izinStmt->execute([':id' => $id]);
            $iz = $izinStmt->fetch();
            if ($iz) {
                $kodeStatus = $iz['jenis'] === 'Sakit' ? 'S' : 'I';
                $up = $pdo->prepare("
                    INSERT INTO absensi (mahasiswa_id, kelas_id, tanggal, waktu_scan, status, keterangan)
                    VALUES (:mid, :kid, :tgl, '00:00:00', :st, :ket)
                    ON DUPLICATE KEY UPDATE status = :st2, keterangan = :ket2
                ");
                $up->execute([
                    ':mid' => $iz['mahasiswa_id'], ':kid' => $iz['kelas_id'], ':tgl' => $iz['tanggal_izin'],
                    ':st' => $kodeStatus, ':ket' => $iz['alasan'], ':st2' => $kodeStatus, ':ket2' => $iz['alasan']
                ]);
            }
        }
        $msg = "Surat izin telah di-$status.";
    }
}

$filter = $_GET['status'] ?? 'Pending';
$sql = "
    SELECT si.*, m.nama, m.nim, k.nama_kelas
    FROM surat_izin si
    JOIN mahasiswa m ON m.id = si.mahasiswa_id
    JOIN kelas k ON k.id = si.kelas_id
";
$params = [];
if ($filter !== '' && $filter !== 'Semua') {
    $sql .= " WHERE si.status_konfirmasi = :st";
    $params[':st'] = $filter;
}
$sql .= " ORDER BY si.created_at DESC";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$izinList = $stmt->fetchAll();

$pageTitle = 'Validasi Surat Izin';
include __DIR__ . '/_layout_top.php';
?>

<h1 class="text-2xl font-bold text-white mb-1">Validasi Surat Izin Mahasiswa</h1>
<p class="text-slate-400 text-sm mb-6">Setujui atau tolak pengajuan izin/sakit mahasiswa</p>

<?php if ($msg): ?>
  <div class="mb-5 px-4 py-3 rounded-lg text-sm bg-emerald-900/40 border border-emerald-700/40 text-emerald-300"><?= h($msg) ?></div>
<?php endif; ?>

<div class="flex gap-2 mb-5">
  <?php foreach (['Pending','Disetujui','Ditolak','Semua'] as $st): ?>
    <a href="?status=<?= $st ?>" class="px-3 py-1.5 rounded-lg text-sm <?= $filter === $st ? 'bg-sky-500 text-slate-900 font-semibold' : 'bg-slate-800 text-slate-300 hover:bg-slate-700' ?>">
      <?= $st ?>
    </a>
  <?php endforeach; ?>
</div>

<div class="card-navy p-6 overflow-x-auto">
  <table class="w-full text-sm">
    <thead>
      <tr class="text-left text-slate-400 border-b border-white/10">
        <th class="py-2 pr-4">Mahasiswa</th>
        <th class="py-2 pr-4">Kelas</th>
        <th class="py-2 pr-4">Jenis</th>
        <th class="py-2 pr-4">Tanggal</th>
        <th class="py-2 pr-4">Alasan</th>
        <th class="py-2 pr-4">Status</th>
        <th class="py-2">Aksi</th>
      </tr>
    </thead>
    <tbody>
      <?php if (empty($izinList)): ?>
        <tr><td colspan="7" class="py-4 text-center text-slate-500">Tidak ada data.</td></tr>
      <?php endif; ?>
      <?php foreach ($izinList as $iz): ?>
        <tr class="border-b border-white/5">
          <td class="py-2 pr-4 text-white"><?= h($iz['nama']) ?><br><span class="text-xs text-slate-500"><?= h($iz['nim']) ?></span></td>
          <td class="py-2 pr-4 text-slate-300"><?= h($iz['nama_kelas']) ?></td>
          <td class="py-2 pr-4 text-slate-300"><?= h($iz['jenis']) ?></td>
          <td class="py-2 pr-4 text-slate-400"><?= date('d M Y', strtotime($iz['tanggal_izin'])) ?></td>
          <td class="py-2 pr-4 text-slate-400 max-w-xs truncate" title="<?= h($iz['alasan']) ?>"><?= h($iz['alasan']) ?></td>
          <td class="py-2 pr-4"><span class="badge badge-<?= $iz['status_konfirmasi'] ?>"><?= h($iz['status_konfirmasi']) ?></span></td>
          <td class="py-2">
            <a href="lihat_surat.php?id=<?= $iz['id'] ?>" class="text-sky-400 hover:text-sky-300 text-xs mr-3">Lihat Surat</a>
            <?php if ($iz['status_konfirmasi'] === 'Pending'): ?>
              <a href="?aksi=setuju&id=<?= $iz['id'] ?>&status=<?= $filter ?>" class="text-emerald-400 hover:text-emerald-300 text-xs mr-3">Setujui</a>
              <a href="?aksi=tolak&id=<?= $iz['id'] ?>&status=<?= $filter ?>" class="text-red-400 hover:text-red-300 text-xs">Tolak</a>
            <?php else: ?>
              <span class="text-slate-600 text-xs">—</span>
            <?php endif; ?>
          </td>
        </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>

<?php include __DIR__ . '/_layout_bottom.php'; ?>

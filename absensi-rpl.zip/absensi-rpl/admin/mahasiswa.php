<?php
require_once __DIR__ . '/../config/database.php';
requireLogin('admin');
$pdo = getDBConnection();
$p = getPengaturan();

$msg = '';
$msgType = 'success';

$kelasOptions = $pdo->query("SELECT * FROM kelas ORDER BY nama_kelas")->fetchAll();

// ===== TAMBAH MAHASISWA BARU (buat akun + profil sekaligus) =====
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'tambah') {
    $nama     = trim($_POST['nama'] ?? '');
    $nim      = trim($_POST['nim'] ?? '');
    $jk       = ($_POST['jenis_kelamin'] ?? 'L') === 'P' ? 'P' : 'L';
    $alamat   = trim($_POST['alamat'] ?? '');
    $kelasId  = (int)($_POST['kelas_id'] ?? 0);
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($nama === '' || $nim === '' || $kelasId === 0) {
        $msg = 'Nama, NIM, dan Kelas wajib diisi.';
        $msgType = 'error';
    } else {
        try {
            $pdo->beginTransaction();

            // Akun login OPSIONAL. Kosongkan saja — mahasiswa mendaftar
            // sendiri lewat register.php dan datanya diklaim via NIM.
            $userId = null;
            if ($username !== '' && $password !== '') {
                $stmt = $pdo->prepare("INSERT INTO users (username, password, role) VALUES (:u, :p, 'mahasiswa')");
                $stmt->execute([':u' => $username, ':p' => password_hash($password, PASSWORD_DEFAULT)]);
                $userId = $pdo->lastInsertId();
            }

            $qrToken = 'STD-' . strtoupper(bin2hex(random_bytes(6)));

            $stmt2 = $pdo->prepare("
                INSERT INTO mahasiswa (user_id, nama, nim, jenis_kelamin, alamat, kelas_id, qr_token)
                VALUES (:uid, :nama, :nim, :jk, :alamat, :kelas_id, :token)
            ");
            $stmt2->execute([
                ':uid' => $userId, ':nama' => $nama, ':nim' => $nim, ':jk' => $jk,
                ':alamat' => $alamat, ':kelas_id' => $kelasId, ':token' => $qrToken
            ]);

            $pdo->commit();
            $msg = $userId
                ? "Mahasiswa \"$nama\" ditambahkan beserta akun login."
                : "Mahasiswa \"$nama\" ditambahkan. Akun login dibuat sendiri oleh mahasiswa via halaman Register.";
        } catch (Exception $e) {
            $pdo->rollBack();
            $msg = 'Gagal menambahkan data (NIM/Username mungkin sudah dipakai).';
            $msgType = 'error';
        }
    }
}

// ===== HAPUS MAHASISWA =====
if (isset($_GET['hapus'])) {
    $id = (int)$_GET['hapus'];
    $stmt = $pdo->prepare("SELECT user_id FROM mahasiswa WHERE id = :id");
    $stmt->execute([':id' => $id]);
    $row = $stmt->fetch();
    if ($row) {
        // Hapus baris mahasiswa dulu, lalu akunnya bila ada
        $pdo->prepare("DELETE FROM mahasiswa WHERE id = :id")->execute([':id' => $id]);
        if (!empty($row['user_id'])) {
            $pdo->prepare("DELETE FROM users WHERE id = :uid")->execute([':uid' => $row['user_id']]);
        }
        $msg = 'Data mahasiswa berhasil dihapus.';
    }
}

// ===== FILTER PER KELAS =====
$filterKelas = $_GET['kelas'] ?? '';

$sql = "SELECT m.*, k.nama_kelas FROM mahasiswa m JOIN kelas k ON k.id = m.kelas_id WHERE 1=1";
$params = [];
if ($filterKelas !== '') { $sql .= " AND m.kelas_id = :kelas"; $params[':kelas'] = $filterKelas; }
$sql .= " ORDER BY k.nama_kelas ASC, m.nama ASC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$mahasiswaList = $stmt->fetchAll();

// Kelompokkan rapi per kelas — kolom tabel dibuat khusus per kelas
$grouped = [];
foreach ($mahasiswaList as $m) {
    $grouped[$m['nama_kelas']][] = $m;
}
ksort($grouped);

$pageTitle = 'Manajemen Mahasiswa';
include __DIR__ . '/_layout_top.php';
?>

<div class="flex flex-col md:flex-row md:items-center justify-between gap-3 mb-6">
  <div>
    <h1 class="text-2xl font-bold text-white">Data Mahasiswa — <?= h($p['nama_mk']) ?></h1>
    <p class="text-slate-400 text-sm">Data ditampilkan rapi per kelas. Status "Belum daftar" = akun login dibuat sendiri oleh mahasiswa.</p>
  </div>
  <button onclick="document.getElementById('modalTambah').classList.remove('hidden')"
    class="px-4 py-2 rounded-lg bg-sky-500 hover:bg-sky-400 text-slate-900 font-semibold text-sm">
    + Tambah Mahasiswa
  </button>
</div>

<?php if ($msg): ?>
  <div class="mb-5 px-4 py-3 rounded-lg text-sm <?= $msgType === 'error' ? 'bg-red-900/40 border border-red-700/40 text-red-300' : 'bg-emerald-900/40 border border-emerald-700/40 text-emerald-300' ?>">
    <?= h($msg) ?>
  </div>
<?php endif; ?>

<!-- FILTER KELAS (TAB) -->
<div class="flex flex-wrap gap-2 mb-6">
  <a href="mahasiswa.php" class="px-3 py-1.5 rounded-lg text-sm <?= $filterKelas === '' ? 'bg-sky-500 text-slate-900 font-semibold' : 'bg-slate-800 text-slate-300 hover:bg-slate-700' ?>">Semua Kelas</a>
  <?php foreach ($kelasOptions as $k): ?>
    <a href="?kelas=<?= $k['id'] ?>" class="px-3 py-1.5 rounded-lg text-sm <?= $filterKelas == $k['id'] ? 'bg-sky-500 text-slate-900 font-semibold' : 'bg-slate-800 text-slate-300 hover:bg-slate-700' ?>"><?= h($k['nama_kelas']) ?></a>
  <?php endforeach; ?>
</div>

<?php if (empty($grouped)): ?>
  <p class="text-slate-500 text-sm">Belum ada data mahasiswa.</p>
<?php endif; ?>

<?php foreach ($grouped as $namaKelas => $list): ?>
  <div class="card-navy p-5 mb-5">
    <p class="font-semibold text-white mb-3">Kelas <?= h($namaKelas) ?> <span class="text-slate-500 font-normal text-sm">(<?= count($list) ?> mahasiswa)</span></p>
    <div class="overflow-x-auto">
      <table class="w-full text-sm">
        <thead>
          <tr class="text-left text-slate-400 border-b border-white/10">
            <th class="py-2 pr-4">No</th>
            <th class="py-2 pr-4">Nama</th>
            <th class="py-2 pr-4">NIM</th>
            <th class="py-2 pr-4">L/P</th>
            <th class="py-2 pr-4">Alamat</th>
            <th class="py-2 pr-4">Akun</th>
            <th class="py-2 pr-4">Kartu</th>
            <th class="py-2 pr-4">Aksi</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($list as $i => $m): ?>
            <tr class="border-b border-white/5">
              <td class="py-2 pr-4 text-slate-500"><?= $i + 1 ?></td>
              <td class="py-2 pr-4 text-white"><?= h($m['nama']) ?></td>
              <td class="py-2 pr-4 text-slate-300"><?= h($m['nim']) ?></td>
              <td class="py-2 pr-4 text-slate-400"><?= h($m['jenis_kelamin']) ?></td>
              <td class="py-2 pr-4 text-slate-400"><?= h($m['alamat'] ?: '-') ?></td>
              <td class="py-2 pr-4">
                <?php if (!empty($m['user_id'])): ?>
                  <span class="px-2 py-0.5 rounded text-xs bg-emerald-900/40 border border-emerald-700/40 text-emerald-300">Aktif</span>
                <?php else: ?>
                  <span class="px-2 py-0.5 rounded text-xs bg-amber-900/40 border border-amber-700/40 text-amber-300">Belum daftar</span>
                <?php endif; ?>
              </td>
              <td class="py-2 pr-4"><a href="kartu.php?id=<?= $m['id'] ?>" class="text-sky-400 hover:text-sky-300 text-xs">Lihat Kartu</a></td>
              <td class="py-2 pr-4">
                <a href="?hapus=<?= $m['id'] ?>" onclick="return confirm('Hapus mahasiswa ini beserta akunnya?')"
                   class="text-red-400 hover:text-red-300 text-xs">Hapus</a>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
<?php endforeach; ?>

<!-- MODAL TAMBAH -->
<div id="modalTambah" class="hidden fixed inset-0 bg-black/60 flex items-center justify-center p-4 z-50">
  <div class="card-navy p-6 w-full max-w-md">
    <p class="font-semibold text-white mb-4">Tambah Mahasiswa Baru</p>
    <form method="POST" class="space-y-3">
      <input type="hidden" name="action" value="tambah">
      <input type="text" name="nama" placeholder="Nama Lengkap" required class="w-full px-3 py-2 rounded-lg bg-slate-800 border border-white/10 text-white text-sm">
      <div class="grid grid-cols-2 gap-3">
        <input type="text" name="nim" placeholder="NIM" required class="px-3 py-2 rounded-lg bg-slate-800 border border-white/10 text-white text-sm">
        <select name="jenis_kelamin" class="px-3 py-2 rounded-lg bg-slate-800 border border-white/10 text-white text-sm">
          <option value="L">Laki-laki</option>
          <option value="P">Perempuan</option>
        </select>
      </div>
      <select name="kelas_id" required class="w-full px-3 py-2 rounded-lg bg-slate-800 border border-white/10 text-white text-sm">
        <option value="">Pilih Kelas</option>
        <?php foreach ($kelasOptions as $k): ?><option value="<?= $k['id'] ?>"><?= h($k['nama_kelas']) ?></option><?php endforeach; ?>
      </select>
      <input type="text" name="alamat" placeholder="Alamat" class="w-full px-3 py-2 rounded-lg bg-slate-800 border border-white/10 text-white text-sm">
      <hr class="border-white/10 my-2">
      <p class="text-xs text-slate-400 leading-relaxed">
        <b class="text-slate-300">Akun login (opsional).</b> Biarkan kosong bila mahasiswa akan mendaftar
        sendiri lewat halaman Register — datanya otomatis tersambung lewat NIM.
      </p>
      <input type="text" name="username" placeholder="Username Login (opsional)" class="w-full px-3 py-2 rounded-lg bg-slate-800 border border-white/10 text-white text-sm">
      <input type="password" name="password" placeholder="Password Login (opsional)" class="w-full px-3 py-2 rounded-lg bg-slate-800 border border-white/10 text-white text-sm">
      <div class="flex gap-3 pt-2">
        <button type="button" onclick="document.getElementById('modalTambah').classList.add('hidden')"
          class="flex-1 py-2 rounded-lg bg-slate-700 hover:bg-slate-600 text-white text-sm">Batal</button>
        <button type="submit" class="flex-1 py-2 rounded-lg bg-sky-500 hover:bg-sky-400 text-slate-900 font-semibold text-sm">Simpan</button>
      </div>
    </form>
  </div>
</div>

<?php include __DIR__ . '/_layout_bottom.php'; ?>

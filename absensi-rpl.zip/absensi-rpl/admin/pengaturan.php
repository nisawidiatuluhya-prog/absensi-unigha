<?php
require_once __DIR__ . '/../config/database.php';
requireLogin('admin');
$pdo = getDBConnection();

$msg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $stmt = $pdo->prepare("
        UPDATE pengaturan SET
            nama_kampus = :nama_kampus, yayasan = :yayasan, alamat_kampus = :alamat_kampus,
            fakultas = :fakultas, jurusan = :jurusan, prodi = :prodi,
            kode_mk = :kode_mk, nama_mk = :nama_mk,
            dosen_pengampu = :dosen_pengampu, nidn_dosen = :nidn_dosen, no_wa_dosen = :no_wa_dosen,
            email_dosen = :email_dosen,
            semester = :semester, tahun_ajaran = :tahun_ajaran, toleransi_menit = :toleransi_menit
        WHERE id = 1
    ");
    $stmt->execute([
        ':nama_kampus' => trim($_POST['nama_kampus']),
        ':yayasan' => trim($_POST['yayasan']),
        ':alamat_kampus' => trim($_POST['alamat_kampus']),
        ':fakultas' => trim($_POST['fakultas']),
        ':jurusan' => trim($_POST['jurusan']),
        ':prodi' => trim($_POST['prodi']),
        ':kode_mk' => trim($_POST['kode_mk']),
        ':nama_mk' => trim($_POST['nama_mk']),
        ':dosen_pengampu' => trim($_POST['dosen_pengampu']),
        ':nidn_dosen' => trim($_POST['nidn_dosen']),
        ':no_wa_dosen' => trim($_POST['no_wa_dosen']),
        ':email_dosen' => trim($_POST['email_dosen']),
        ':semester' => trim($_POST['semester']),
        ':tahun_ajaran' => trim($_POST['tahun_ajaran']),
        ':toleransi_menit' => (int)$_POST['toleransi_menit'],
    ]);
    $msg = 'Pengaturan mata kuliah berhasil disimpan.';
}

$p = $pdo->query("SELECT * FROM pengaturan WHERE id = 1")->fetch();

$pageTitle = 'Pengaturan Mata Kuliah';
include __DIR__ . '/_layout_top.php';
?>

<h1 class="text-2xl font-bold text-white mb-1">Pengaturan Mata Kuliah</h1>
<p class="text-slate-400 text-sm mb-6">Data ini digunakan pada kop laporan resmi, kartu mahasiswa, dan halaman utama</p>

<?php if ($msg): ?>
  <div class="mb-5 px-4 py-3 rounded-lg text-sm bg-emerald-900/40 border border-emerald-700/40 text-emerald-300"><?= h($msg) ?></div>
<?php endif; ?>

<form method="POST" class="grid grid-cols-1 lg:grid-cols-2 gap-6">
  <div class="card-navy p-6 space-y-3">
    <p class="font-semibold text-white mb-2">Identitas Kampus</p>
    <div>
      <label class="text-xs text-slate-400 block mb-1">Nama Yayasan</label>
      <input type="text" name="yayasan" value="<?= h($p['yayasan']) ?>" class="w-full px-3 py-2 rounded-lg bg-slate-800 border border-white/10 text-white text-sm">
    </div>
    <div>
      <label class="text-xs text-slate-400 block mb-1">Nama Kampus</label>
      <input type="text" name="nama_kampus" value="<?= h($p['nama_kampus']) ?>" class="w-full px-3 py-2 rounded-lg bg-slate-800 border border-white/10 text-white text-sm">
    </div>
    <div>
      <label class="text-xs text-slate-400 block mb-1">Alamat Kampus</label>
      <input type="text" name="alamat_kampus" value="<?= h($p['alamat_kampus']) ?>" class="w-full px-3 py-2 rounded-lg bg-slate-800 border border-white/10 text-white text-sm">
    </div>
    <div class="grid grid-cols-2 gap-3">
      <div>
        <label class="text-xs text-slate-400 block mb-1">Fakultas</label>
        <input type="text" name="fakultas" value="<?= h($p['fakultas']) ?>" class="w-full px-3 py-2 rounded-lg bg-slate-800 border border-white/10 text-white text-sm">
      </div>
      <div>
        <label class="text-xs text-slate-400 block mb-1">Jurusan</label>
        <input type="text" name="jurusan" value="<?= h($p['jurusan']) ?>" class="w-full px-3 py-2 rounded-lg bg-slate-800 border border-white/10 text-white text-sm">
      </div>
    </div>
    <div>
      <label class="text-xs text-slate-400 block mb-1">Program Studi</label>
      <input type="text" name="prodi" value="<?= h($p['prodi']) ?>" class="w-full px-3 py-2 rounded-lg bg-slate-800 border border-white/10 text-white text-sm">
    </div>
  </div>

  <div class="card-navy p-6 space-y-3">
    <p class="font-semibold text-white mb-2">Data Mata Kuliah & Dosen</p>
    <div class="grid grid-cols-2 gap-3">
      <div>
        <label class="text-xs text-slate-400 block mb-1">Kode MK</label>
        <input type="text" name="kode_mk" value="<?= h($p['kode_mk']) ?>" class="w-full px-3 py-2 rounded-lg bg-slate-800 border border-white/10 text-white text-sm">
      </div>
      <div>
        <label class="text-xs text-slate-400 block mb-1">Nama Mata Kuliah</label>
        <input type="text" name="nama_mk" value="<?= h($p['nama_mk']) ?>" class="w-full px-3 py-2 rounded-lg bg-slate-800 border border-white/10 text-white text-sm">
      </div>
    </div>
    <div>
      <label class="text-xs text-slate-400 block mb-1">Dosen Pengampu</label>
      <input type="text" name="dosen_pengampu" value="<?= h($p['dosen_pengampu']) ?>" class="w-full px-3 py-2 rounded-lg bg-slate-800 border border-white/10 text-white text-sm">
    </div>
    <div class="grid grid-cols-2 gap-3">
      <div>
        <label class="text-xs text-slate-400 block mb-1">NIDN Dosen</label>
        <input type="text" name="nidn_dosen" value="<?= h($p['nidn_dosen']) ?>" class="w-full px-3 py-2 rounded-lg bg-slate-800 border border-white/10 text-white text-sm">
      </div>
      <div>
        <label class="text-xs text-slate-400 block mb-1">No. WhatsApp Dosen</label>
        <input type="text" name="no_wa_dosen" placeholder="cth: 6281234567890" value="<?= h($p['no_wa_dosen']) ?>" class="w-full px-3 py-2 rounded-lg bg-slate-800 border border-white/10 text-white text-sm">
      </div>
    </div>
    <div>
      <label class="text-xs text-slate-400 block mb-1">Email Dosen</label>
      <input type="email" name="email_dosen" placeholder="cth: dosen@unigha.ac.id" value="<?= h($p['email_dosen'] ?? '') ?>" class="w-full px-3 py-2 rounded-lg bg-slate-800 border border-white/10 text-white text-sm">
      <p class="text-xs text-slate-500 mt-1">Dipakai untuk tombol "Kirim ke Dosen" di halaman surat izin mahasiswa.</p>
    </div>
    <div class="grid grid-cols-2 gap-3">
      <div>
        <label class="text-xs text-slate-400 block mb-1">Semester</label>
        <input type="text" name="semester" value="<?= h($p['semester']) ?>" class="w-full px-3 py-2 rounded-lg bg-slate-800 border border-white/10 text-white text-sm">
      </div>
      <div>
        <label class="text-xs text-slate-400 block mb-1">Tahun Ajaran</label>
        <input type="text" name="tahun_ajaran" value="<?= h($p['tahun_ajaran']) ?>" class="w-full px-3 py-2 rounded-lg bg-slate-800 border border-white/10 text-white text-sm">
      </div>
    </div>
    <div>
      <label class="text-xs text-slate-400 block mb-1">Toleransi Keterlambatan (menit)</label>
      <input type="number" name="toleransi_menit" min="0" value="<?= h($p['toleransi_menit']) ?>" class="w-full px-3 py-2 rounded-lg bg-slate-800 border border-white/10 text-white text-sm">
      <p class="text-xs text-slate-500 mt-1">Scan setelah batas ini akan otomatis diberi catatan "terlambat".</p>
    </div>
  </div>

  <div class="lg:col-span-2">
    <button type="submit" class="px-6 py-2.5 rounded-lg bg-sky-500 hover:bg-sky-400 text-slate-900 font-semibold text-sm">Simpan Pengaturan</button>
  </div>
</form>

<?php include __DIR__ . '/_layout_bottom.php'; ?>

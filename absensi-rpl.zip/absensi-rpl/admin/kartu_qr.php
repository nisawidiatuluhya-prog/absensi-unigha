<?php
require_once __DIR__ . '/../config/database.php';
requireLogin('admin');
$pdo = getDBConnection();
$p = getPengaturan();

$kelasOptions = $pdo->query("SELECT * FROM kelas ORDER BY nama_kelas")->fetchAll();
$filterKelasId = (int)($_GET['kelas'] ?? ($kelasOptions[0]['id'] ?? 0));

$mahasiswaList = [];
if ($filterKelasId) {
    $stmt = $pdo->prepare("SELECT m.*, k.nama_kelas FROM mahasiswa m JOIN kelas k ON k.id = m.kelas_id WHERE m.kelas_id = :kid ORDER BY m.nama");
    $stmt->execute([':kid' => $filterKelasId]);
    $mahasiswaList = $stmt->fetchAll();
}

$pageTitle = 'Cetak Massal Kartu QR';
include __DIR__ . '/_layout_top.php';
?>

<script src="https://cdn.jsdelivr.net/npm/qrcodejs@1.0.0/qrcode.min.js"></script>

<div class="flex flex-col md:flex-row md:items-center justify-between gap-3 mb-6 print:hidden">
  <div>
    <h1 class="text-2xl font-bold text-white">Cetak Massal Kartu QR</h1>
    <p class="text-slate-400 text-sm">Unduh / cetak seluruh kartu mahasiswa dalam satu kelas sekaligus</p>
  </div>
  <div class="flex items-center gap-3">
    <form method="GET">
      <select name="kelas" onchange="this.form.submit()" class="px-3 py-2 rounded-lg bg-slate-800 border border-white/10 text-white text-sm">
        <?php foreach ($kelasOptions as $k): ?>
          <option value="<?= $k['id'] ?>" <?= $filterKelasId == $k['id'] ? 'selected' : '' ?>>Kelas <?= h($k['nama_kelas']) ?></option>
        <?php endforeach; ?>
      </select>
    </form>
    <button onclick="window.print()" class="px-4 py-2 rounded-lg bg-sky-500 hover:bg-sky-400 text-slate-900 font-semibold text-sm">🖨️ Cetak Semua</button>
  </div>
</div>

<?php if (empty($mahasiswaList)): ?>
  <p class="text-slate-500 text-sm print:hidden">Tidak ada mahasiswa pada kelas ini.</p>
<?php else: ?>
  <div class="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-5 print-area" id="grid-kartu">
    <?php foreach ($mahasiswaList as $i => $m): ?>
      <div class="id-card" style="break-inside: avoid; page-break-inside: avoid; margin-bottom: 14px;">
        <div class="id-card-header">
          <p class="font-bold text-white text-sm leading-tight"><?= h($p['nama_kampus']) ?></p>
          <p class="text-[10px] text-white/80 leading-tight">KARTU PESERTA — <?= h($p['nama_mk']) ?></p>
        </div>
        <div class="p-4 flex items-center gap-3">
          <div class="id-avatar" style="width:44px;height:44px;"><?= avatarSvg($m['jenis_kelamin']) ?></div>
          <div class="flex-1 space-y-0.5 text-xs text-slate-700">
            <p class="text-sm font-bold text-slate-900"><?= h($m['nama']) ?></p>
            <p><span class="text-slate-400">NIM</span> <?= h($m['nim']) ?></p>
            <p><span class="text-slate-400">Kelas</span> <?= h($m['nama_kelas']) ?></p>
          </div>
          <div class="qr-slot shrink-0" data-token="<?= h($m['qr_token']) ?>"></div>
        </div>
        <div class="px-4 py-1.5 text-center text-white text-[10px] font-semibold" style="background:#0f172a;">
          Pindai QR untuk absen
        </div>
      </div>
    <?php endforeach; ?>
  </div>

  <script>
    document.querySelectorAll('.qr-slot').forEach(function (slot) {
      new QRCode(slot, {
        text: slot.getAttribute('data-token'),
        width: 72, height: 72,
        colorDark: "#0f172a", colorLight: "#ffffff"
      });
    });
  </script>
<?php endif; ?>

<style>
  @media print {
    #grid-kartu { display: block !important; }
  }
</style>

<?php include __DIR__ . '/_layout_bottom.php'; ?>

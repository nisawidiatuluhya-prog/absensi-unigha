<?php
require_once __DIR__ . '/../config/database.php';
requireLogin('admin');
$pdo = getDBConnection();
$p = getPengaturan();

$kelasOptions = $pdo->query("SELECT * FROM kelas ORDER BY nama_kelas")->fetchAll();
$filterKelasId = (int)($_GET['kelas'] ?? ($kelasOptions[0]['id'] ?? 0));
$kelasAktif = null;
foreach ($kelasOptions as $k) { if ((int)$k['id'] === $filterKelasId) { $kelasAktif = $k; break; } }
if (!$kelasAktif) { die('Kelas tidak ditemukan.'); }

$filterBulan = $_GET['bulan'] ?? date('Y-m');

$hariMapAngka = ['Minggu'=>0,'Senin'=>1,'Selasa'=>2,'Rabu'=>3,'Kamis'=>4,'Jumat'=>5,'Sabtu'=>6];
$targetDow = $hariMapAngka[$kelasAktif['hari']] ?? 1;
$awalBulan = new DateTime($filterBulan . '-01');
$akhirBulan = (clone $awalBulan)->modify('last day of this month');
$tanggalPertemuan = [];
$cursor = clone $awalBulan;
while ($cursor <= $akhirBulan) {
    $tglStr = $cursor->format('Y-m-d');
    if ((int)$cursor->format('w') === $targetDow && !isHariLibur($pdo, $tglStr)) {
        $tanggalPertemuan[] = $tglStr;
    }
    $cursor->modify('+1 day');
}
$hariIniStr = date('Y-m-d');

$mhsStmt = $pdo->prepare("SELECT * FROM mahasiswa WHERE kelas_id = :kid ORDER BY nama");
$mhsStmt->execute([':kid' => $filterKelasId]);
$mhsList = $mhsStmt->fetchAll();

$absensiMap = [];
$absStmt = $pdo->prepare("SELECT mahasiswa_id, tanggal, status FROM absensi WHERE kelas_id = :kid AND DATE_FORMAT(tanggal, '%Y-%m') = :bulan");
$absStmt->execute([':kid' => $filterKelasId, ':bulan' => $filterBulan]);
foreach ($absStmt as $row) { $absensiMap[$row['mahasiswa_id']][$row['tanggal']] = $row['status']; }

$namaFile = 'DHMD_' . preg_replace('/[^A-Za-z0-9]/', '', $kelasAktif['nama_kelas']) . '_' . $filterBulan . '.xls';
header('Content-Type: application/vnd.ms-excel; charset=utf-8');
header('Content-Disposition: attachment; filename="' . $namaFile . '"');
echo "\xEF\xBB\xBF"; // BOM agar karakter Indonesia terbaca benar di Excel
?>
<table border="1">
  <tr><td colspan="<?= 3 + count($tanggalPertemuan) + 4 ?>" style="font-weight:bold;font-size:14pt;text-align:center;"><?= h($p['nama_kampus']) ?></td></tr>
  <tr><td colspan="<?= 3 + count($tanggalPertemuan) + 4 ?>" style="text-align:center;">DAFTAR HADIR MAHASISWA DAN DOSEN (DHMD)</td></tr>
  <tr><td colspan="<?= 3 + count($tanggalPertemuan) + 4 ?>" style="text-align:center;">Matakuliah: <?= h($p['kode_mk']) ?> - <?= h($p['nama_mk']) ?> | Kelas <?= h($kelasAktif['nama_kelas']) ?> | Bulan: <?= date('F Y', strtotime($filterBulan.'-01')) ?></td></tr>
  <tr><td></td></tr>
  <tr>
    <th>No</th>
    <th>Nama</th>
    <th>NIM</th>
    <?php foreach ($tanggalPertemuan as $tgl): ?>
      <th><?= date('d/m', strtotime($tgl)) ?></th>
    <?php endforeach; ?>
    <th>H</th><th>I</th><th>S</th><th>A</th>
  </tr>
  <?php foreach ($mhsList as $i => $m):
      $rec = ['H'=>0,'I'=>0,'S'=>0,'A'=>0];
  ?>
  <tr>
    <td><?= $i + 1 ?></td>
    <td><?= h($m['nama']) ?></td>
    <td><?= h($m['nim']) ?></td>
    <?php foreach ($tanggalPertemuan as $tgl):
        $st = $absensiMap[$m['id']][$tgl] ?? '';
        if ($st === '' && $tgl < $hariIniStr) { $st = 'A'; }
        if ($st !== '') { $rec[$st]++; }
    ?>
      <td style="text-align:center;"><?= h($st) ?></td>
    <?php endforeach; ?>
    <td style="text-align:center;"><?= $rec['H'] ?></td>
    <td style="text-align:center;"><?= $rec['I'] ?></td>
    <td style="text-align:center;"><?= $rec['S'] ?></td>
    <td style="text-align:center;"><?= $rec['A'] ?></td>
  </tr>
  <?php endforeach; ?>
  <tr><td></td></tr>
  <tr><td colspan="3">Dosen Pengampu: <?= h($p['dosen_pengampu']) ?></td></tr>
  <tr><td colspan="3">Kode Verifikasi: <?= h(buatKodeVerifikasi($kelasAktif['id'], $filterBulan, $p['nama_mk'])) ?></td></tr>
</table>

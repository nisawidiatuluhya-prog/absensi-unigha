<?php
require_once __DIR__ . '/../config/database.php';
requireLogin('admin');
$pdo = getDBConnection();
$p = getPengaturan();

// AJAX endpoint mode: kembalikan potongan tabel saja untuk auto-refresh
$isAjax = isset($_GET['ajax']);

function ambilDataMonitoring($pdo) {
    $hariMap = ['Monday'=>'Senin','Tuesday'=>'Selasa','Wednesday'=>'Rabu','Thursday'=>'Kamis','Friday'=>'Jumat','Saturday'=>'Sabtu','Sunday'=>'Minggu'];
    $hariIni = $hariMap[(new DateTime())->format('l')];

    // Kelas yang jadwalnya hari ini
    $stmt = $pdo->prepare("SELECT * FROM kelas WHERE hari = :h ORDER BY jam_mulai");
    $stmt->execute([':h' => $hariIni]);
    $kelasHariIni = $stmt->fetchAll();

    $stmt = $pdo->prepare("
        SELECT a.*, m.nama, m.nim, k.nama_kelas
        FROM absensi a
        JOIN mahasiswa m ON m.id = a.mahasiswa_id
        JOIN kelas k ON k.id = a.kelas_id
        WHERE a.tanggal = CURDATE()
        ORDER BY a.waktu_scan DESC
        LIMIT 100
    ");
    $stmt->execute();
    $absensiHariIni = $stmt->fetchAll();

    return [$hariIni, $kelasHariIni, $absensiHariIni];
}

[$hariIni, $kelasHariIni, $absensiHariIni] = ambilDataMonitoring($pdo);

if ($isAjax) {
    header('Content-Type: text/html; charset=utf-8');
    ?>
    <table class="w-full text-sm">
      <thead>
        <tr class="text-left text-slate-400 border-b border-white/10">
          <th class="py-2 pr-4">Waktu</th>
          <th class="py-2 pr-4">Nama</th>
          <th class="py-2 pr-4">NIM</th>
          <th class="py-2 pr-4">Kelas</th>
          <th class="py-2">Status</th>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($absensiHariIni)): ?>
          <tr><td colspan="5" class="py-4 text-center text-slate-500">Belum ada aktivitas absensi hari ini.</td></tr>
        <?php endif; ?>
        <?php foreach ($absensiHariIni as $a): ?>
          <tr class="border-b border-white/5">
            <td class="py-2 pr-4 text-slate-400"><?= substr($a['waktu_scan'],0,5) ?></td>
            <td class="py-2 pr-4 text-white"><?= h($a['nama']) ?></td>
            <td class="py-2 pr-4 text-slate-300"><?= h($a['nim']) ?></td>
            <td class="py-2 pr-4 text-slate-300"><?= h($a['nama_kelas']) ?></td>
            <td class="py-2"><span class="badge badge-<?= $a['status'] ?>"><?= statusLabel($a['status']) ?><?= $a['keterangan'] === 'Terlambat' ? ' (Terlambat)' : '' ?></span></td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
    <?php
    exit;
}

$pageTitle = 'Live Monitoring';
include __DIR__ . '/_layout_top.php';
?>

<div class="flex items-center justify-between mb-1">
  <h1 class="text-2xl font-bold text-white">Live Monitoring Absensi</h1>
  <span class="badge badge-H" id="live-indicator">● Live</span>
</div>
<p class="text-slate-400 text-sm mb-6">Aktivitas absensi hari ini, <?= date('d F Y') ?> (<?= $hariIni ?>) — otomatis diperbarui setiap 8 detik</p>

<div class="card-navy p-5 mb-6">
  <p class="font-semibold text-white mb-3">Kelas Terjadwal Hari Ini</p>
  <?php if (empty($kelasHariIni)): ?>
    <p class="text-slate-500 text-sm">Tidak ada kelas <?= h($p['nama_mk']) ?> yang terjadwal pada hari <?= $hariIni ?>.</p>
  <?php else: ?>
    <div class="flex flex-wrap gap-3">
      <?php foreach ($kelasHariIni as $k): ?>
        <span class="px-3 py-1.5 rounded-lg bg-slate-800/60 border border-white/10 text-sm text-slate-200">
          Kelas <?= h($k['nama_kelas']) ?> &middot; <?= substr($k['jam_mulai'],0,5) ?>–<?= substr($k['jam_selesai'],0,5) ?>
        </span>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>
</div>

<div class="card-navy p-6" id="monitor-panel">
  <p class="font-semibold text-white mb-4">Aktivitas Absensi Real-Time</p>
  <div id="monitor-table">
    <table class="w-full text-sm">
      <thead>
        <tr class="text-left text-slate-400 border-b border-white/10">
          <th class="py-2 pr-4">Waktu</th>
          <th class="py-2 pr-4">Nama</th>
          <th class="py-2 pr-4">NIM</th>
          <th class="py-2 pr-4">Kelas</th>
          <th class="py-2">Status</th>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($absensiHariIni)): ?>
          <tr><td colspan="5" class="py-4 text-center text-slate-500">Belum ada aktivitas absensi hari ini.</td></tr>
        <?php endif; ?>
        <?php foreach ($absensiHariIni as $a): ?>
          <tr class="border-b border-white/5">
            <td class="py-2 pr-4 text-slate-400"><?= substr($a['waktu_scan'],0,5) ?></td>
            <td class="py-2 pr-4 text-white"><?= h($a['nama']) ?></td>
            <td class="py-2 pr-4 text-slate-300"><?= h($a['nim']) ?></td>
            <td class="py-2 pr-4 text-slate-300"><?= h($a['nama_kelas']) ?></td>
            <td class="py-2"><span class="badge badge-<?= $a['status'] ?>"><?= statusLabel($a['status']) ?><?= $a['keterangan'] === 'Terlambat' ? ' (Terlambat)' : '' ?></span></td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<script>
  setInterval(function () {
    fetch('monitoring.php?ajax=1')
      .then(res => res.text())
      .then(html => { document.getElementById('monitor-table').innerHTML = html; })
      .catch(() => {});
  }, 8000);
</script>

<?php include __DIR__ . '/_layout_bottom.php'; ?>

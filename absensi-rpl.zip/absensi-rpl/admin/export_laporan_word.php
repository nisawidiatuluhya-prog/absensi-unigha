<?php
require_once __DIR__ . '/../config/database.php';
requireLogin('admin');
$pdo = getDBConnection();
$p = getPengaturan();

$kelasOptions = $pdo->query("SELECT * FROM kelas ORDER BY nama_kelas")->fetchAll();
$filterKelasId = (int)($_GET['kelas'] ?? ($kelasOptions[0]['id'] ?? 0));
$kelasAktif = null;
foreach ($kelasOptions as $k) { if ((int)$k['id'] === $filterKelasId) { $kelasAktif = $k; break; } }
if (!$kelasAktif) { die('Kelas tidak ditemukan.'); }

$filterBulan = $_GET['bulan'] ?? date('Y-m');

$hariMapAngka = ['Minggu'=>0,'Selasa'=>2,'Senin'=>1,'Rabu'=>3,'Kamis'=>4,'Jumat'=>5,'Sabtu'=>6];
$targetDow = $hariMapAngka[$kelasAktif['hari']] ?? 1;
$awalBulan = new DateTime($filterBulan . '-01');
$akhirBulan = (clone $awalBulan)->modify('last day of this month');
$tanggalPertemuan = [];
$cursor = clone $awalBulan;
while ($cursor <= $akhirBulan) {
    $tglStr = $cursor->format('Y-m-d');
    if ((int)$cursor->format('w') === $targetDow && !isHariLibur($pdo, $tglStr)) {
        $tanggalPertemuan[] = $tglStr;
    }
    $cursor->modify('+1 day');
}
$hariIniStr = date('Y-m-d');

$mhsStmt = $pdo->prepare("SELECT * FROM mahasiswa WHERE kelas_id = :kid ORDER BY nama");
$mhsStmt->execute([':kid' => $filterKelasId]);
$mhsList = $mhsStmt->fetchAll();

$absensiMap = [];
$absStmt = $pdo->prepare("SELECT mahasiswa_id, tanggal, status FROM absensi WHERE kelas_id = :kid AND DATE_FORMAT(tanggal, '%Y-%m') = :bulan");
$absStmt->execute([':kid' => $filterKelasId, ':bulan' => $filterBulan]);
foreach ($absStmt as $row) { $absensiMap[$row['mahasiswa_id']][$row['tanggal']] = $row['status']; }

$kodeVerifikasi = buatKodeVerifikasi($kelasAktif['id'], $filterBulan, $p['nama_mk']);
$namaFile = 'DHMD_' . preg_replace('/[^A-Za-z0-9]/', '', $kelasAktif['nama_kelas']) . '_' . $filterBulan . '.doc';
header('Content-Type: application/msword; charset=utf-8');
header('Content-Disposition: attachment; filename="' . $namaFile . '"');
?>
<!DOCTYPE html>
<html>
<head><meta charset="UTF-8"><style>
  body { font-family: 'Times New Roman', serif; font-size: 11pt; }
  table { border-collapse: collapse; width: 100%; font-size: 9pt; }
  td, th { border: 1px solid #000; padding: 3px 5px; }
  .center { text-align: center; }
  h2, h3 { text-align: center; margin: 2px 0; }
</style></head>
<body>
  <table style="border:none;width:100%;margin-bottom:10px;">
    <tr style="border:none;">
      <td style="border:none;width:80px;text-align:center;">(LOGO)</td>
      <td style="border:none;text-align:center;">
        <p style="margin:0;font-size:9pt;"><?= h(strtoupper($p['yayasan'])) ?></p>
        <h3><?= h(strtoupper($p['nama_kampus'])) ?></h3>
        <p style="margin:0;font-size:9pt;"><?= h($p['alamat_kampus']) ?></p>
        <h3 style="text-decoration:underline;">DAFTAR HADIR MAHASISWA DAN DOSEN (DHMD)</h3>
      </td>
    </tr>
  </table>
  <p><b>Matakuliah</b> : <?= h($p['kode_mk']) ?> — <?= h($p['nama_mk']) ?><br>
  <b>Kelas / Ruang</b> : <?= h($kelasAktif['nama_kelas']) ?> / <?= h($kelasAktif['ruang'] ?: '-') ?><br>
  <b>Hari / Jam</b> : <?= h($kelasAktif['hari']) ?>, <?= substr($kelasAktif['jam_mulai'],0,5) ?>–<?= substr($kelasAktif['jam_selesai'],0,5) ?><br>
  <b>Dosen Pengampu</b> : <?= h($p['dosen_pengampu']) ?><br>
  <b>Bulan</b> : <?= date('F Y', strtotime($filterBulan . '-01')) ?></p>

  <table>
    <tr>
      <th>No</th><th>Nama</th><th>NIM</th>
      <?php foreach ($tanggalPertemuan as $tgl): ?><th><?= date('d/m', strtotime($tgl)) ?></th><?php endforeach; ?>
      <th>H</th><th>I</th><th>S</th><th>A</th>
    </tr>
    <?php foreach ($mhsList as $i => $m):
        $rec = ['H'=>0,'I'=>0,'S'=>0,'A'=>0];
    ?>
    <tr>
      <td class="center"><?= $i + 1 ?></td>
      <td><?= h($m['nama']) ?></td>
      <td><?= h($m['nim']) ?></td>
      <?php foreach ($tanggalPertemuan as $tgl):
          $st = $absensiMap[$m['id']][$tgl] ?? '';
          if ($st === '' && $tgl < $hariIniStr) { $st = 'A'; }
          if ($st !== '') { $rec[$st]++; }
      ?>
        <td class="center"><?= h($st) ?></td>
      <?php endforeach; ?>
      <td class="center"><?= $rec['H'] ?></td>
      <td class="center"><?= $rec['I'] ?></td>
      <td class="center"><?= $rec['S'] ?></td>
      <td class="center"><?= $rec['A'] ?></td>
    </tr>
    <?php endforeach; ?>
  </table>

  <p style="margin-top:20px;font-size:9pt;">Kode Verifikasi Dokumen: <b><?= h($kodeVerifikasi) ?></b></p>

  <table style="border:none;width:100%;margin-top:30px;">
    <tr style="border:none;">
      <td style="border:none;width:50%;text-align:center;">
        Mengetahui,<br>Ketua Program Studi <?= h($p['prodi']) ?>,<br><br><br><br>
        ( ..................................... )
      </td>
      <td style="border:none;width:50%;text-align:center;">
        Sigli, <?= date('d F Y') ?><br>Dosen Pengampu,<br><br><br><br>
        <b><?= h($p['dosen_pengampu']) ?></b>
      </td>
    </tr>
  </table>
</body>
</html>

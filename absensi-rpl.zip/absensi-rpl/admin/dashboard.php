<?php
require_once __DIR__ . '/../config/database.php';
requireLogin('admin');
$pdo = getDBConnection();
$p = getPengaturan();

// Statistik ringkas
$totalMhs   = $pdo->query("SELECT COUNT(*) c FROM mahasiswa")->fetch()['c'];
$totalKelas = $pdo->query("SELECT COUNT(*) c FROM kelas")->fetch()['c'];
$izinPending = $pdo->query("SELECT COUNT(*) c FROM surat_izin WHERE status_konfirmasi='Pending'")->fetch()['c'];

// Hadir vs Tidak Hadir HARI INI
$hadirHariIni = $pdo->query("SELECT COUNT(*) c FROM absensi WHERE tanggal = CURDATE() AND status = 'H'")->fetch()['c'];
$tidakHadirHariIni = max(0, $totalMhs - $hadirHariIni);

// Rekap kehadiran per status (30 hari terakhir) untuk grafik batang & pie
$stmtStatus = $pdo->query("
    SELECT status, COUNT(*) jumlah FROM absensi
    WHERE tanggal >= (CURDATE() - INTERVAL 30 DAY)
    GROUP BY status
");
$statusCounts = ['H' => 0, 'I' => 0, 'S' => 0, 'A' => 0];
foreach ($stmtStatus as $row) { $statusCounts[$row['status']] = (int)$row['jumlah']; }
$totalAbsensi = array_sum($statusCounts);

// Gender: laki-laki vs perempuan
$stmtGender = $pdo->query("SELECT jenis_kelamin, COUNT(*) c FROM mahasiswa GROUP BY jenis_kelamin");
$genderCounts = ['L' => 0, 'P' => 0];
foreach ($stmtGender as $row) { $genderCounts[$row['jenis_kelamin']] = (int)$row['c']; }

// Kehadiran per kelas (bullet chart)
$stmtKelas = $pdo->query("
    SELECT k.nama_kelas,
           COUNT(a.id) total,
           SUM(CASE WHEN a.status='H' THEN 1 ELSE 0 END) hadir
    FROM kelas k
    LEFT JOIN absensi a ON a.kelas_id = k.id AND a.tanggal >= (CURDATE() - INTERVAL 30 DAY)
    GROUP BY k.id
    ORDER BY k.nama_kelas
");
$kelasStats = $stmtKelas->fetchAll();

// Data untuk donut chart (conic-gradient)
$colors = ['H' => '#22c55e', 'I' => '#facc15', 'S' => '#818cf8', 'A' => '#ef4444'];
$gradientParts = [];
$cursor = 0;
foreach ($statusCounts as $key => $val) {
    if ($totalAbsensi === 0) break;
    $deg = ($val / $totalAbsensi) * 360;
    $gradientParts[] = $colors[$key] . ' ' . $cursor . 'deg ' . ($cursor + $deg) . 'deg';
    $cursor += $deg;
}
$donutStyle = $totalAbsensi > 0 ? 'background: conic-gradient(' . implode(', ', $gradientParts) . ');' : 'background:#273548;';

// Kelas untuk widget edit jadwal cepat
$semuaKelas = $pdo->query("SELECT * FROM kelas ORDER BY nama_kelas")->fetchAll();

// Tren kehadiran 14 hari terakhir (untuk grafik batang Chart.js)
$stmtTren = $pdo->query("
    SELECT tanggal, SUM(CASE WHEN status='H' THEN 1 ELSE 0 END) hadir, COUNT(*) total
    FROM absensi
    WHERE tanggal >= (CURDATE() - INTERVAL 13 DAY)
    GROUP BY tanggal
    ORDER BY tanggal
");
$trenMap = [];
foreach ($stmtTren as $row) { $trenMap[$row['tanggal']] = (int)$row['hadir']; }
$trenLabels = []; $trenData = [];
for ($i = 13; $i >= 0; $i--) {
    $tgl = date('Y-m-d', strtotime("-$i day"));
    $trenLabels[] = date('d/m', strtotime($tgl));
    $trenData[] = $trenMap[$tgl] ?? 0;
}

$pageTitle = 'Dashboard Admin';
include __DIR__ . '/_layout_top.php';
?>

<h1 class="text-2xl font-bold text-white mb-1">Dashboard Admin</h1>
<p class="text-slate-400 text-sm mb-6"><?= h($p['nama_mk']) ?> &middot; <?= h($totalKelas) ?> Kelas &middot; Ringkasan 30 hari terakhir</p>

<!-- KARTU STATISTIK -->
<div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
  <div class="card-navy p-5">
    <p class="text-slate-400 text-xs mb-1">Total Mahasiswa</p>
    <p class="text-2xl font-bold text-white"><?= $totalMhs ?></p>
  </div>
  <div class="card-navy p-5">
    <p class="text-slate-400 text-xs mb-1">Jumlah Kelas</p>
    <p class="text-2xl font-bold text-white"><?= $totalKelas ?></p>
  </div>
  <div class="card-navy p-5">
    <p class="text-slate-400 text-xs mb-1">Hadir Hari Ini</p>
    <p class="text-2xl font-bold text-emerald-400"><?= $hadirHariIni ?></p>
  </div>
  <div class="card-navy p-5">
    <p class="text-slate-400 text-xs mb-1">Izin Menunggu</p>
    <p class="text-2xl font-bold text-yellow-400"><?= $izinPending ?></p>
  </div>
</div>

<div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
  <!-- GRAFIK BATANG STATUS KEHADIRAN -->
  <div class="card-navy p-6">
    <p class="font-semibold text-white mb-4">Grafik Batang — Status Kehadiran (30 Hari)</p>
    <?php foreach (['H' => ['Hadir', 'bg-emerald-500'], 'I' => ['Izin', 'bg-amber-400'], 'S' => ['Sakit', 'bg-indigo-400'], 'A' => ['Alpa', 'bg-red-500']] as $key => [$label, $color]):
        $pct = $totalAbsensi > 0 ? round($statusCounts[$key] / $totalAbsensi * 100) : 0;
    ?>
    <div class="mb-4">
      <div class="flex justify-between text-sm text-slate-300 mb-1">
        <span><?= $label ?></span>
        <span><?= $statusCounts[$key] ?> (<?= $pct ?>%)</span>
      </div>
      <div class="progress-bar-track">
        <div class="<?= $color ?> h-full rounded-full" style="width: <?= $pct ?>%"></div>
      </div>
    </div>
    <?php endforeach; ?>
  </div>

  <!-- PIE / DONUT CHART KEHADIRAN -->
  <div class="card-navy p-6 flex flex-col sm:flex-row items-center gap-6">
    <div>
      <p class="font-semibold text-white mb-4">Diagram Bulat — Distribusi Kehadiran</p>
      <div class="donut-chart" style="<?= $donutStyle ?>">
        <div class="donut-chart-inner">
          <p class="text-white font-bold text-lg"><?= $totalAbsensi ?></p>
          <p class="text-slate-500 text-[10px]">total absen</p>
        </div>
      </div>
    </div>
    <div class="space-y-2 text-sm">
      <?php foreach (['H'=>'Hadir','I'=>'Izin','S'=>'Sakit','A'=>'Alpa'] as $key => $label): ?>
        <div class="flex items-center gap-2">
          <span class="w-3 h-3 rounded-full inline-block" style="background:<?= $colors[$key] ?>"></span>
          <span class="text-slate-300"><?= $label ?></span>
          <span class="text-slate-500">(<?= $statusCounts[$key] ?>)</span>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</div>

<div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
  <!-- HADIR VS TIDAK HADIR HARI INI -->
  <div class="card-navy p-6">
    <p class="font-semibold text-white mb-4">Hadir vs Tidak Hadir Hari Ini</p>
    <div class="space-y-3">
      <div>
        <div class="flex justify-between text-sm text-slate-300 mb-1"><span>Hadir</span><span><?= $hadirHariIni ?> mhs</span></div>
        <div class="compare-bar-row">
          <div class="compare-bar-track"><div class="compare-bar-fill bg-emerald-500" style="width: <?= $totalMhs > 0 ? round($hadirHariIni/$totalMhs*100) : 0 ?>%"></div></div>
        </div>
      </div>
      <div>
        <div class="flex justify-between text-sm text-slate-300 mb-1"><span>Tidak Hadir</span><span><?= $tidakHadirHariIni ?> mhs</span></div>
        <div class="compare-bar-row">
          <div class="compare-bar-track"><div class="compare-bar-fill bg-red-500" style="width: <?= $totalMhs > 0 ? round($tidakHadirHariIni/$totalMhs*100) : 0 ?>%"></div></div>
        </div>
      </div>
    </div>
    <p class="text-xs text-slate-500 mt-3">Dihitung dari total <?= $totalMhs ?> mahasiswa terdaftar hari ini, <?= date('d M Y') ?>.</p>
  </div>

  <!-- PERBANDINGAN GENDER -->
  <div class="card-navy p-6">
    <p class="font-semibold text-white mb-4">Diagram Perbandingan Gender</p>
    <?php $totalGender = $genderCounts['L'] + $genderCounts['P']; ?>
    <div class="space-y-3">
      <div>
        <div class="flex justify-between text-sm text-slate-300 mb-1"><span>Laki-laki</span><span><?= $genderCounts['L'] ?> mhs</span></div>
        <div class="compare-bar-row">
          <div class="compare-bar-track"><div class="compare-bar-fill bg-sky-500" style="width: <?= $totalGender > 0 ? round($genderCounts['L']/$totalGender*100) : 0 ?>%"></div></div>
        </div>
      </div>
      <div>
        <div class="flex justify-between text-sm text-slate-300 mb-1"><span>Perempuan</span><span><?= $genderCounts['P'] ?> mhs</span></div>
        <div class="compare-bar-row">
          <div class="compare-bar-track"><div class="compare-bar-fill bg-pink-400" style="width: <?= $totalGender > 0 ? round($genderCounts['P']/$totalGender*100) : 0 ?>%"></div></div>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- BULLET CHART PER KELAS -->
<div class="card-navy p-6">
  <p class="font-semibold text-white mb-4">Kehadiran per Kelas (30 Hari)</p>
  <?php if (empty($kelasStats)): ?>
    <p class="text-slate-500 text-sm">Belum ada data kelas.</p>
  <?php endif; ?>
  <?php foreach ($kelasStats as $ks):
      $pct = $ks['total'] > 0 ? round($ks['hadir'] / $ks['total'] * 100) : 0;
  ?>
  <div class="mb-4">
    <div class="flex justify-between text-sm text-slate-300 mb-1">
      <span>Kelas <?= h($ks['nama_kelas']) ?></span>
      <span><?= $pct ?>%</span>
    </div>
    <div class="progress-bar-track relative">
      <div class="progress-bar-fill" style="width: <?= $pct ?>%"></div>
      <div class="absolute top-0 h-full border-l-2 border-white/70" style="left: 80%"></div>
    </div>
  </div>
  <?php endforeach; ?>
  <p class="text-xs text-slate-500 mt-2">Garis putih menandai target kehadiran minimum (80%).</p>
</div>

<!-- TREN KEHADIRAN 14 HARI (CHART.JS) -->
<div class="card-navy p-6 mb-6">
  <p class="font-semibold text-white mb-4">Tren Kehadiran 14 Hari Terakhir</p>
  <canvas id="trenChart" height="90"></canvas>
</div>

<!-- WIDGET EDIT JADWAL CEPAT -->
<div class="card-navy p-6 mb-6">
  <p class="font-semibold text-white mb-1">Jadwal & Jam Masuk Kelas</p>
  <p class="text-slate-500 text-xs mb-4">Edit jam kuliah langsung dari sini tanpa perlu buka menu Data Kelas</p>
  <div class="overflow-x-auto">
    <table class="w-full text-sm">
      <thead>
        <tr class="text-left text-slate-400 border-b border-white/10">
          <th class="py-2 pr-4">Kelas</th>
          <th class="py-2 pr-4">Hari</th>
          <th class="py-2 pr-4">Jam Masuk</th>
          <th class="py-2 pr-4">Jam Selesai</th>
          <th class="py-2">Aksi</th>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($semuaKelas)): ?>
          <tr><td colspan="5" class="py-4 text-center text-slate-500">Belum ada data kelas.</td></tr>
        <?php endif; ?>
        <?php foreach ($semuaKelas as $k): ?>
          <tr class="border-b border-white/5">
            <td class="py-2 pr-4 text-white"><?= h($k['nama_kelas']) ?></td>
            <td class="py-2 pr-4 text-slate-300"><?= h($k['hari']) ?></td>
            <td class="py-2 pr-4 text-slate-300"><?= substr($k['jam_mulai'],0,5) ?></td>
            <td class="py-2 pr-4 text-slate-300"><?= substr($k['jam_selesai'],0,5) ?></td>
            <td class="py-2">
              <button onclick='bukaEditJadwal(<?= json_encode($k) ?>)' class="text-sky-400 hover:text-sky-300 text-xs">Edit Jam</button>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<!-- MODAL EDIT JADWAL (posting ke kelas.php) -->
<div id="modalEditJadwal" class="hidden fixed inset-0 bg-black/60 flex items-center justify-center p-4 z-50">
  <div class="card-navy p-6 w-full max-w-md">
    <p class="font-semibold text-white mb-4">Edit Jam Masuk Kelas</p>
    <form method="POST" action="kelas.php" class="space-y-3">
      <input type="hidden" name="action" value="edit">
      <input type="hidden" name="id" id="ej_id">
      <input type="text" name="nama_kelas" id="ej_nama" required class="w-full px-3 py-2 rounded-lg bg-slate-800 border border-white/10 text-white text-sm">
      <input type="text" name="ruang" id="ej_ruang" class="w-full px-3 py-2 rounded-lg bg-slate-800 border border-white/10 text-white text-sm">
      <div class="grid grid-cols-3 gap-2">
        <select name="hari" id="ej_hari" class="px-3 py-2 rounded-lg bg-slate-800 border border-white/10 text-white text-sm">
          <?php foreach (['Senin','Selasa','Rabu','Kamis','Jumat','Sabtu'] as $h): ?><option value="<?= $h ?>"><?= $h ?></option><?php endforeach; ?>
        </select>
        <input type="time" name="jam_mulai" id="ej_mulai" required class="px-3 py-2 rounded-lg bg-slate-800 border border-white/10 text-white text-sm">
        <input type="time" name="jam_selesai" id="ej_selesai" required class="px-3 py-2 rounded-lg bg-slate-800 border border-white/10 text-white text-sm">
      </div>
      <div class="flex gap-3 pt-2">
        <button type="button" onclick="document.getElementById('modalEditJadwal').classList.add('hidden')"
          class="flex-1 py-2 rounded-lg bg-slate-700 hover:bg-slate-600 text-white text-sm">Batal</button>
        <button type="submit" class="flex-1 py-2 rounded-lg bg-sky-500 hover:bg-sky-400 text-slate-900 font-semibold text-sm">Simpan</button>
      </div>
    </form>
  </div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.0/chart.umd.min.js"></script>
<script>
function bukaEditJadwal(k) {
  document.getElementById('ej_id').value = k.id;
  document.getElementById('ej_nama').value = k.nama_kelas;
  document.getElementById('ej_ruang').value = k.ruang || '';
  document.getElementById('ej_hari').value = k.hari;
  document.getElementById('ej_mulai').value = k.jam_mulai.substring(0,5);
  document.getElementById('ej_selesai').value = k.jam_selesai.substring(0,5);
  document.getElementById('modalEditJadwal').classList.remove('hidden');
}

new Chart(document.getElementById('trenChart'), {
  type: 'bar',
  data: {
    labels: <?= json_encode($trenLabels) ?>,
    datasets: [{
      label: 'Mahasiswa Hadir',
      data: <?= json_encode($trenData) ?>,
      backgroundColor: 'rgba(56,189,248,0.6)',
      borderRadius: 4
    }]
  },
  options: {
    plugins: { legend: { display: false } },
    scales: {
      x: { ticks: { color: '#94a3b8' }, grid: { display: false } },
      y: { ticks: { color: '#94a3b8', stepSize: 1 }, grid: { color: 'rgba(255,255,255,0.05)' } }
    }
  }
});
</script>

<?php include __DIR__ . '/_layout_bottom.php'; ?>

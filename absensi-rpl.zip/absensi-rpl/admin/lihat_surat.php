<?php
require_once __DIR__ . '/../config/database.php';
requireLogin('admin');
$pdo = getDBConnection();
$p = getPengaturan();

$id = (int)($_GET['id'] ?? 0);

$stmt = $pdo->prepare("
    SELECT si.*, m.nama, m.nim, k.nama_kelas
    FROM surat_izin si
    JOIN mahasiswa m ON m.id = si.mahasiswa_id
    JOIN kelas k ON k.id = si.kelas_id
    WHERE si.id = :id
");
$stmt->execute([':id' => $id]);
$surat = $stmt->fetch();

if (!$surat) {
    header('Location: izin.php');
    exit;
}

$pageTitle = 'Surat ' . $surat['jenis'] . ' — ' . $surat['nama'];
include __DIR__ . '/_layout_top.php';
?>

<div class="flex items-center justify-between mb-6 print:hidden">
  <div>
    <h1 class="text-2xl font-bold text-white">Surat <?= h($surat['jenis']) ?> — <?= h($surat['nama']) ?></h1>
    <p class="text-slate-400 text-sm">NIM <?= h($surat['nim']) ?> &middot; Kelas <?= h($surat['nama_kelas']) ?></p>
  </div>
  <a href="izin.php" class="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-white text-sm">&larr; Kembali</a>
</div>

<div class="max-w-2xl">
  <div class="card-navy p-6 print-area">
    <div class="mb-4 print:hidden">
      <span class="badge badge-<?= h($surat['status_konfirmasi']) ?>"><?= h($surat['status_konfirmasi']) ?></span>
    </div>
    <div class="bg-white text-slate-900 rounded-lg p-6 text-sm leading-relaxed" id="surat-cetak">
      <div class="text-center border-b-2 border-slate-800 pb-3 mb-4">
        <p class="font-bold text-base uppercase"><?= h($p['nama_kampus']) ?></p>
        <p class="text-xs"><?= h($p['alamat_kampus']) ?></p>
        <p class="text-xs"><?= h($p['fakultas']) ?> — <?= h($p['prodi']) ?></p>
      </div>
      <p class="text-center font-semibold underline mb-4">SURAT <?= strtoupper($surat['jenis']) ?> TIDAK MENGIKUTI PERKULIAHAN</p>
      <p class="mb-3">Yang bertanda tangan di bawah ini menerangkan bahwa:</p>
      <table class="mb-3">
        <tr><td class="pr-3 align-top">Nama</td><td class="pr-2">:</td><td><?= h($surat['nama']) ?></td></tr>
        <tr><td class="pr-3 align-top">NIM</td><td class="pr-2">:</td><td><?= h($surat['nim']) ?></td></tr>
        <tr><td class="pr-3 align-top">Kelas</td><td class="pr-2">:</td><td><?= h($surat['nama_kelas']) ?></td></tr>
        <tr><td class="pr-3 align-top">Mata Kuliah</td><td class="pr-2">:</td><td><?= h($p['nama_mk']) ?></td></tr>
        <tr><td class="pr-3 align-top">Tanggal</td><td class="pr-2">:</td><td><?= date('d F Y', strtotime($surat['tanggal_izin'])) ?></td></tr>
      </table>
      <p class="mb-2">Dengan alasan sebagai berikut:</p>
      <p class="mb-6 italic">"<?= h($surat['alasan']) ?>"</p>
      <p class="mb-8">Demikian surat ini dibuat untuk dapat dipergunakan sebagaimana mestinya.</p>

      <div class="grid grid-cols-2 gap-6 text-center mt-10">
        <div>
          <p class="mb-16">Mengetahui,<br>Ketua Tingkat (Komting)</p>
          <p class="border-t border-slate-800 pt-1">( ____________________ )</p>
        </div>
        <div>
          <p class="mb-16">Menyetujui,<br>Dosen Pengampu</p>
          <p class="border-t border-slate-800 pt-1"><?= h($p['dosen_pengampu']) ?></p>
        </div>
      </div>
    </div>

    <div class="flex flex-col sm:flex-row gap-2 mt-4 print:hidden">
      <button onclick="window.print()" class="flex-1 py-2.5 rounded-lg bg-slate-700 hover:bg-slate-600 text-white text-sm">🖨️ Cetak Surat</button>
      <button onclick="unduhSurat()" class="flex-1 py-2.5 rounded-lg bg-sky-500 hover:bg-sky-400 text-slate-900 font-semibold text-sm">⬇️ Unduh Surat (PNG)</button>
      <?php if ($surat['status_konfirmasi'] === 'Pending'): ?>
        <a href="izin.php?aksi=setuju&id=<?= $surat['id'] ?>" class="flex-1 text-center py-2.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-sm font-semibold">✔️ Setujui</a>
        <a href="izin.php?aksi=tolak&id=<?= $surat['id'] ?>" class="flex-1 text-center py-2.5 rounded-lg bg-red-700 hover:bg-red-600 text-white text-sm font-semibold">✖️ Tolak</a>
      <?php endif; ?>
    </div>
  </div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>
<script>
  function unduhSurat() {
    html2canvas(document.getElementById('surat-cetak'), { backgroundColor: '#ffffff', scale: 2 }).then(function (canvas) {
      const link = document.createElement('a');
      link.download = 'surat-<?= h($surat['jenis']) ?>-<?= h(preg_replace('/[^A-Za-z0-9]/', '', $surat['nim'])) ?>.png';
      link.href = canvas.toDataURL('image/png');
      link.click();
    });
  }
</script>

<?php include __DIR__ . '/_layout_bottom.php'; ?>

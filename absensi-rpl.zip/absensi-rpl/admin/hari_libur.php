<?php
require_once __DIR__ . '/../config/database.php';
requireLogin('admin');
$pdo = getDBConnection();
$p = getPengaturan();

$msg = ''; $msgType = 'success';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'tambah') {
    $tanggal = $_POST['tanggal'] ?? '';
    $keterangan = trim($_POST['keterangan'] ?? '');
    if ($tanggal === '') {
        $msg = 'Tanggal wajib diisi.'; $msgType = 'error';
    } else {
        try {
            $stmt = $pdo->prepare("INSERT INTO hari_libur (tanggal, keterangan) VALUES (:t, :k)");
            $stmt->execute([':t' => $tanggal, ':k' => $keterangan ?: null]);
            $msg = 'Tanggal libur berhasil ditambahkan.';
        } catch (Exception $e) {
            $msg = 'Tanggal tersebut sudah ditandai sebagai hari libur.'; $msgType = 'error';
        }
    }
}

if (isset($_GET['hapus'])) {
    $pdo->prepare("DELETE FROM hari_libur WHERE id = :id")->execute([':id' => (int)$_GET['hapus']]);
    $msg = 'Tanggal libur berhasil dihapus.';
}

$bulanFilter = $_GET['bulan'] ?? date('Y-m');
$stmt = $pdo->prepare("SELECT * FROM hari_libur WHERE DATE_FORMAT(tanggal, '%Y-%m') = :b ORDER BY tanggal");
$stmt->execute([':b' => $bulanFilter]);
$liburBulanIni = $stmt->fetchAll();
$liburTanggalSet = array_column($liburBulanIni, 'keterangan', 'tanggal');
$liburIdSet = array_column($liburBulanIni, 'id', 'tanggal');

// Data untuk grid kalender bulan berjalan
$awalBulanCal = new DateTime($bulanFilter . '-01');
$akhirBulanCal = (clone $awalBulanCal)->modify('last day of this month');
$offsetAwal = (int)$awalBulanCal->format('w'); // 0=Minggu
$jumlahHari = (int)$akhirBulanCal->format('d');
$bulanSebelum = (clone $awalBulanCal)->modify('-1 month')->format('Y-m');
$bulanSesudah = (clone $awalBulanCal)->modify('+1 month')->format('Y-m');

$semuaLibur = $pdo->query("SELECT * FROM hari_libur ORDER BY tanggal DESC LIMIT 100")->fetchAll();

$pageTitle = 'Kalender Hari Libur';
include __DIR__ . '/_layout_top.php';
?>

<h1 class="text-2xl font-bold text-white mb-1">Kalender Hari Libur</h1>
<p class="text-slate-400 text-sm mb-6">Tanggal yang ditandai di sini tidak akan dihitung sebagai pertemuan / Alfa pada Laporan Resmi, dan mahasiswa tidak dapat melakukan absensi pada tanggal tersebut.</p>

<?php if ($msg): ?>
  <div class="mb-5 px-4 py-3 rounded-lg text-sm <?= $msgType === 'error' ? 'bg-red-900/40 border border-red-700/40 text-red-300' : 'bg-emerald-900/40 border border-emerald-700/40 text-emerald-300' ?>">
    <?= h($msg) ?>
  </div>
<?php endif; ?>

<div class="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
  <!-- KALENDER VISUAL -->
  <div class="lg:col-span-2 card-navy p-6">
    <div class="flex items-center justify-between mb-4">
      <a href="?bulan=<?= $bulanSebelum ?>" class="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-white text-sm">‹ Bulan Lalu</a>
      <p class="font-semibold text-white"><?= date('F Y', strtotime($bulanFilter . '-01')) ?></p>
      <a href="?bulan=<?= $bulanSesudah ?>" class="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-white text-sm">Bulan Depan ›</a>
    </div>
    <div class="grid grid-cols-7 gap-1.5 text-center text-[11px] text-slate-500 mb-2">
      <div>Min</div><div>Sen</div><div>Sel</div><div>Rab</div><div>Kam</div><div>Jum</div><div>Sab</div>
    </div>
    <div class="grid grid-cols-7 gap-1.5" id="grid-kalender">
      <?php for ($i = 0; $i < $offsetAwal; $i++): ?>
        <div></div>
      <?php endfor; ?>
      <?php for ($d = 1; $d <= $jumlahHari; $d++):
          $tglStr = sprintf('%s-%02d', $bulanFilter, $d);
          $isLibur = array_key_exists($tglStr, $liburTanggalSet);
          $isMinggu = ((($offsetAwal + $d - 1) % 7) === 0);
      ?>
        <?php if ($isLibur): ?>
          <a href="?hapus=<?= $liburIdSet[$tglStr] ?>&bulan=<?= $bulanFilter ?>" onclick="return confirm('Hapus tanggal libur <?= $d ?>?')"
             title="<?= h($liburTanggalSet[$tglStr] ?: 'Hari Libur') ?> — klik untuk hapus"
             class="aspect-square rounded-lg bg-red-500/20 border border-red-500/50 text-red-300 flex items-center justify-center text-sm font-semibold hover:bg-red-500/30 transition">
            <?= $d ?>
          </a>
        <?php else: ?>
          <button type="button" onclick="tandaiLibur('<?= $tglStr ?>', <?= $d ?>)"
             class="aspect-square rounded-lg bg-slate-800/60 border border-white/5 <?= $isMinggu ? 'text-red-400/70' : 'text-slate-300' ?> flex items-center justify-center text-sm hover:bg-sky-500/20 hover:border-sky-400/40 transition">
            <?= $d ?>
          </button>
        <?php endif; ?>
      <?php endfor; ?>
    </div>
    <p class="text-xs text-slate-500 mt-4">🔴 Tanggal merah = hari libur &nbsp;&middot;&nbsp; Klik tanggal biasa untuk menandainya sebagai libur, klik tanggal merah untuk menghapusnya.</p>
  </div>

  <div class="card-navy p-6">
    <p class="font-semibold text-white mb-4">Tambah Tanggal Libur</p>
    <form method="POST" class="space-y-3">
      <input type="hidden" name="action" value="tambah">
      <div>
        <label class="text-xs text-slate-400 block mb-1">Tanggal</label>
        <input type="date" name="tanggal" required class="w-full px-3 py-2 rounded-lg bg-slate-800 border border-white/10 text-white text-sm">
      </div>
      <div>
        <label class="text-xs text-slate-400 block mb-1">Keterangan (opsional)</label>
        <input type="text" name="keterangan" placeholder="cth: Cuti Bersama, Libur Nasional" class="w-full px-3 py-2 rounded-lg bg-slate-800 border border-white/10 text-white text-sm">
      </div>
      <button class="w-full py-2.5 rounded-lg bg-sky-500 hover:bg-sky-400 text-slate-900 font-semibold text-sm">Tandai Libur</button>
    </form>
  </div>
</div>

<!-- FORM TERSEMBUNYI UNTUK QUICK-ADD DARI KALENDER -->
<form method="POST" id="form-quick-libur" class="hidden">
  <input type="hidden" name="action" value="tambah">
  <input type="hidden" name="tanggal" id="quick-tanggal">
  <input type="hidden" name="keterangan" id="quick-keterangan">
</form>
<script>
  function tandaiLibur(tanggal, hari) {
    const ket = prompt('Keterangan untuk tanggal ' + hari + ' (opsional):', 'Hari Libur');
    if (ket === null) return; // batal
    document.getElementById('quick-tanggal').value = tanggal;
    document.getElementById('quick-keterangan').value = ket;
    document.getElementById('form-quick-libur').submit();
  }
</script>

<div class="card-navy p-6">
  <p class="font-semibold text-white mb-4">Daftar Hari Libur Terbaru</p>
  <div class="overflow-x-auto max-h-[420px] overflow-y-auto">
    <table class="w-full text-sm">
      <thead>
        <tr class="text-left text-slate-400 border-b border-white/10 sticky top-0" style="background-color:var(--navy-900,#1e293b);">
          <th class="py-2 pr-4">Tanggal</th>
          <th class="py-2 pr-4">Keterangan</th>
          <th class="py-2">Aksi</th>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($semuaLibur)): ?>
          <tr><td colspan="3" class="py-4 text-center text-slate-500">Belum ada tanggal libur yang ditandai.</td></tr>
        <?php endif; ?>
        <?php foreach ($semuaLibur as $l): ?>
          <tr class="border-b border-white/5">
            <td class="py-2 pr-4 text-white"><?= date('d F Y (l)', strtotime($l['tanggal'])) ?></td>
            <td class="py-2 pr-4 text-slate-400"><?= h($l['keterangan'] ?: '-') ?></td>
            <td class="py-2">
              <a href="?hapus=<?= $l['id'] ?>" onclick="return confirm('Hapus tanggal libur ini?')" class="text-red-400 hover:text-red-300 text-xs">Hapus</a>
            </td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<?php include __DIR__ . '/_layout_bottom.php'; ?>

<?php
require_once __DIR__ . '/config/database.php';
$p = getPengaturan();
$pdo = getDBConnection();

$kelasOptions = $pdo->query("SELECT * FROM kelas ORDER BY nama_kelas")->fetchAll();

$error = '';
$success = false;
$namaTampil = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama     = trim($_POST['nama'] ?? '');
    $nim      = trim($_POST['nim'] ?? '');
    $jk       = ($_POST['jenis_kelamin'] ?? 'L') === 'P' ? 'P' : 'L';
    $alamat   = trim($_POST['alamat'] ?? '');
    $kelasId  = (int)($_POST['kelas_id'] ?? 0);
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $konfirmasi = $_POST['konfirmasi'] ?? '';

    // Cek apakah NIM sudah didaftarkan dosen/admin (data ada, akun belum ada)
    $stmtCek = $pdo->prepare("SELECT id, nama, user_id FROM mahasiswa WHERE nim = :nim LIMIT 1");
    $stmtCek->execute([':nim' => $nim]);
    $dataTerdaftar = $stmtCek->fetch();

    if ($nim === '' || $username === '' || $password === '') {
        $error = 'NIM, username, dan password wajib diisi.';
    } elseif (!$dataTerdaftar && ($nama === '' || $kelasId === 0)) {
        $error = 'NIM Anda belum terdaftar di sistem. Lengkapi Nama dan Kelas, atau hubungi dosen pengampu.';
    } elseif ($password !== $konfirmasi) {
        $error = 'Konfirmasi password tidak sama.';
    } elseif (strlen($password) < 6) {
        $error = 'Password minimal 6 karakter.';
    } else {
        $stmt = $pdo->prepare("SELECT id FROM users WHERE username = :u");
        $stmt->execute([':u' => $username]);
        if ($stmt->fetch()) {
            $error = 'Username sudah digunakan, silakan pilih username lain.';
        } else {
            if ($dataTerdaftar && !empty($dataTerdaftar['user_id'])) {
                $error = 'NIM ini sudah memiliki akun. Silakan login, atau hubungi dosen bila lupa password.';
            } else {
                try {
                    $pdo->beginTransaction();

                    $stmt = $pdo->prepare("INSERT INTO users (username, password, role) VALUES (:u, :p, 'mahasiswa')");
                    $stmt->execute([':u' => $username, ':p' => password_hash($password, PASSWORD_DEFAULT)]);
                    $userId = $pdo->lastInsertId();

                    if ($dataTerdaftar) {
                        // KLAIM DATA: nama, NIM, dan kelas mengikuti data resmi dari dosen
                        $stmt = $pdo->prepare("
                            UPDATE mahasiswa
                            SET user_id = :uid,
                                jenis_kelamin = :jk,
                                alamat = CASE WHEN :alamat1 <> '' THEN :alamat2 ELSE alamat END,
                                qr_token = CASE WHEN qr_token IS NULL OR qr_token = '' THEN :token ELSE qr_token END
                            WHERE id = :id
                        ");
                        $stmt->execute([
                            ':uid' => $userId, ':jk' => $jk,
                            ':alamat1' => $alamat, ':alamat2' => $alamat,
                            ':token' => 'STD-' . strtoupper(bin2hex(random_bytes(6))),
                            ':id' => $dataTerdaftar['id']
                        ]);
                        $namaTampil = $dataTerdaftar['nama'];
                    } else {
                        // Mahasiswa benar-benar baru (belum ada di data dosen)
                        $qrToken = 'STD-' . strtoupper(bin2hex(random_bytes(6)));
                        $stmt = $pdo->prepare("
                            INSERT INTO mahasiswa (user_id, nama, nim, jenis_kelamin, alamat, kelas_id, qr_token)
                            VALUES (:uid, :nama, :nim, :jk, :alamat, :kelas_id, :token)
                        ");
                        $stmt->execute([
                            ':uid' => $userId, ':nama' => $nama, ':nim' => $nim, ':jk' => $jk,
                            ':alamat' => $alamat, ':kelas_id' => $kelasId, ':token' => $qrToken
                        ]);
                        $namaTampil = $nama;
                    }

                    $pdo->commit();
                    $success = true;
                } catch (Exception $e) {
                    $pdo->rollBack();
                    $error = 'Pendaftaran gagal: ' . $e->getMessage();
                }
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Daftar Akun Mahasiswa | Absensi Unigha</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<script src="https://cdn.tailwindcss.com"></script>
<link rel="stylesheet" href="assets/css/style.css">
</head>
<body class="min-h-screen flex items-center justify-center px-4 py-10">
  <div class="w-full max-w-lg">
    <div class="text-center mb-6">
      <div class="w-14 h-14 mx-auto mb-3 rounded-xl bg-gradient-to-br from-sky-400 to-indigo-500 flex items-center justify-center font-bold text-slate-900 text-lg">AU</div>
      <h1 class="text-xl font-bold text-white">Daftar Akun Mahasiswa</h1>
      <p class="text-sm text-slate-400"><?= h($p['nama_kampus']) ?> — <?= h($p['nama_mk']) ?></p>
    </div>

    <div class="card-navy p-8">
      <?php if ($success): ?>
        <div class="text-center py-4">
          <div class="w-14 h-14 mx-auto mb-4 rounded-full bg-emerald-500/20 border border-emerald-400/40 flex items-center justify-center text-2xl">✔</div>
          <p class="text-white font-semibold mb-1">Pendaftaran Berhasil!</p>
          <?php if (!empty($namaTampil)): ?>
            <p class="text-sky-300 text-sm mb-1">Selamat datang, <b><?= h($namaTampil) ?></b></p>
          <?php endif; ?>
          <p class="text-slate-400 text-sm mb-6">Akun Anda sudah aktif. Silakan login untuk melihat kartu digital &amp; QR code Anda.</p>
          <a href="login.php?role=mahasiswa" class="inline-block px-6 py-2.5 rounded-lg bg-sky-500 hover:bg-sky-400 text-slate-900 font-semibold text-sm">
            Masuk Sekarang
          </a>
        </div>
      <?php else: ?>

        <?php if ($error): ?>
          <div class="mb-4 px-4 py-3 rounded-lg bg-red-900/40 border border-red-700/40 text-red-300 text-sm">
            <?= h($error) ?>
          </div>
        <?php endif; ?>

        <form method="POST" class="space-y-3">
          <p class="text-xs font-semibold text-sky-400 uppercase tracking-wide mb-1">Data Mahasiswa</p>
          <div class="mb-3 px-3 py-2 rounded-lg bg-sky-900/30 border border-sky-700/40 text-sky-200 text-xs leading-relaxed">
            Nama &amp; kelas Anda sudah diinput dosen. Cukup isi <b>NIM</b> + <b>username</b> + <b>password</b>,
            sistem akan mencocokkan otomatis. Isi Nama &amp; Kelas hanya bila NIM Anda belum terdaftar.
          </div>
          <div>
            <label class="text-sm text-slate-400 block mb-1">Nama Lengkap <span class="text-slate-600">(opsional)</span></label>
            <input type="text" name="nama" value="<?= h($_POST['nama'] ?? '') ?>"
              class="w-full px-4 py-2.5 rounded-lg bg-slate-800 border border-white/10 text-white text-sm focus:outline-none focus:border-sky-400">
          </div>
          <div class="grid grid-cols-2 gap-3">
            <div>
              <label class="text-sm text-slate-400 block mb-1">NIM <span class="text-sky-400">*</span></label>
              <input type="text" name="nim" required value="<?= h($_POST['nim'] ?? '') ?>"
                class="w-full px-4 py-2.5 rounded-lg bg-slate-800 border border-white/10 text-white text-sm focus:outline-none focus:border-sky-400">
            </div>
            <div>
              <label class="text-sm text-slate-400 block mb-1">Jenis Kelamin</label>
              <select name="jenis_kelamin" class="w-full px-4 py-2.5 rounded-lg bg-slate-800 border border-white/10 text-white text-sm">
                <option value="L" <?= (($_POST['jenis_kelamin'] ?? '') === 'L') ? 'selected' : '' ?>>Laki-laki</option>
                <option value="P" <?= (($_POST['jenis_kelamin'] ?? '') === 'P') ? 'selected' : '' ?>>Perempuan</option>
              </select>
            </div>
          </div>
          <div>
            <label class="text-sm text-slate-400 block mb-1">Kelas <span class="text-slate-600">(opsional)</span></label>
            <select name="kelas_id" class="w-full px-4 py-2.5 rounded-lg bg-slate-800 border border-white/10 text-white text-sm">
              <option value="">Pilih Kelas</option>
              <?php foreach ($kelasOptions as $k): ?>
                <option value="<?= $k['id'] ?>" <?= (($_POST['kelas_id'] ?? '') == $k['id']) ? 'selected' : '' ?>><?= h($k['nama_kelas']) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div>
            <label class="text-sm text-slate-400 block mb-1">Alamat</label>
            <input type="text" name="alamat" value="<?= h($_POST['alamat'] ?? '') ?>"
              class="w-full px-4 py-2.5 rounded-lg bg-slate-800 border border-white/10 text-white text-sm focus:outline-none focus:border-sky-400">
          </div>

          <hr class="border-white/10 my-3">
          <p class="text-xs font-semibold text-sky-400 uppercase tracking-wide mb-1">Akun Login</p>
          <div>
            <label class="text-sm text-slate-400 block mb-1">Username</label>
            <input type="text" name="username" required value="<?= h($_POST['username'] ?? '') ?>"
              class="w-full px-4 py-2.5 rounded-lg bg-slate-800 border border-white/10 text-white text-sm focus:outline-none focus:border-sky-400">
          </div>
          <div class="grid grid-cols-2 gap-3">
            <div>
              <label class="text-sm text-slate-400 block mb-1">Password</label>
              <input type="password" name="password" required minlength="6"
                class="w-full px-4 py-2.5 rounded-lg bg-slate-800 border border-white/10 text-white text-sm focus:outline-none focus:border-sky-400">
            </div>
            <div>
              <label class="text-sm text-slate-400 block mb-1">Konfirmasi Password</label>
              <input type="password" name="konfirmasi" required minlength="6"
                class="w-full px-4 py-2.5 rounded-lg bg-slate-800 border border-white/10 text-white text-sm focus:outline-none focus:border-sky-400">
            </div>
          </div>

          <button type="submit" class="w-full py-2.5 rounded-lg bg-sky-500 hover:bg-sky-400 text-slate-900 font-semibold text-sm mt-2">
            Daftar Sekarang
          </button>
        </form>

        <p class="text-xs text-slate-500 text-center mt-5">
          Sudah punya akun? <a href="login.php?role=mahasiswa" class="text-sky-400 hover:underline">Masuk di sini</a>
        </p>
      <?php endif; ?>
    </div>

    <p class="text-center text-xs text-slate-600 mt-6">
      <a href="index.php" class="hover:text-slate-400">&larr; Kembali ke Beranda</a>
    </p>
  </div>
</body>
</html>

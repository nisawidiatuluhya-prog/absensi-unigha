<?php
require_once __DIR__ . '/config/database.php';
$p = getPengaturan();
$pdo = getDBConnection();
$totalMhs = (int)$pdo->query("SELECT COUNT(*) c FROM mahasiswa")->fetch()['c'];
$totalKelas = (int)$pdo->query("SELECT COUNT(*) c FROM kelas")->fetch()['c'];
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Absensi Unigha | <?= h($p['nama_kampus']) ?></title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<script src="https://cdn.tailwindcss.com"></script>
<link rel="stylesheet" href="assets/css/style.css">
</head>
<body class="min-h-screen flex flex-col text-slate-200 overflow-x-hidden">

  <!-- ORB DEKORATIF -->
  <div class="glow-orb" style="width:380px;height:380px;background:#0ea5e9;top:-120px;left:-100px;"></div>
  <div class="glow-orb" style="width:420px;height:420px;background:#6366f1;top:200px;right:-140px;animation-delay:2s;"></div>
  <div class="glow-orb" style="width:300px;height:300px;background:#22d3ee;bottom:10%;left:40%;animation-delay:4s;"></div>

  <!-- NAVBAR -->
  <nav class="w-full px-6 py-4 flex items-center justify-between sticky top-0 z-40 glass-panel">
    <div class="flex items-center gap-3">
      <div class="w-10 h-10 rounded-xl bg-gradient-to-br from-sky-400 to-indigo-500 flex items-center justify-center font-bold text-slate-900 shadow-lg shadow-sky-900/40">AU</div>
      <div>
        <p class="font-semibold text-white leading-tight">Absensi Unigha</p>
        <p class="text-xs text-slate-400 leading-tight"><?= h($p['nama_kampus']) ?></p>
      </div>
    </div>
    <div class="hidden sm:flex items-center gap-2">
      <a href="login.php?role=admin" class="px-4 py-2 rounded-lg text-sm text-slate-300 hover:text-white transition">Login Admin</a>
      <a href="login.php?role=mahasiswa" class="btn-glossy px-5 py-2 rounded-lg bg-sky-500 hover:bg-sky-400 text-slate-900 font-semibold text-sm transition">Login Mahasiswa</a>
    </div>
    <a href="login.php" class="sm:hidden px-4 py-2 rounded-lg bg-sky-500 text-slate-900 font-semibold text-sm">Masuk</a>
  </nav>

  <!-- HERO -->
  <main class="flex-1 flex items-center justify-center px-6 relative z-10">
    <div class="max-w-3xl w-full text-center py-16 md:py-24">
      <span class="inline-block px-3 py-1 rounded-full text-xs font-semibold text-sky-300 bg-sky-500/10 border border-sky-400/30 mb-6 reveal-up is-visible">
        ✨ Sistem Absensi QR Code &middot; <?= h($p['nama_mk']) ?>
      </span>
      <h1 class="text-3xl md:text-6xl font-extrabold text-white mb-4 leading-tight reveal-up is-visible">
        Absensi Kampus,<br>
        <span class="gradient-text">Secepat Sekali Scan</span>
      </h1>
      <p class="text-slate-400 mb-1 reveal-up is-visible"><?= h($p['nama_kampus']) ?> &middot; <?= h($p['fakultas']) ?></p>
      <p class="text-slate-500 text-sm mb-10 reveal-up is-visible"><?= h($p['jurusan']) ?> &middot; Semester <?= h($p['semester']) ?> <?= h($p['tahun_ajaran']) ?></p>

      <div class="flex flex-col sm:flex-row gap-4 justify-center reveal-up is-visible">
        <a href="login.php?role=mahasiswa" class="btn-glossy px-8 py-3 rounded-xl bg-sky-500 hover:bg-sky-400 text-slate-900 font-semibold transition shadow-lg shadow-sky-900/40">
          Masuk sebagai Mahasiswa
        </a>
        <a href="login.php?role=admin" class="px-8 py-3 rounded-xl border border-white/15 text-white hover:bg-white/5 font-semibold transition">
          Masuk sebagai Admin
        </a>
      </div>

      <!-- STATS -->
      <div class="grid grid-cols-3 gap-4 mt-14 reveal-up">
        <div class="glass-panel rounded-xl py-4">
          <p class="text-2xl md:text-3xl font-extrabold text-sky-400 counter" data-target="<?= $totalMhs ?>">0</p>
          <p class="text-xs text-slate-400 mt-1">Mahasiswa Terdaftar</p>
        </div>
        <div class="glass-panel rounded-xl py-4">
          <p class="text-2xl md:text-3xl font-extrabold text-indigo-400 counter" data-target="<?= $totalKelas ?>">0</p>
          <p class="text-xs text-slate-400 mt-1">Kelas Paralel</p>
        </div>
        <div class="glass-panel rounded-xl py-4">
          <p class="text-2xl md:text-3xl font-extrabold text-emerald-400 counter" data-target="100">0</p>
          <p class="text-xs text-slate-400 mt-1">% Digital &amp; Real-Time</p>
        </div>
      </div>
    </div>
  </main>

  <!-- ALUR / CARA KERJA -->
  <section class="w-full px-6 py-16 relative z-10">
    <div class="max-w-5xl mx-auto text-center mb-12 reveal-up">
      <p class="text-sky-400 text-xs font-semibold uppercase tracking-widest mb-2">Cara Kerja</p>
      <h2 class="text-2xl md:text-3xl font-bold text-white">Empat Langkah, Selesai</h2>
      <p class="text-slate-400 text-sm mt-2">Alur absensi yang dirancang secepat dan serapi mungkin untuk mahasiswa dan dosen</p>
    </div>
    <div class="max-w-5xl mx-auto grid grid-cols-2 md:grid-cols-4 gap-6 relative">
      <div class="hidden md:block flow-connector" style="top:28px;"></div>
      <?php
      $flow = [
        ['🪪', 'Dapatkan Kartu QR', 'Setiap mahasiswa otomatis punya kartu digital & QR code unik setelah mendaftar.'],
        ['📷', 'Scan di Kelas', 'Saat jam kuliah berlangsung, cukup scan QR lewat kamera HP — tidak perlu tanda tangan manual.'],
        ['⚡', 'Terverifikasi Otomatis', 'Sistem mencocokkan jadwal & jam toleransi secara real-time, langsung tercatat Hadir/Terlambat.'],
        ['📊', 'Laporan Resmi', 'Dosen tinggal unduh laporan DHMD resmi lengkap dengan kode verifikasi keaslian.'],
      ];
      foreach ($flow as $i => $f): ?>
        <div class="reveal-up relative z-10" style="transition-delay: <?= $i * 0.12 ?>s;">
          <div class="w-14 h-14 mx-auto rounded-2xl glass-panel flex items-center justify-center text-2xl mb-4 border border-sky-400/30">
            <?= $f[0] ?>
          </div>
          <p class="text-white font-semibold text-sm mb-1"><?= $i + 1 ?>. <?= h($f[1]) ?></p>
          <p class="text-slate-400 text-xs leading-relaxed"><?= h($f[2]) ?></p>
        </div>
      <?php endforeach; ?>
    </div>
  </section>

  <!-- FITUR -->
  <section class="w-full px-6 py-16 relative z-10">
    <div class="max-w-5xl mx-auto text-center mb-12 reveal-up">
      <p class="text-sky-400 text-xs font-semibold uppercase tracking-widest mb-2">Fitur Unggulan</p>
      <h2 class="text-2xl md:text-3xl font-bold text-white">Semua yang Dibutuhkan Satu Mata Kuliah</h2>
    </div>
    <div class="max-w-5xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-5">
      <?php
      $fitur = [
        ['🪪', 'Kartu Digital & QR', 'Kartu mahasiswa resmi dengan QR unik, siap dicetak satuan maupun massal per kelas.'],
        ['🟢', 'Live Monitoring', 'Pantau aktivitas absensi hari ini secara real-time tanpa perlu refresh manual.'],
        ['📣', 'Broadcast Pengumuman', 'Info dosen berhalangan hadir langsung tampil sebagai notifikasi di dashboard mahasiswa.'],
        ['📅', 'Kalender Hari Libur', 'Tanggal merah otomatis dikecualikan dari perhitungan Alfa — tidak perlu atur manual tiap bulan.'],
        ['🏅', 'Skor Kedisiplinan', 'Gamifikasi kehadiran memotivasi mahasiswa datang tepat waktu lewat skor & predikat otomatis.'],
        ['📑', 'Laporan DHMD Resmi', 'Format Daftar Hadir Mahasiswa dan Dosen ber-kop kampus, lengkap kode verifikasi keaslian.'],
      ];
      foreach ($fitur as $i => $f): ?>
        <div class="glass-panel hover-lift reveal-up rounded-2xl p-5" style="transition-delay: <?= ($i % 3) * 0.1 ?>s;">
          <div class="w-10 h-10 rounded-lg bg-sky-500/15 flex items-center justify-center text-lg mb-3"><?= $f[0] ?></div>
          <p class="text-white font-semibold mb-1"><?= h($f[1]) ?></p>
          <p class="text-sm text-slate-400"><?= h($f[2]) ?></p>
        </div>
      <?php endforeach; ?>
    </div>
  </section>

  <!-- INFO MATA KULIAH -->
  <section class="w-full px-6 pb-20 relative z-10">
    <div class="max-w-4xl mx-auto glass-panel rounded-2xl p-6 md:p-8 reveal-up">
      <p class="text-sky-400 text-xs font-semibold uppercase tracking-wide mb-4">Informasi Mata Kuliah</p>
      <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm">
        <div class="flex justify-between border-b border-white/5 pb-2"><span class="text-slate-400">Kode / Nama MK</span><span class="text-white font-medium text-right"><?= h($p['kode_mk']) ?> — <?= h($p['nama_mk']) ?></span></div>
        <div class="flex justify-between border-b border-white/5 pb-2"><span class="text-slate-400">Dosen Pengampu</span><span class="text-white font-medium text-right"><?= h($p['dosen_pengampu']) ?></span></div>
        <div class="flex justify-between border-b border-white/5 pb-2"><span class="text-slate-400">Jurusan / Prodi</span><span class="text-white font-medium text-right"><?= h($p['jurusan']) ?> / <?= h($p['prodi']) ?></span></div>
        <div class="flex justify-between border-b border-white/5 pb-2"><span class="text-slate-400">Semester / T.A.</span><span class="text-white font-medium text-right"><?= h($p['semester']) ?> / <?= h($p['tahun_ajaran']) ?></span></div>
      </div>
      <p class="text-xs text-slate-500 mt-5">Sistem ini digunakan khusus untuk absensi mata kuliah di atas, mencakup <?= $totalKelas ?> kelas paralel yang dikelola langsung oleh admin.</p>
    </div>
  </section>

  <!-- CTA AKHIR -->
  <section class="w-full px-6 pb-20 relative z-10">
    <div class="max-w-4xl mx-auto text-center rounded-2xl p-10 reveal-up" style="background: linear-gradient(120deg, rgba(14,165,233,0.15), rgba(99,102,241,0.15)); border:1px solid rgba(56,189,248,0.25);">
      <h3 class="text-xl md:text-2xl font-bold text-white mb-2">Siap absen tanpa ribet?</h3>
      <p class="text-slate-400 text-sm mb-6">Masuk sekarang dan mulai gunakan kartu QR digital Anda.</p>
      <a href="login.php" class="btn-glossy inline-block px-8 py-3 rounded-xl bg-sky-500 hover:bg-sky-400 text-slate-900 font-semibold transition">
        Masuk ke Absensi Unigha
      </a>
    </div>
  </section>

  <footer class="text-center text-xs text-slate-500 py-6 border-t border-white/5 relative z-10">
    &copy; <?= date('Y') ?> Absensi Unigha — <?= h($p['nama_kampus']) ?>
  </footer>

  <script>
    // Reveal-on-scroll
    const revealEls = document.querySelectorAll('.reveal-up');
    const io = new IntersectionObserver((entries) => {
      entries.forEach(e => { if (e.isIntersecting) { e.target.classList.add('is-visible'); io.unobserve(e.target); } });
    }, { threshold: 0.15 });
    revealEls.forEach(el => io.observe(el));

    // Counter animation
    document.querySelectorAll('.counter').forEach(el => {
      const target = parseInt(el.getAttribute('data-target'), 10) || 0;
      let started = false;
      const startCount = () => {
        if (started) return;
        started = true;
        let cur = 0;
        const step = Math.max(1, Math.ceil(target / 40));
        const t = setInterval(() => {
          cur += step;
          if (cur >= target) { cur = target; clearInterval(t); }
          el.textContent = cur;
        }, 25);
      };
      const obs = new IntersectionObserver((entries) => {
        entries.forEach(e => { if (e.isIntersecting) { startCount(); obs.unobserve(e.target); } });
      }, { threshold: 0.4 });
      obs.observe(el);
    });
  </script>
</body>
</html>

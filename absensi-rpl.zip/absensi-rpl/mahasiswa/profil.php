<?php
require_once __DIR__ . '/../config/database.php';
requireLogin('mahasiswa');
$pdo = getDBConnection();
$p = getPengaturan();

$stmt = $pdo->prepare("SELECT m.*, k.nama_kelas FROM mahasiswa m JOIN kelas k ON k.id = m.kelas_id WHERE m.user_id = :uid LIMIT 1");
$stmt->execute([':uid' => $_SESSION['user_id']]);
$mhs = $stmt->fetch();

$msg = ''; $msgType = 'success';
if ($mhs && $_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'ubah_password') {
    $lama = $_POST['password_lama'] ?? '';
    $baru = $_POST['password_baru'] ?? '';
    $konfirmasi = $_POST['konfirmasi_baru'] ?? '';

    $stmt = $pdo->prepare("SELECT password FROM users WHERE id = :id");
    $stmt->execute([':id' => $_SESSION['user_id']]);
    $userRow = $stmt->fetch();

    if (!$userRow || !password_verify($lama, $userRow['password'])) {
        $msg = 'Password lama tidak sesuai.'; $msgType = 'error';
    } elseif (strlen($baru) < 6) {
        $msg = 'Password baru minimal 6 karakter.'; $msgType = 'error';
    } elseif ($baru !== $konfirmasi) {
        $msg = 'Konfirmasi password baru tidak sama.'; $msgType = 'error';
    } else {
        $pdo->prepare("UPDATE users SET password = :p WHERE id = :id")
            ->execute([':p' => password_hash($baru, PASSWORD_DEFAULT), ':id' => $_SESSION['user_id']]);
        $msg = 'Password berhasil diperbarui.';
    }
}

$riwayat = [];
if ($mhs) {
    $riwayat = $pdo->prepare("
        SELECT * FROM absensi
        WHERE mahasiswa_id = :mid
        ORDER BY tanggal DESC, waktu_scan DESC
        LIMIT 50
    ");
    $riwayat->execute([':mid' => $mhs['id']]);
    $riwayat = $riwayat->fetchAll();
}

$pageTitle = 'Profil Saya';
include __DIR__ . '/_layout_top.php';
?>

<h1 class="text-2xl font-bold text-white mb-1">Profil & Riwayat Absensi</h1>
<p class="text-slate-400 text-sm mb-6">Informasi akun dan catatan kehadiran Anda</p>

<?php if ($msg): ?>
  <div class="mb-5 px-4 py-3 rounded-lg text-sm <?= $msgType === 'error' ? 'bg-red-900/40 border border-red-700/40 text-red-300' : 'bg-emerald-900/40 border border-emerald-700/40 text-emerald-300' ?>">
    <?= h($msg) ?>
  </div>
<?php endif; ?>

<?php if (!$mhs): ?>
  <div class="card-navy p-8 text-center text-slate-400 text-sm">Profil mahasiswa Anda belum lengkap. Silakan hubungi admin.</div>
<?php else: ?>

<div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
  <div class="card-navy p-6">
    <p class="font-semibold text-white mb-4">Data Diri</p>
    <div class="space-y-2 text-sm">
      <p class="text-slate-400">Nama: <span class="text-slate-200"><?= h($mhs['nama']) ?></span></p>
      <p class="text-slate-400">NIM: <span class="text-slate-200"><?= h($mhs['nim']) ?></span></p>
      <p class="text-slate-400">J. Kelamin: <span class="text-slate-200"><?= $mhs['jenis_kelamin'] === 'L' ? 'Laki-laki' : 'Perempuan' ?></span></p>
      <p class="text-slate-400">Kelas: <span class="text-slate-200"><?= h($mhs['nama_kelas']) ?></span></p>
      <p class="text-slate-400">Alamat: <span class="text-slate-200"><?= h($mhs['alamat'] ?: '-') ?></span></p>
      <hr class="border-white/10 my-2">
      <p class="text-slate-400">Kampus: <span class="text-slate-200"><?= h($p['nama_kampus']) ?></span></p>
      <p class="text-slate-400">Mata Kuliah: <span class="text-slate-200"><?= h($p['nama_mk']) ?></span></p>
    </div>

    <hr class="border-white/10 my-4">
    <p class="font-semibold text-white mb-3 text-sm">Ubah Password</p>
    <form method="POST" class="space-y-2">
      <input type="hidden" name="action" value="ubah_password">
      <input type="password" name="password_lama" required placeholder="Password Lama"
        class="w-full px-3 py-2 rounded-lg bg-slate-800 border border-white/10 text-white text-xs">
      <input type="password" name="password_baru" required minlength="6" placeholder="Password Baru (min. 6 karakter)"
        class="w-full px-3 py-2 rounded-lg bg-slate-800 border border-white/10 text-white text-xs">
      <input type="password" name="konfirmasi_baru" required minlength="6" placeholder="Konfirmasi Password Baru"
        class="w-full px-3 py-2 rounded-lg bg-slate-800 border border-white/10 text-white text-xs">
      <button class="w-full py-2 rounded-lg bg-sky-500 hover:bg-sky-400 text-slate-900 font-semibold text-xs">Simpan Password Baru</button>
    </form>
  </div>

  <div class="card-navy p-6 lg:col-span-2">
    <p class="font-semibold text-white mb-4">Riwayat Absensi Terbaru</p>
    <div class="overflow-x-auto">
      <table class="w-full text-sm">
        <thead><tr class="text-left text-slate-400 border-b border-white/10">
          <th class="py-2 pr-4">Tanggal</th><th class="py-2 pr-4">Waktu</th><th class="py-2 pr-4">Status</th><th class="py-2">Keterangan</th>
        </tr></thead>
        <tbody>
          <?php if (empty($riwayat)): ?>
            <tr><td colspan="4" class="py-4 text-center text-slate-500">Belum ada riwayat absensi.</td></tr>
          <?php endif; ?>
          <?php foreach ($riwayat as $r): ?>
            <tr class="border-b border-white/5">
              <td class="py-2 pr-4 text-slate-300"><?= date('d M Y', strtotime($r['tanggal'])) ?></td>
              <td class="py-2 pr-4 text-slate-400"><?= substr($r['waktu_scan'],0,5) ?></td>
              <td class="py-2 pr-4"><span class="badge badge-<?= $r['status'] ?>"><?= statusLabel($r['status']) ?></span></td>
              <td class="py-2 text-slate-500 text-xs"><?= h($r['keterangan'] ?: '-') ?></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<?php endif; ?>

<?php include __DIR__ . '/_layout_bottom.php'; ?>

<?php
require_once __DIR__ . '/../config/database.php';
header('Content-Type: application/json');

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'mahasiswa') {
    echo json_encode(['error' => 'Sesi tidak valid, silakan login ulang.']);
    exit;
}

$pdo = getDBConnection();
$p = getPengaturan();
$token = trim($_POST['barcode_token'] ?? $_POST['qr_token'] ?? '');

if ($token === '') {
    echo json_encode(['error' => 'QR code tidak terbaca.']);
    exit;
}

// Cari mahasiswa pemilik QR code
$stmt = $pdo->prepare("SELECT m.*, k.* , m.id as mahasiswa_id, k.id as kelas_id_real FROM mahasiswa m JOIN kelas k ON k.id = m.kelas_id WHERE m.qr_token = :t LIMIT 1");
$stmt->execute([':t' => $token]);
$mhs = $stmt->fetch();

if (!$mhs) {
    echo json_encode(['error' => 'QR code tidak dikenali dalam sistem.']);
    exit;
}

// Pastikan yang scan adalah pemilik QR itu sendiri (mencegah orang lain absen-kan)
if ($mhs['user_id'] != $_SESSION['user_id']) {
    echo json_encode(['error' => 'QR code ini bukan milik akun Anda.']);
    exit;
}

$now = new DateTime();
$hariMap = ['Monday'=>'Senin','Tuesday'=>'Selasa','Wednesday'=>'Rabu','Thursday'=>'Kamis','Friday'=>'Jumat','Saturday'=>'Sabtu','Sunday'=>'Minggu'];
$hariIni = $hariMap[$now->format('l')];
$jamSekarang = $now->format('H:i:s');
$tanggalHariIni = $now->format('Y-m-d');

// Tanggal libur: kelas dianggap tidak berlangsung, absensi ditolak
if (isHariLibur($pdo, $tanggalHariIni)) {
    echo json_encode(['error' => "Hari ini adalah hari libur / tanggal merah. Tidak ada perkuliahan {$p['nama_mk']}."]);
    exit;
}

// Validasi: hari ini harus sesuai jadwal kelas mahasiswa, dan masih dalam jam toleransi
if ($mhs['hari'] !== $hariIni) {
    echo json_encode([
        'error' => "Absensi ditolak. Kelas {$mhs['nama_kelas']} dijadwalkan pada hari {$mhs['hari']}, bukan $hariIni."
    ]);
    exit;
}

$batasToleransi = (clone (new DateTime($mhs['jam_mulai'])))->modify('+' . (int)$p['toleransi_menit'] . ' minutes')->format('H:i:s');
$batasAkhir = $mhs['jam_selesai'];

if ($jamSekarang < $mhs['jam_mulai'] || $jamSekarang > $batasAkhir) {
    echo json_encode([
        'error' => "Absensi ditolak. Jadwal kelas {$mhs['nama_kelas']} adalah " . substr($mhs['jam_mulai'],0,5) . "–" . substr($batasAkhir,0,5) . ", saat ini " . substr($jamSekarang,0,5) . "."
    ]);
    exit;
}

$terlambat = $jamSekarang > $batasToleransi;

// Cegah duplikasi absen pada tanggal yang sama
$stmt = $pdo->prepare("SELECT id FROM absensi WHERE mahasiswa_id = :mid AND tanggal = :tgl");
$stmt->execute([':mid' => $mhs['mahasiswa_id'], ':tgl' => $tanggalHariIni]);
if ($stmt->fetch()) {
    echo json_encode([
        'error' => "Anda sudah tercatat hadir untuk mata kuliah {$p['nama_mk']} hari ini.",
        'sudah_absen' => true
    ]);
    exit;
}

// Catat kehadiran
$stmt = $pdo->prepare("
    INSERT INTO absensi (mahasiswa_id, kelas_id, tanggal, waktu_scan, status, keterangan)
    VALUES (:mid, :kid, :tgl, :jam, 'H', :ket)
");
$stmt->execute([
    ':mid' => $mhs['mahasiswa_id'], ':kid' => $mhs['kelas_id_real'],
    ':tgl' => $tanggalHariIni, ':jam' => $jamSekarang,
    ':ket' => $terlambat ? 'Terlambat' : null,
]);

echo json_encode([
    'success' => true,
    'nama' => $mhs['nama'],
    'nim' => $mhs['nim'],
    'kelas' => $mhs['nama_kelas'],
    'mata_kuliah' => $p['nama_mk'],
    'terlambat' => $terlambat,
    'waktu' => substr($jamSekarang, 0, 5),
]);

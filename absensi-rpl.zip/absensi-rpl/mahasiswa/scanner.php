<?php
require_once __DIR__ . '/../config/database.php';
requireLogin('mahasiswa');

$pageTitle = 'Scan Absensi';
include __DIR__ . '/_layout_top.php';
?>

<script src="https://unpkg.com/@zxing/library@0.20.0"></script>
<script src="../assets/js/scanner.js"></script>

<h1 class="text-2xl font-bold text-white mb-1">Scan Absensi Real-Time</h1>
<p class="text-slate-400 text-sm mb-6">Arahkan QR code kartu mahasiswa Anda ke kamera</p>

<div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
  <div class="card-navy p-6 flex flex-col items-center">
    <video id="scanner-video" autoplay></video>
    <p class="text-xs text-slate-500 mt-3">Pastikan izin kamera diaktifkan pada browser Anda.</p>
  </div>

  <div class="card-navy p-6" id="hasil-panel">
    <p class="font-semibold text-white mb-4">Hasil Verifikasi</p>
    <div id="hasil-kosong" class="text-slate-500 text-sm">Belum ada QR code yang dipindai.</div>

    <div id="hasil-sukses" class="hidden space-y-2">
      <div class="badge badge-H mb-2" id="h-badge">✔ Absensi Berhasil</div>
      <p class="text-white font-semibold text-lg" id="h-nama"></p>
      <p class="text-slate-400 text-sm">NIM: <span id="h-nim" class="text-slate-200"></span></p>
      <p class="text-slate-400 text-sm">Kelas: <span id="h-kelas" class="text-slate-200"></span></p>
      <hr class="border-white/10 my-3">
      <p class="text-slate-400 text-sm">Mata Kuliah: <span id="h-mk" class="text-slate-200"></span></p>
      <p class="text-slate-400 text-sm">Status: <span id="h-status" class="text-slate-200"></span></p>
      <p class="text-slate-400 text-sm">Waktu Scan: <span id="h-waktu" class="text-slate-200"></span></p>
    </div>

    <div id="hasil-error" class="hidden">
      <div class="badge badge-A mb-2">✕ Absensi Ditolak</div>
      <p class="text-red-300 text-sm" id="h-error"></p>
    </div>
  </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function () {
  initScanner('scanner-video', function (data) {
    const kosong = document.getElementById('hasil-kosong');
    const sukses = document.getElementById('hasil-sukses');
    const error = document.getElementById('hasil-error');
    kosong.classList.add('hidden');

    if (data.error) {
      sukses.classList.add('hidden');
      error.classList.remove('hidden');
      document.getElementById('h-error').textContent = data.error;
      if (typeof beep === 'function') beep(false);
    } else if (data.success) {
      error.classList.add('hidden');
      sukses.classList.remove('hidden');
      document.getElementById('h-nama').textContent = data.nama;
      document.getElementById('h-nim').textContent = data.nim;
      document.getElementById('h-kelas').textContent = data.kelas;
      document.getElementById('h-mk').textContent = data.mata_kuliah;
      document.getElementById('h-status').textContent = data.terlambat ? 'Hadir (Terlambat)' : 'Hadir Tepat Waktu';
      document.getElementById('h-waktu').textContent = data.waktu;
      document.getElementById('h-badge').className = data.terlambat ? 'badge badge-I mb-2' : 'badge badge-H mb-2';
      document.getElementById('h-badge').textContent = data.terlambat ? '⏱ Absensi Berhasil (Terlambat)' : '✔ Absensi Berhasil';
      if (typeof beep === 'function') beep(true);
    }
  });
});
</script>

<?php include __DIR__ . '/_layout_bottom.php'; ?>

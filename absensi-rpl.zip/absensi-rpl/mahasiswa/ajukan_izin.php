<?php
require_once __DIR__ . '/../config/database.php';
requireLogin('mahasiswa');
$pdo = getDBConnection();
$p = getPengaturan();

$stmt = $pdo->prepare("SELECT m.*, k.nama_kelas FROM mahasiswa m JOIN kelas k ON k.id = m.kelas_id WHERE m.user_id = :uid LIMIT 1");
$stmt->execute([':uid' => $_SESSION['user_id']]);
$mhs = $stmt->fetch();

$suratDicetak = null;
$msg = '';
$waLink = null;
$emailLink = null;

if ($mhs && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $jenis = ($_POST['jenis'] ?? 'Izin') === 'Sakit' ? 'Sakit' : 'Izin';
    $tanggalIzin = $_POST['tanggal_izin'] ?? '';
    $alasan = trim($_POST['alasan'] ?? '');

    if ($tanggalIzin && $alasan !== '') {
        $stmt = $pdo->prepare("
            INSERT INTO surat_izin (mahasiswa_id, kelas_id, tanggal_izin, jenis, alasan)
            VALUES (:mid, :kid, :tgl, :jenis, :alasan)
        ");
        $stmt->execute([
            ':mid' => $mhs['id'], ':kid' => $mhs['kelas_id'],
            ':tgl' => $tanggalIzin, ':jenis' => $jenis, ':alasan' => $alasan
        ]);
        $suratId = $pdo->lastInsertId();

        $stmt = $pdo->prepare("SELECT * FROM surat_izin WHERE id = :id");
        $stmt->execute([':id' => $suratId]);
        $suratDicetak = $stmt->fetch();
        $msg = 'Surat izin berhasil diajukan dan menunggu validasi admin.';

        if (!empty($p['no_wa_dosen'])) {
            $pesan = "Assalamu'alaikum, Bapak/Ibu {$p['dosen_pengampu']}.\n"
                   . "Saya {$mhs['nama']} (NIM {$mhs['nim']}, Kelas {$mhs['nama_kelas']}) mengajukan $jenis "
                   . "untuk mata kuliah {$p['nama_mk']} pada tanggal " . date('d F Y', strtotime($tanggalIzin)) . ".\n"
                   . "Alasan: $alasan\n"
                   . "Terima kasih.";
            $noWa = preg_replace('/[^0-9]/', '', $p['no_wa_dosen']);
            $waLink = "https://wa.me/{$noWa}?text=" . rawurlencode($pesan);

            if (!empty($p['email_dosen'])) {
                $subjekEmail = "Surat $jenis - {$mhs['nama']} ({$mhs['nim']})";
                $emailLink = "mailto:" . rawurlencode($p['email_dosen'])
                           . "?subject=" . rawurlencode($subjekEmail)
                           . "&body=" . rawurlencode($pesan);
            }
        }
    } else {
        $msg = 'Semua field wajib diisi.';
    }
}

// Riwayat pengajuan izin
$riwayat = [];
if ($mhs) {
    $riwayat = $pdo->prepare("SELECT * FROM surat_izin WHERE mahasiswa_id = :mid ORDER BY created_at DESC");
    $riwayat->execute([':mid' => $mhs['id']]);
    $riwayat = $riwayat->fetchAll();
}

$pageTitle = 'Ajukan Surat Izin';
include __DIR__ . '/_layout_top.php';
?>

<h1 class="text-2xl font-bold text-white mb-1">Pengajuan Surat Izin / Sakit Otomatis</h1>
<p class="text-slate-400 text-sm mb-6">Isi form berikut, surat resmi akan dibuat otomatis dan dapat dikirim ke dosen via WhatsApp</p>

<?php if ($msg): ?>
  <div class="mb-5 px-4 py-3 rounded-lg text-sm bg-emerald-900/40 border border-emerald-700/40 text-emerald-300 print:hidden"><?= h($msg) ?></div>
<?php endif; ?>

<?php if (!$mhs): ?>
  <div class="card-navy p-8 text-center text-slate-400 text-sm">Profil mahasiswa Anda belum lengkap. Silakan hubungi admin.</div>
<?php else: ?>

<div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
  <!-- FORM -->
  <div class="card-navy p-6 print:hidden">
    <p class="font-semibold text-white mb-4">Form Pengajuan</p>
    <form method="POST" class="space-y-3">
      <div class="grid grid-cols-2 gap-3 text-sm">
        <div>
          <label class="text-xs text-slate-400 block mb-1">Nama</label>
          <input type="text" value="<?= h($mhs['nama']) ?>" disabled class="w-full px-3 py-2 rounded-lg bg-slate-800/50 border border-white/10 text-slate-400">
        </div>
        <div>
          <label class="text-xs text-slate-400 block mb-1">NIM</label>
          <input type="text" value="<?= h($mhs['nim']) ?>" disabled class="w-full px-3 py-2 rounded-lg bg-slate-800/50 border border-white/10 text-slate-400">
        </div>
        <div>
          <label class="text-xs text-slate-400 block mb-1">Kelas</label>
          <input type="text" value="<?= h($mhs['nama_kelas']) ?>" disabled class="w-full px-3 py-2 rounded-lg bg-slate-800/50 border border-white/10 text-slate-400">
        </div>
        <div>
          <label class="text-xs text-slate-400 block mb-1">Mata Kuliah</label>
          <input type="text" value="<?= h($p['nama_mk']) ?>" disabled class="w-full px-3 py-2 rounded-lg bg-slate-800/50 border border-white/10 text-slate-400">
        </div>
      </div>
      <div>
        <label class="text-xs text-slate-400 block mb-1">Jenis</label>
        <select name="jenis" class="w-full px-3 py-2 rounded-lg bg-slate-800 border border-white/10 text-white text-sm">
          <option value="Izin">Izin</option>
          <option value="Sakit">Sakit</option>
        </select>
      </div>
      <div>
        <label class="text-xs text-slate-400 block mb-1">Tanggal</label>
        <input type="date" name="tanggal_izin" required class="w-full px-3 py-2 rounded-lg bg-slate-800 border border-white/10 text-white text-sm">
      </div>
      <div>
        <label class="text-xs text-slate-400 block mb-1">Alasan</label>
        <textarea name="alasan" rows="4" required class="w-full px-3 py-2 rounded-lg bg-slate-800 border border-white/10 text-white text-sm" placeholder="Tuliskan alasan..."></textarea>
      </div>
      <button class="w-full py-2.5 rounded-lg bg-sky-500 hover:bg-sky-400 text-slate-900 font-semibold text-sm">Ajukan Surat</button>
    </form>
  </div>

  <!-- PREVIEW SURAT RESMI -->
  <div class="card-navy p-6 print-area">
    <p class="font-semibold text-white mb-4 print:hidden">Pratinjau Surat Resmi</p>
    <?php if ($suratDicetak): ?>
      <div class="bg-white text-slate-900 rounded-lg p-6 text-sm leading-relaxed" id="surat-cetak">
        <div class="text-center border-b-2 border-slate-800 pb-3 mb-4">
          <p class="font-bold text-base uppercase"><?= h($p['nama_kampus']) ?></p>
          <p class="text-xs"><?= h($p['alamat_kampus']) ?></p>
          <p class="text-xs"><?= h($p['fakultas']) ?> — <?= h($p['prodi']) ?></p>
        </div>
        <p class="text-center font-semibold underline mb-4">SURAT <?= strtoupper($suratDicetak['jenis']) ?> TIDAK MENGIKUTI PERKULIAHAN</p>
        <p class="mb-3">Yang bertanda tangan di bawah ini menerangkan bahwa:</p>
        <table class="mb-3">
          <tr><td class="pr-3 align-top">Nama</td><td class="pr-2">:</td><td><?= h($mhs['nama']) ?></td></tr>
          <tr><td class="pr-3 align-top">NIM</td><td class="pr-2">:</td><td><?= h($mhs['nim']) ?></td></tr>
          <tr><td class="pr-3 align-top">Kelas</td><td class="pr-2">:</td><td><?= h($mhs['nama_kelas']) ?></td></tr>
          <tr><td class="pr-3 align-top">Mata Kuliah</td><td class="pr-2">:</td><td><?= h($p['nama_mk']) ?></td></tr>
          <tr><td class="pr-3 align-top">Tanggal</td><td class="pr-2">:</td><td><?= date('d F Y', strtotime($suratDicetak['tanggal_izin'])) ?></td></tr>
        </table>
        <p class="mb-2">Dengan alasan sebagai berikut:</p>
        <p class="mb-6 italic">"<?= h($suratDicetak['alasan']) ?>"</p>
        <p class="mb-8">Demikian surat ini dibuat untuk dapat dipergunakan sebagaimana mestinya.</p>

        <div class="grid grid-cols-2 gap-6 text-center mt-10">
          <div>
            <p class="mb-16">Mengetahui,<br>Ketua Tingkat (Komting)</p>
            <p class="border-t border-slate-800 pt-1">( ____________________ )</p>
          </div>
          <div>
            <p class="mb-16">Menyetujui,<br>Dosen Pengampu</p>
            <p class="border-t border-slate-800 pt-1"><?= h($p['dosen_pengampu']) ?></p>
          </div>
        </div>
      </div>
      <button onclick="window.print()" class="w-full mt-4 py-2.5 rounded-lg bg-slate-700 hover:bg-slate-600 text-white text-sm print:hidden">🖨️ Cetak Surat</button>
      <button onclick="unduhSurat()" class="w-full mt-2 py-2.5 rounded-lg bg-sky-500 hover:bg-sky-400 text-slate-900 font-semibold text-sm print:hidden">⬇️ Unduh Surat (PNG)</button>

      <?php if ($waLink || $emailLink): ?>
        <div class="mt-4 pt-4 border-t border-white/10 print:hidden">
          <p class="text-xs font-semibold text-slate-400 uppercase tracking-wide mb-2">Kirim Surat Ini</p>
          <div class="flex flex-col sm:flex-row gap-2">
            <?php if ($emailLink): ?>
              <a href="<?= h($emailLink) ?>" class="flex-1 text-center inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg bg-sky-600 hover:bg-sky-500 text-white text-sm font-semibold">
                ✉️ Kirim ke Dosen
              </a>
            <?php endif; ?>
            <?php if ($waLink): ?>
              <a href="<?= h($waLink) ?>" target="_blank" class="flex-1 text-center inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-sm font-semibold">
                📲 Kirim via WhatsApp
              </a>
            <?php endif; ?>
          </div>
          <p class="text-xs text-slate-500 mt-2">Surat sudah otomatis tersimpan di sistem dan akan divalidasi admin/dosen. Tombol di atas hanya opsi tambahan untuk mengirim salinannya langsung.</p>
        </div>
      <?php endif; ?>

      <script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>
      <script>
        function unduhSurat() {
          html2canvas(document.getElementById('surat-cetak'), { backgroundColor: '#ffffff', scale: 2 }).then(function (canvas) {
            const link = document.createElement('a');
            link.download = 'surat-<?= h($suratDicetak['jenis']) ?>-<?= h(preg_replace('/[^A-Za-z0-9]/', '', $mhs['nim'])) ?>.png';
            link.href = canvas.toDataURL('image/png');
            link.click();
          });
        }
      </script>
    <?php else: ?>
      <p class="text-slate-500 text-sm">Surat resmi akan tampil di sini setelah pengajuan berhasil.</p>
    <?php endif; ?>
  </div>
</div>

<!-- RIWAYAT -->
<div class="card-navy p-6 mt-6 print:hidden">
  <p class="font-semibold text-white mb-4">Riwayat Pengajuan</p>
  <table class="w-full text-sm">
    <thead><tr class="text-left text-slate-400 border-b border-white/10">
      <th class="py-2 pr-4">Jenis</th><th class="py-2 pr-4">Tanggal</th><th class="py-2 pr-4">Status</th>
    </tr></thead>
    <tbody>
      <?php if (empty($riwayat)): ?>
        <tr><td colspan="3" class="py-4 text-center text-slate-500">Belum ada pengajuan.</td></tr>
      <?php endif; ?>
      <?php foreach ($riwayat as $r): ?>
        <tr class="border-b border-white/5">
          <td class="py-2 pr-4 text-white"><?= h($r['jenis']) ?></td>
          <td class="py-2 pr-4 text-slate-400"><?= date('d M Y', strtotime($r['tanggal_izin'])) ?></td>
          <td class="py-2 pr-4"><span class="badge badge-<?= $r['status_konfirmasi'] ?>"><?= h($r['status_konfirmasi']) ?></span></td>
        </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>

<?php endif; ?>

<?php include __DIR__ . '/_layout_bottom.php'; ?>

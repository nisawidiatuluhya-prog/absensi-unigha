<?php
$currentPage = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= h($pageTitle ?? 'Mahasiswa') ?> | Absensi Unigha</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<script src="https://cdn.tailwindcss.com"></script>
<link rel="stylesheet" href="../assets/css/style.css">
</head>
<body class="min-h-screen flex text-slate-200">

  <div id="sidebar-overlay" class="fixed inset-0 bg-black/60 z-40 hidden md:hidden" onclick="toggleSidebar()"></div>

  <aside id="sidebar" class="w-64 shrink-0 border-r border-white/5 flex flex-col fixed md:static inset-y-0 left-0 z-50 -translate-x-full md:translate-x-0 transition-transform duration-300 ease-in-out" style="background-color:#0b1220;">
    <div class="p-5 flex items-center justify-between gap-3 border-b border-white/5">
      <div class="flex items-center gap-3">
        <div class="w-9 h-9 rounded-lg bg-gradient-to-br from-sky-400 to-indigo-500 flex items-center justify-center font-bold text-slate-900 text-sm">AU</div>
        <div>
          <p class="text-white font-semibold text-sm leading-tight">Absensi Unigha</p>
          <p class="text-xs text-slate-500 leading-tight">Panel Mahasiswa</p>
        </div>
      </div>
      <button onclick="toggleSidebar()" class="md:hidden w-8 h-8 rounded-lg bg-white/5 text-white flex items-center justify-center">✕</button>
    </div>
    <nav class="p-3 flex-1 space-y-1">
      <a href="dashboard.php" class="sidebar-link <?= $currentPage === 'dashboard.php' ? 'active' : '' ?>">🪪 Kartu & Dashboard</a>
      <a href="scanner.php" class="sidebar-link <?= $currentPage === 'scanner.php' ? 'active' : '' ?>">📷 Scan Absensi</a>
      <a href="pemberitahuan.php" class="sidebar-link <?= $currentPage === 'pemberitahuan.php' ? 'active' : '' ?>">📌 Pemberitahuan Dosen</a>
      <a href="ajukan_izin.php" class="sidebar-link <?= $currentPage === 'ajukan_izin.php' ? 'active' : '' ?>">📝 Ajukan Izin</a>
      <a href="kontak_dosen.php" class="sidebar-link <?= $currentPage === 'kontak_dosen.php' ? 'active' : '' ?>">☎️ Kontak Dosen</a>
      <a href="profil.php" class="sidebar-link <?= $currentPage === 'profil.php' ? 'active' : '' ?>">👤 Profil & Riwayat</a>
      <a href="panduan.php" class="sidebar-link <?= $currentPage === 'panduan.php' ? 'active' : '' ?>">📘 Panduan</a>
    </nav>
    <div class="p-3 border-t border-white/5">
      <a href="../logout.php" class="sidebar-link text-red-400 hover:text-red-300">🚪 Keluar</a>
    </div>
  </aside>

  <div class="flex-1 flex flex-col min-w-0">
    <div class="md:hidden flex items-center justify-between px-4 py-3 border-b border-white/5 sticky top-0 z-30" style="background-color:#0b1220;">
      <button onclick="toggleSidebar()" class="w-9 h-9 rounded-lg bg-white/5 text-white flex items-center justify-center text-lg">☰</button>
      <p class="font-semibold text-white text-sm">Absensi Unigha</p>
      <a href="../logout.php" class="text-red-400 text-sm">Keluar</a>
    </div>
    <main class="flex-1 p-6 md:p-8 overflow-x-auto">

    <script>
      function toggleSidebar() {
        document.getElementById('sidebar').classList.toggle('-translate-x-full');
        document.getElementById('sidebar-overlay').classList.toggle('hidden');
      }
    </script>

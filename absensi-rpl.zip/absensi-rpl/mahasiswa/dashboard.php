<?php
require_once __DIR__ . '/../config/database.php';
requireLogin('mahasiswa');
$pdo = getDBConnection();
$p = getPengaturan();

$stmt = $pdo->prepare("SELECT m.*, k.nama_kelas FROM mahasiswa m JOIN kelas k ON k.id = m.kelas_id WHERE m.user_id = :uid LIMIT 1");
$stmt->execute([':uid' => $_SESSION['user_id']]);
$mhs = $stmt->fetch();

$pageTitle = 'Dashboard Mahasiswa';
include __DIR__ . '/_layout_top.php';

if (!$mhs) {
    echo '<div class="card-navy p-8 text-center text-slate-400 text-sm">Profil mahasiswa Anda belum lengkap. Silakan hubungi admin untuk melengkapi data kelas Anda.</div>';
    include __DIR__ . '/_layout_bottom.php';
    exit;
}

// Statistik ringkas kehadiran bulan berjalan
$stmt = $pdo->prepare("
    SELECT status, COUNT(*) c FROM absensi
    WHERE mahasiswa_id = :id AND DATE_FORMAT(tanggal,'%Y-%m') = DATE_FORMAT(CURDATE(),'%Y-%m')
    GROUP BY status
");
$stmt->execute([':id' => $mhs['id']]);
$stat = ['H'=>0,'I'=>0,'S'=>0,'A'=>0];
foreach ($stmt as $r) { $stat[$r['status']] = (int)$r['c']; }

// Skor & predikat kedisiplinan kehadiran
$disiplin = hitungSkorDisiplin($pdo, $mhs['id']);

// Pengumuman terbaru untuk kelas mahasiswa ini (atau untuk semua kelas)
$stmtPeng = $pdo->prepare("
    SELECT * FROM pengumuman
    WHERE kelas_id IS NULL OR kelas_id = :kid
    ORDER BY created_at DESC
    LIMIT 3
");
$stmtPeng->execute([':kid' => $mhs['kelas_id']]);
$pengumumanList = $stmtPeng->fetchAll();
?>

<script src="https://cdn.jsdelivr.net/npm/qrcodejs@1.0.0/qrcode.min.js"></script>

<h1 class="text-2xl font-bold text-white mb-1">Selamat Datang, <?= h($mhs['nama']) ?></h1>
<p class="text-slate-400 text-sm mb-4">Kartu Mahasiswa Digital & Ringkasan Kehadiran — <?= h($p['nama_mk']) ?></p>

<a href="pemberitahuan.php" class="block card-navy px-5 py-4 mb-6 hover:border-sky-400/40 transition-colors">
  <div class="flex items-center justify-between gap-3">
    <div class="flex items-center gap-3 min-w-0">
      <div class="w-10 h-10 rounded-lg bg-sky-500/10 border border-sky-400/30 flex items-center justify-center text-lg shrink-0">📌</div>
      <div class="min-w-0">
        <p class="text-white font-semibold text-sm">Pemberitahuan Dosen</p>
        <?php if (empty($pengumumanList)): ?>
          <p class="text-slate-500 text-xs">Belum ada pengumuman atau tugas baru.</p>
        <?php else: ?>
          <p class="text-slate-400 text-xs truncate">Terbaru: <?= h($pengumumanList[0]['judul']) ?></p>
        <?php endif; ?>
      </div>
    </div>
    <span class="text-slate-500 text-sm shrink-0">Lihat semua &rarr;</span>
  </div>
</a>

<div class="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
  <!-- KARTU MAHASISWA DIGITAL -->
  <div class="lg:col-span-2">
    <div class="id-card" id="kartu-mhs">
      <div class="id-card-header flex items-center justify-between">
        <div>
          <p class="text-white font-bold leading-tight"><?= h($p['nama_kampus']) ?></p>
          <p class="text-[11px] text-white/70 leading-tight uppercase tracking-wide">Kartu Mahasiswa — <?= h($p['nama_mk']) ?></p>
        </div>
        <div class="w-10 h-10 rounded-lg bg-white/15 flex items-center justify-center font-bold text-white text-xs shrink-0">AU</div>
      </div>

      <div class="p-5 flex items-center gap-4">
        <div class="id-avatar"><?= avatarSvg($mhs['jenis_kelamin']) ?></div>
        <div class="flex-1 space-y-1 text-sm">
          <p class="text-slate-900 text-lg font-bold leading-tight"><?= h($mhs['nama']) ?></p>
          <p class="text-slate-500 text-xs">NIM <span class="text-slate-800 font-medium"><?= h($mhs['nim']) ?></span> &middot; Kelas <span class="text-slate-800 font-medium"><?= h($mhs['nama_kelas']) ?></span></p>
          <p class="text-slate-500 text-xs">J. Kelamin <span class="text-slate-800 font-medium"><?= $mhs['jenis_kelamin'] === 'L' ? 'Laki-laki' : 'Perempuan' ?></span></p>
        </div>
        <div class="flex flex-col items-center justify-center border border-slate-200 rounded-xl p-2 shrink-0">
          <div id="qrcode"></div>
          <p class="text-[9px] text-slate-400 mt-1">Pindai QR untuk absen</p>
        </div>
      </div>
      <div class="px-5 py-2 text-center text-white text-[11px] font-semibold" style="background:#0f172a;">
        Absensi Unigha — Kartu Digital Resmi
      </div>
    </div>
    <div class="flex gap-3 mt-3">
      <button onclick="window.print()" class="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-white text-xs">🖨️ Cetak Kartu</button>
      <button onclick="unduhKartu()" class="px-4 py-2 rounded-lg bg-sky-500 hover:bg-sky-400 text-slate-900 font-semibold text-xs">⬇️ Unduh Kartu (PNG)</button>
    </div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>
    <script>
      new QRCode(document.getElementById("qrcode"), {
        text: <?= json_encode($mhs['qr_token']) ?>,
        width: 88, height: 88,
        colorDark: "#0f172a", colorLight: "#ffffff"
      });
      function unduhKartu() {
        html2canvas(document.getElementById('kartu-mhs'), { backgroundColor: '#ffffff', scale: 2 }).then(function (canvas) {
          const link = document.createElement('a');
          link.download = 'kartu-<?= h(preg_replace('/[^A-Za-z0-9]/', '', $mhs['nim'])) ?>.png';
          link.href = canvas.toDataURL('image/png');
          link.click();
        });
      }
    </script>
  </div>

  <!-- RINGKASAN KEHADIRAN -->
  <div class="card-navy p-6">
    <div class="text-center mb-5 pb-5 border-b border-white/10">
      <p class="text-xs text-slate-400 uppercase tracking-wide mb-1">Skor Kedisiplinan</p>
      <p class="text-3xl font-bold <?= $disiplin['warna'] ?>"><?= $disiplin['skor'] ?><span class="text-base">/100</span></p>
      <p class="text-sm font-semibold <?= $disiplin['warna'] ?> mt-1">🏅 <?= h($disiplin['predikat']) ?></p>
      <p class="text-xs text-slate-500 mt-1"><?= $disiplin['tepatWaktu'] ?> tepat waktu &middot; <?= $disiplin['terlambat'] ?> terlambat dari <?= $disiplin['total'] ?> pertemuan</p>
    </div>
    <p class="font-semibold text-white mb-4">Kehadiran Bulan Ini</p>
    <div class="space-y-3">
      <div class="flex items-center justify-between">
        <span class="badge badge-H">Hadir</span><span class="text-white font-semibold"><?= $stat['H'] ?></span>
      </div>
      <div class="flex items-center justify-between">
        <span class="badge badge-I">Izin</span><span class="text-white font-semibold"><?= $stat['I'] ?></span>
      </div>
      <div class="flex items-center justify-between">
        <span class="badge badge-S">Sakit</span><span class="text-white font-semibold"><?= $stat['S'] ?></span>
      </div>
      <div class="flex items-center justify-between">
        <span class="badge badge-A">Alpa</span><span class="text-white font-semibold"><?= $stat['A'] ?></span>
      </div>
    </div>
    <a href="scanner.php" class="block text-center mt-6 py-2.5 rounded-lg bg-sky-500 hover:bg-sky-400 text-slate-900 font-semibold text-sm">
      Mulai Scan Absensi
    </a>
  </div>
</div>

<?php include __DIR__ . '/_layout_bottom.php'; ?>

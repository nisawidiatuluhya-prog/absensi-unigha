<?php
require_once __DIR__ . '/../config/database.php';
requireLogin('mahasiswa');
$p = getPengaturan();

$waLink = null;
if (!empty($p['no_wa_dosen'])) {
    $noWa = preg_replace('/[^0-9]/', '', $p['no_wa_dosen']);
    $waLink = "https://wa.me/{$noWa}";
}

$pageTitle = 'Kontak Dosen';
include __DIR__ . '/_layout_top.php';
?>

<h1 class="text-2xl font-bold text-white mb-1">Kontak Dosen Pengampu</h1>
<p class="text-slate-400 text-sm mb-6">Informasi kontak dosen pengampu mata kuliah <?= h($p['nama_mk']) ?></p>

<div class="max-w-lg">
  <div class="card-navy p-6 text-center">
    <div class="w-20 h-20 rounded-full bg-sky-500/15 border border-sky-400/40 flex items-center justify-center text-3xl mx-auto mb-4">
      👨‍🏫
    </div>
    <p class="text-white font-bold text-lg"><?= h($p['dosen_pengampu']) ?></p>
    <?php if (!empty($p['nidn_dosen'])): ?>
      <p class="text-slate-400 text-sm">NIDN: <?= h($p['nidn_dosen']) ?></p>
    <?php endif; ?>
    <p class="text-slate-500 text-sm mt-1"><?= h($p['nama_mk']) ?> (<?= h($p['kode_mk']) ?>)</p>
    <p class="text-slate-500 text-sm"><?= h($p['fakultas']) ?> &middot; <?= h($p['prodi']) ?></p>

    <div class="mt-6 space-y-2 text-left text-sm">
      <div class="flex justify-between border-b border-white/5 pb-2">
        <span class="text-slate-400">Kampus</span>
        <span class="text-slate-200 text-right"><?= h($p['nama_kampus']) ?></span>
      </div>
      <div class="flex justify-between border-b border-white/5 pb-2">
        <span class="text-slate-400">No. WhatsApp</span>
        <span class="text-slate-200 text-right"><?= h($p['no_wa_dosen'] ?: 'Belum diatur oleh admin') ?></span>
      </div>
    </div>

    <?php if ($waLink): ?>
      <a href="<?= h($waLink) ?>" target="_blank"
        class="inline-flex items-center justify-center gap-2 w-full mt-6 px-4 py-2.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-sm font-semibold">
        📲 Hubungi via WhatsApp
      </a>
    <?php else: ?>
      <p class="text-xs text-slate-500 mt-6">Nomor WhatsApp dosen belum diatur. Silakan hubungi admin untuk melengkapinya di menu Pengaturan.</p>
    <?php endif; ?>

    <a href="ajukan_izin.php" class="block text-center mt-3 px-4 py-2.5 rounded-lg border border-white/10 text-slate-300 hover:bg-white/5 text-sm">
      📝 Ajukan Surat Izin/Sakit
    </a>
  </div>
</div>

<?php include __DIR__ . '/_layout_bottom.php'; ?>

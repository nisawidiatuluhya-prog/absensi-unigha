<?php
require_once __DIR__ . '/../config/database.php';
requireLogin('mahasiswa');
$pdo = getDBConnection();
$p = getPengaturan();

$stmt = $pdo->prepare("SELECT m.*, k.nama_kelas FROM mahasiswa m JOIN kelas k ON k.id = m.kelas_id WHERE m.user_id = :uid LIMIT 1");
$stmt->execute([':uid' => $_SESSION['user_id']]);
$mhs = $stmt->fetch();

$pageTitle = 'Pemberitahuan Dosen';
include __DIR__ . '/_layout_top.php';

if (!$mhs) {
    echo '<div class="card-navy p-8 text-center text-slate-400 text-sm">Profil mahasiswa Anda belum lengkap. Silakan hubungi admin.</div>';
    include __DIR__ . '/_layout_bottom.php';
    exit;
}

$filter = $_GET['tipe'] ?? 'Semua';
$sql = "SELECT * FROM pengumuman WHERE (kelas_id IS NULL OR kelas_id = :kid)";
$params = [':kid' => $mhs['kelas_id']];
if (in_array($filter, ['Pengumuman', 'Tugas'], true)) {
    $sql .= " AND tipe = :tipe";
    $params[':tipe'] = $filter;
}
$sql .= " ORDER BY created_at DESC";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$daftar = $stmt->fetchAll();
?>

<h1 class="text-2xl font-bold text-white mb-1">📌 Pemberitahuan Dosen</h1>
<p class="text-slate-400 text-sm mb-6">Pengumuman dan tugas dari <?= h($p['dosen_pengampu']) ?> untuk kelas <?= h($mhs['nama_kelas']) ?></p>

<div class="flex gap-2 mb-6">
  <?php foreach (['Semua' => 'Semua', 'Pengumuman' => '📣 Pengumuman', 'Tugas' => '📝 Tugas'] as $val => $label): ?>
    <a href="?tipe=<?= $val ?>" class="px-3 py-1.5 rounded-lg text-sm <?= $filter === $val ? 'bg-sky-500 text-slate-900 font-semibold' : 'bg-slate-800 text-slate-300 hover:bg-slate-700' ?>"><?= $label ?></a>
  <?php endforeach; ?>
</div>

<div class="space-y-4">
  <?php if (empty($daftar)): ?>
    <div class="card-navy p-8 text-center text-slate-500 text-sm">Belum ada pemberitahuan.</div>
  <?php endif; ?>

  <?php foreach ($daftar as $d):
    $isTugas = $d['tipe'] === 'Tugas';
    $lewatDeadline = $isTugas && $d['deadline'] && strtotime($d['deadline']) < time();
  ?>
    <div class="card-navy p-5">
      <div class="flex items-start justify-between gap-3 mb-2">
        <span class="badge <?= $isTugas ? 'badge-I' : 'badge-H' ?>"><?= $isTugas ? '📝 Tugas' : '📣 Pengumuman' ?></span>
        <span class="text-xs text-slate-500 shrink-0"><?= date('d M Y, H:i', strtotime($d['created_at'])) ?></span>
      </div>
      <p class="text-white font-semibold text-base mb-1"><?= h($d['judul']) ?></p>
      <p class="text-slate-300 text-sm whitespace-pre-line mb-3"><?= h($d['isi']) ?></p>

      <?php if ($isTugas && $d['deadline']): ?>
        <p class="text-xs mb-2 <?= $lewatDeadline ? 'text-red-400' : 'text-amber-300' ?>">
          ⏰ Batas waktu: <?= date('d F Y, H:i', strtotime($d['deadline'])) ?> WIB
          <?= $lewatDeadline ? ' — sudah lewat' : '' ?>
        </p>
      <?php endif; ?>

      <?php if ($d['file_lampiran']): ?>
        <a href="../assets/uploads/pengumuman/<?= h($d['file_lampiran']) ?>" target="_blank"
           class="inline-flex items-center gap-2 px-3 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 border border-white/10 text-sky-400 text-xs">
          📎 <?= h($d['file_nama_asli']) ?>
        </a>
      <?php endif; ?>
    </div>
  <?php endforeach; ?>
</div>

<?php include __DIR__ . '/_layout_bottom.php'; ?>

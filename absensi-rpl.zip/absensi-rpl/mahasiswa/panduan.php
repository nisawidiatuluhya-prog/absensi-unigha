<?php
require_once __DIR__ . '/../config/database.php';
requireLogin('mahasiswa');
$p = getPengaturan();

$pageTitle = 'Panduan Penggunaan';
include __DIR__ . '/_layout_top.php';

$langkah = [
    ['🪪', 'Lihat Kartu Digital', 'Buka menu "Kartu & Dashboard" untuk melihat kartu mahasiswa digital Anda beserta QR code unik.'],
    ['📷', 'Scan Absensi', 'Saat jam perkuliahan ' . h($p['nama_mk']) . ' berlangsung, buka menu "Scan Absensi", izinkan akses kamera, lalu arahkan QR code pada kartu Anda ke kamera.'],
    ['✅', 'Verifikasi Otomatis', 'Sistem akan otomatis mencocokkan jadwal kelas Anda. Jika sesuai jadwal, absensi tercatat sebagai Hadir (atau Hadir Terlambat jika melewati batas toleransi).'],
    ['📝', 'Ajukan Izin/Sakit', 'Jika berhalangan hadir, buka menu "Ajukan Izin", isi form, dan surat resmi otomatis dibuat. Anda juga dapat mengirim surat tersebut langsung ke dosen melalui WhatsApp.'],
    ['👤', 'Pantau Riwayat', 'Buka menu "Profil & Riwayat" untuk melihat rekap kehadiran Anda dari waktu ke waktu.'],
];
?>

<h1 class="text-2xl font-bold text-white mb-1">Panduan Penggunaan Absensi Unigha</h1>
<p class="text-slate-400 text-sm mb-8">Langkah-langkah menggunakan sistem absensi untuk mata kuliah <?= h($p['nama_mk']) ?></p>

<div class="relative">
  <div class="absolute left-5 top-2 bottom-2 w-0.5 bg-gradient-to-b from-sky-400/60 to-indigo-500/20 hidden sm:block"></div>
  <div class="space-y-4">
    <?php foreach ($langkah as $i => $l): ?>
      <div class="card-navy p-5 flex gap-4 items-start relative">
        <div class="w-10 h-10 rounded-full bg-sky-500 text-slate-900 font-bold flex items-center justify-center shrink-0 relative z-10"><?= $i + 1 ?></div>
        <div>
          <p class="text-white font-semibold mb-1"><?= $l[0] ?> <?= h($l[1]) ?></p>
          <p class="text-slate-400 text-sm"><?= $l[2] ?></p>
        </div>
      </div>
    <?php endforeach; ?>
  </div>
</div>

<div class="card-navy p-5 mt-8">
  <p class="font-semibold text-white mb-1">🛠️ Pertanyaan Umum & Pemecahan Masalah</p>
  <p class="text-slate-500 text-xs mb-4">Jika tombol atau fitur tidak berjalan seperti seharusnya, coba langkah berikut sebelum menghubungi admin.</p>
  <div class="space-y-4 text-sm">
    <div>
      <p class="text-slate-200 font-medium">❓ QR code tidak terbaca kamera?</p>
      <p class="text-slate-500">Pastikan pencahayaan cukup dan kartu tidak terlalu jauh/dekat dari kamera. Bersihkan lensa kamera HP jika buram.</p>
    </div>
    <div>
      <p class="text-slate-200 font-medium">❓ Tombol "Mulai Scan" tidak bisa diklik / tidak merespons?</p>
      <p class="text-slate-500">Coba refresh (muat ulang) halaman terlebih dahulu. Jika masih sama, pastikan koneksi internet Anda stabil, lalu coba buka dari browser lain (Chrome/Safari). Jika tetap tidak bisa, screenshot masalahnya dan hubungi admin lewat menu Kontak Dosen.</p>
    </div>
    <div>
      <p class="text-slate-200 font-medium">❓ Browser meminta izin kamera tapi tidak muncul kamera?</p>
      <p class="text-slate-500">Periksa pengaturan browser Anda — pastikan izin kamera untuk situs ini diaktifkan (biasanya di ikon gembok/info pada address bar), lalu muat ulang halaman.</p>
    </div>
    <div>
      <p class="text-slate-200 font-medium">❓ Absensi ditolak walau sudah pada jadwal?</p>
      <p class="text-slate-500">Periksa apakah waktu scan melewati jam selesai kelas, apakah hari ini ditandai sebagai hari libur, atau Anda sudah tercatat hadir hari ini.</p>
    </div>
    <div>
      <p class="text-slate-200 font-medium">❓ Lupa password akun?</p>
      <p class="text-slate-500">Hubungi admin/dosen pengampu (lihat menu Kontak Dosen) untuk melakukan reset akun Anda.</p>
    </div>
    <div>
      <p class="text-slate-200 font-medium">❓ Salah input saat mengajukan izin/sakit?</p>
      <p class="text-slate-500">Hubungi dosen pengampu langsung melalui menu Kontak Dosen agar pengajuan dapat dikoreksi sebelum divalidasi.</p>
    </div>
  </div>
</div>

<?php include __DIR__ . '/_layout_bottom.php'; ?>
